-- File frame for constructing a Haskell file for generating .csp file.

import TF 
import CSP 
import TA  
import Data.List 
import System.Directory  

main  = do print "start"  

           createDirectoryIfMissing True "GenFiles" 

           -- invokes functions genFiles
           genFiles 3  [ 01 ]
