-- Todo: complete the following
    -- recursive process,  
    -- event deadline, 
    -- Example  Hiding (Hd)               
    -- Example  Renaming (Rn)             
    -- Example  Exception (Ex)        


-- Sample test examples for combining the operators of tock-CSP.

{-- 

Constant processes, Deadlock, Termination and Delay
 
01  STOP       (Deadlock (Dl) )             
02  Stopu      (Urgent Deadlock (UD) )
03  SKIP       (Termination (Tn) )          
04  Skipu      (Urgent Termination (UT) )
05  WAIT(n)    (Delay  (Dy) )         
06  Waitu(n)   (strict Delay (sD) )         
07  EDeadline  (ID "e1") 3

BNF Constructors          Dl   UD   Tn   UT   Dy   sD   Px   IC   EC   Il   GP   SC   RP   To   Il   ED   Hd   Rn   Ex
Prefix (Px)               10   11   12   13   14   15   16   17   18   19   1A   1B   1C   1D   1E   1F   1G   1H   1J 
Internal Choice (IC)      20   21   22   23   24   25   26*  27   28   29   2A   2B   2C   2D   2E   2F   2G   2H   2J 
External Choice (EC)      30   31   32   33   34   35   36*  37   38   39   3A   3B   3C   3D   3E   3F   3G   3H   3J 
Interleaving (Il)         40   41   42   43   44   45   46*  47   48   49   4A   4B   4C   4D   4E   4F   4G   4H   4J 
Generallise Parallel (GP) 50   51   52   53   54   55   56*  57   58   59   5A   5B   5C   5D   5E   5F   5G   5H   5J
Sequential (SC)           60   61   62   63   64   65   66*  67   68   69   6A   6B   6C   6D   6E   6F   6G   6H   6J 
Recursive  Process (RP)   70   71   72   73   74   75   76   77   78   79   7A   7B   7C   7D   7E   7F   7G   7H   7J
Interrupt (It)            80   81   82   83   84   85   86   87   88   89   8A   8B   8C   8D   8E   8F   8G   8H   8J
Timeout (To)              90   91   92   93   94   95   96   97   98   99   9A   9B   9C   9D   9E   9F   9G   9H   9J 
Hiding (Hd)               A0   A1   A2   A3   A4   A5   A6   A7   A8   A9   AA   AB   AC   AD   AE   AF   AG   AH   AJ 
Renaming (Rn)             B0   B1   B2   B3   B4   B5   B6   B7   B8   B9   BA   BB   BC   BD   BE   BF   BG   BH   BJ 
Exception (Ex)            C0   C1   C2   C3   C4   C5   C6   C7   C8   C9   CA   CB   CC   CD   CE   CF   CG   CH   CJ 
* Invalid CSP syntax such as (P1|~|P2)->SKIP


BNF Constructors          Dl   UD   Tn   UT   Dy   SD   Px   IC   EC   Il   GP   SC   RP   To   Il   ED   Hd   Rn   Ex
Prefix (Px)               10   11   12   13   14   15   16   17   18   19   1A   1B   1C   1D   1E   1F   1G   1H   1J 
Internal Choice (IC)      20   21   22   23   24   25   26*  27   28   29   2A   2B   2C   2D   2E   2F   2G   2H   2J 
External Choice (EC)      30   31   32   33   34   35   36*  37   38   39   3A   3B   3C   3D   3E   3F   3G   3H   3J 
Interleaving (Il)         40   41   42   43   44   45   46*  47   48   49   4A   4B   4C   4D   4E   4F   4G   4H   4J 
Generallise Parallel (GP) 50   51   52   53   54   55   56*  57   58   59   5A   5B   5C   5D   5E   5F   5G   5H   5J
Sequential (SC)           60   61   62   63   64   65   66*  67   68   69   6A   6B   6C   6D   6E   6F   6G   6H   6J 
Recursive  Process (RP)   70   71   72   73   74   75   76   77   78   79   7A   7B   7C   7D   7E   7F   7G   7H   7J
Interrupt (It)            80   81   82   83   84   85   86   87   88   89   8A   8B   8C   8D   8E   8F   8G   8H   8J
Timeout (To)              90   91   92   93   94   95   96   97   98   99   9A   9B   9C   9D   9E   9F   9G   9H   9J 
Event Deadline (ED)       A0   A1   A2   A3   A4   A5   A6   A7   A8   A9   AA   AB   AC   AD   AE   AF   AG   AH   AJ 
Hiding (Hd)               B0   B1   B2   B3   B4   B5   B6   B7   B8   B9   BA   BB   BC   BD   BE   BF   BG   BH   BJ 
Renaming (Rn)             C0   C1   C2   C3   C4   C5   C6   C7   C8   C9   CA   CB   CC   CD   CE   CF   CG   CH   CJ 
Exception (Ex)            D0   D1   D2   D3   D4   D5   D6   D7   D8   D9   DA   DB   DC   DD   DE   DF   DG   DH   DJ
* Invalid CSP syntax such as (P1|~|P2)->SKIP



-}


import TF
import CSP
import TA
import Data.List
import System.Environment   
import System.Directory



main  = do -- print "start"

           createDirectoryIfMissing True "GenFiles"  
           [pNo, traceSizeString]      <- getArgs

           -- Get trace size
--           traceText  <- readFile "traceSizeFile"
           let traceSize = read traceSizeString
           
           -- choose a single process or all of the provided processes
           if (pNo /= "all") then 
                do 
                   -- pick the selected process using the function pick
                   pick traceSize pNo
           else  
                do

                   -- All the provided processes
                   genFiles traceSize [np0_1]
                   
                   genFiles traceSize [np0_2]

                   genFiles traceSize [np0_3]
                             
                   genFiles traceSize [np0_4]

                   genFiles traceSize [np0_5]
                   
                   genFiles traceSize [np0_6]

                   genFiles traceSize [np0_7]
                   
                   genFiles traceSize [np0_8]
                   
                   genFiles traceSize [np0_9]
                   
                   genFiles traceSize [npA]  
                   
                   genFiles traceSize [np1_1]
                   
                   genFiles traceSize [np1_2]

                   genFiles traceSize [np1_3]
                   
                   genFiles traceSize [np1_4]

                   genFiles traceSize [np1_5]
                   
                   genFiles traceSize [np1_6]    

                   genFiles traceSize [np1_7]    

                   genFiles traceSize [np2_2]

                   genFiles traceSize [np2_3]
                   
                   genFiles traceSize [np2_4]

                   genFiles traceSize [np2_5]
                   
                   genFiles traceSize [np2_6]
                   
                   genFiles traceSize [np2_7]

                   genFiles traceSize [np3_2]

                   genFiles traceSize [np3_3]
                   
                   genFiles traceSize [np3_4]

                   genFiles traceSize [np3_5]
                   
                   genFiles traceSize [np3_6]    

                   genFiles traceSize [np3_7]
                   
                   genFiles traceSize [np4_2]

                   genFiles traceSize [np4_3]
                   
                   genFiles traceSize [np4_4]

                   genFiles traceSize [np4_5]
                   
                   genFiles traceSize [np4_6]
                   
                   genFiles traceSize [np4_7]                       

                   genFiles traceSize [np5_2]

                   genFiles traceSize [np5_3]
                   
                   genFiles traceSize [np5_4]   

                   genFiles traceSize [np5_5]
                   
                   genFiles traceSize [np5_6]
                   
                   genFiles traceSize [np5_7]                                         

                   genFiles traceSize [nsp6_1]
                   
                   genFiles traceSize [nsp6_2]
                   
                   genFiles traceSize [nsp6_3]  
                   
                   genFiles traceSize [nsp6_4]  
                   
                   genFiles traceSize [nsp6_5]  
                   
                   genFiles traceSize [nsp6_6]  

                   genFiles traceSize [nsp6_7]
                   
                   genFiles traceSize [nsp6_8]
                   
                   genFiles traceSize [nsp6_9]   
                   
                   genFiles traceSize [nsp6_10]  
                   
                   genFiles traceSize [nsp6_11] -- , p6_11]  
                   
                   genFiles traceSize [nsp6_12] -- , p6_11]  
                   
                   genFiles traceSize [nsp6_13] -- , p6_11]
                   
                   genFiles traceSize [nsp6_14]
                   
                   genFiles traceSize [nsp6_15]  
          
                   -- Sequential composition
                   genFiles traceSize [np7_2]

                   genFiles traceSize [np7_3]
                   
                   genFiles traceSize [np7_4]

                   genFiles traceSize [np7_5]
                   
                   genFiles traceSize [np7_6]
                   
                   genFiles traceSize [np7_7]                   

                   -- Interrupt                   
                   genFiles traceSize [np8_2]

                   genFiles traceSize [np8_3]
                   
                   genFiles traceSize [np8_4]

                   genFiles traceSize [np8_5]
                   
                   genFiles traceSize [np8_6]
                   
                   genFiles traceSize [np8_7]    
                   
                   -- Timeout ---------------
                   genFiles traceSize [np9_1]
                   
                   genFiles traceSize [np9_2]
                   
                   genFiles traceSize [np9_3]
                   
                   genFiles traceSize [np9_4] 
                   
                   genFiles traceSize [np9_5]                  
                
                   genFiles traceSize [np9_6]
                   
                   genFiles traceSize [np9_7]
                   
                   genFiles traceSize [np9_8]
                   -- to do, reverse, operators with timeout      
                                     
                   
                   -- Hiding -----------------
                   genFiles traceSize [np10_1]
                   
                   genFiles traceSize [np10_2]
                   
                   genFiles traceSize [np10_3]
                   
                   genFiles traceSize [np10_4] 
                   
                   genFiles traceSize [np10_5]                  
                
                   genFiles traceSize [np10_6]
                   
                   genFiles traceSize [np10_7] 
                   
                   -- Hiding multiple events
                   genFiles traceSize [np10_1m]
                   
                   genFiles traceSize [np10_2m]
                   
                   genFiles traceSize [np10_3m]
                   
                   genFiles traceSize [np10_4m] 
                   
                   genFiles traceSize [np10_5m]                  
                
                   genFiles traceSize [np10_6m]
                   
                   genFiles traceSize [np10_7m]                

                   -- Hiding empty events
                   genFiles traceSize [np10_1e]
                   
                   genFiles traceSize [np10_2e]
                   
                   genFiles traceSize [np10_3e]
                   
                   genFiles traceSize [np10_4e] 
                   
                   genFiles traceSize [np10_5e]                  
                
                   genFiles traceSize [np10_6e]
                   
                   genFiles traceSize [np10_7e]  
                   
                   -- Hiding single event in one side of binary operators
                   genFiles traceSize [np10_2s]
                   
                   genFiles traceSize [np10_3s]
                   
                   genFiles traceSize [np10_4s] 
                   
                   genFiles traceSize [np10_5s]                  
                
                   genFiles traceSize [np10_6s]
                   
                   genFiles traceSize [np10_7s]                

                   -- Hiding multiple events in one side of binary operators
                   genFiles traceSize [np10_2ms]
                   
                   genFiles traceSize [np10_3ms]
                   
                   genFiles traceSize [np10_4ms] 
                   
                   genFiles traceSize [np10_5ms]                  
                
                   genFiles traceSize [np10_6ms]
                   
                   genFiles traceSize [np10_7ms]                

                   -- Hiding empty events in one side of binary operators
                   genFiles traceSize [np10_2es]
                   
                   genFiles traceSize [np10_3es]
                   
                   genFiles traceSize [np10_4es] 
                   
                   genFiles traceSize [np10_5es]                  
                
                   genFiles traceSize [np10_6es]
                   
                   genFiles traceSize [np10_7es]                
                                                    
                                  
                   -- Renaming
                   genFiles traceSize [np11_1]
                   
                   genFiles traceSize [np11_2]
                   
                   genFiles traceSize [np11_3]
                   
                   genFiles traceSize [np11_4] 
                   
                   genFiles traceSize [np11_5]                  
                
                   genFiles traceSize [np11_6]
                   
                   genFiles traceSize [np11_7]

                   -- Other special cases
                   genFiles traceSize [np12_1]
                   
                   genFiles traceSize [np12_2]                                      
                   
                   -- Exception
                   genFiles traceSize [np13_C]  
                       
                   genFiles traceSize [np13_D]

                   genFiles traceSize [np13_E]

                   genFiles traceSize [np13_2]
                   
                   genFiles traceSize [np13_3]
                   
                   genFiles traceSize [np13_4] 
                   
                   genFiles traceSize [np13_5]                  
                
                   genFiles traceSize [np13_6]
                   
                   genFiles traceSize [np13_7]
                   --------------------------
                                      
                                    
                              

         
-------------------------------------------------------------------
-- Choice of a process         
           
pick  traceSize  pNo   | (pNo == "01") = genFiles traceSize [np0_1]
                       
                       | (pNo == "02") = genFiles traceSize [np0_2]
                       
                       | (pNo == "03") = genFiles traceSize [np0_3]
                       
                       | (pNo == "04") = genFiles traceSize [np0_4]

                       | (pNo == "05") = genFiles traceSize [np0_5]
                       
                       | (pNo == "06") = genFiles traceSize [np0_6]

                       | (pNo == "07") = genFiles traceSize [np0_7]
                       
                       | (pNo == "08") = genFiles traceSize [np0_8]
                       
                       | (pNo == "09") = genFiles traceSize [np0_9]
                       
                       | (pNo == "0A") = genFiles traceSize [npA  ]
                       
                       | (pNo == "0B") = genFiles traceSize [np8_1]  
                       
                       | (pNo == "0C") = genFiles traceSize [npdl ] 
                       
                       | (pNo == "0D") = genFiles traceSize [npB  ]
                       
                       | (pNo == "11") = genFiles traceSize [np1_1]
                       
                       | (pNo == "12") = genFiles traceSize [np1_2]

                       | (pNo == "13") = genFiles traceSize [np1_3]
                       
                       | (pNo == "14") = genFiles traceSize [np1_4]

                       | (pNo == "15") = genFiles traceSize [np1_5]
                       
                       | (pNo == "16") = genFiles traceSize [np1_6]    
                       
                       | (pNo == "17") = genFiles traceSize [np1_7]                           

                       | (pNo == "22") = genFiles traceSize [np2_2]

                       | (pNo == "23") = genFiles traceSize [np2_3]
                       
                       | (pNo == "24") = genFiles traceSize [np2_4]

                       | (pNo == "25") = genFiles traceSize [np2_5]
                       
                       | (pNo == "26") = genFiles traceSize [np2_6]
                       
                       | (pNo == "27") = genFiles traceSize [np2_7]                       

                       | (pNo == "32") = genFiles traceSize [np3_2]

                       | (pNo == "33") = genFiles traceSize [np3_3]
                       
                       | (pNo == "34") = genFiles traceSize [np3_4]

                       | (pNo == "35") = genFiles traceSize [np3_5]
                       
                       | (pNo == "36") = genFiles traceSize [np3_6]    

                       | (pNo == "37") = genFiles traceSize [np3_7]
                       
                       | (pNo == "42") = genFiles traceSize [np4_2]

                       | (pNo == "43") = genFiles traceSize [np4_3]
                       
                       | (pNo == "44") = genFiles traceSize [np4_4]

                       | (pNo == "45") = genFiles traceSize [np4_5]
                       
                       | (pNo == "46") = genFiles traceSize [np4_6]
                       
                       | (pNo == "47") = genFiles traceSize [np4_7]                           

                       | (pNo == "52") = genFiles traceSize [np5_2]

                       | (pNo == "53") = genFiles traceSize [np5_3]
                       
                       | (pNo == "54") = genFiles traceSize [np5_4]   

                       | (pNo == "55") = genFiles traceSize [np5_5]
                       
                       | (pNo == "56") = genFiles traceSize [np5_6] 

                       | (pNo == "57") = genFiles traceSize [np5_7]                                            

                       | (pNo == "61") = genFiles traceSize [nsp6_1]
                       
                       | (pNo == "62") = genFiles traceSize [nsp6_2]
                       
                       | (pNo == "63") = genFiles traceSize [nsp6_3]  
                       
                       | (pNo == "64") = genFiles traceSize [nsp6_4]  
                       
                       | (pNo == "65") = genFiles traceSize [nsp6_5]  
                       
                       | (pNo == "66") = genFiles traceSize [nsp6_6]  

                       | (pNo == "67") = genFiles traceSize [nsp6_7]
                       
                       | (pNo == "68") = genFiles traceSize [nsp6_8]
                       
                       | (pNo == "69") = genFiles traceSize [nsp6_9]   
                       
                       | (pNo == "610") = genFiles traceSize [nsp6_10]  
                       
                       | (pNo == "611") = genFiles traceSize [nsp6_11]  -- , p6_11]  
                       
                       | (pNo == "612") = genFiles traceSize [nsp6_12]  -- , p6_11]  
                       
                       | (pNo == "613") = genFiles traceSize [nsp6_13]  -- , p6_11]
                       
                       | (pNo == "614") = genFiles traceSize [nsp6_14]
                       
                       | (pNo == "615") = genFiles traceSize [nsp6_15]  
                       
                       -- Sequential composition
                       | (pNo == "72") = genFiles traceSize [np7_2]

                       | (pNo == "73") = genFiles traceSize [np7_3]
                       
                       | (pNo == "74") = genFiles traceSize [np7_4]   

                       | (pNo == "75") = genFiles traceSize [np7_5]
                       
                       | (pNo == "76") = genFiles traceSize [np7_6] 
                       
                       | (pNo == "77") = genFiles traceSize [np7_7]                                            

                       -- Interrupt
                       | (pNo == "81") = genFiles traceSize [np8_1]  
                       
                       | (pNo == "82") = genFiles traceSize [np8_2]

                       | (pNo == "83") = genFiles traceSize [np8_3]
                       
                       | (pNo == "84") = genFiles traceSize [np8_4]   

                       | (pNo == "85") = genFiles traceSize [np8_5]
                       
                       | (pNo == "86") = genFiles traceSize [np8_6]    
                       
                       | (pNo == "87") = genFiles traceSize [np8_7]   
                       
                       -- Timeout
                       | (pNo == "91") = genFiles traceSize [np9_1]  
                       
                       | (pNo == "92") = genFiles traceSize [np9_2]

                       | (pNo == "93") = genFiles traceSize [np9_3]
                       
                       | (pNo == "94") = genFiles traceSize [np9_4]   

                       | (pNo == "95") = genFiles traceSize [np9_5]
                       
                       | (pNo == "96") = genFiles traceSize [np9_6]    
                       
                       | (pNo == "97") = genFiles traceSize [np9_7]
                       
                       | (pNo == "98") = genFiles traceSize [np9_8]                                               
                                                             
                       -- Hiding
                       | (pNo == "101") = genFiles traceSize [np10_1]  
                       
                       | (pNo == "102") = genFiles traceSize [np10_2]

                       | (pNo == "103") = genFiles traceSize [np10_3]
                       
                       | (pNo == "104") = genFiles traceSize [np10_4]   

                       | (pNo == "105") = genFiles traceSize [np10_5]
                       
                       | (pNo == "106") = genFiles traceSize [np10_6]    
                       
                       | (pNo == "107") = genFiles traceSize [np10_7]

                       -- Hiding multiple events
                       | (pNo == "101m") = genFiles traceSize [np10_1m]  
                       
                       | (pNo == "102m") = genFiles traceSize [np10_2m]

                       | (pNo == "103m") = genFiles traceSize [np10_3m]
                       
                       | (pNo == "104m") = genFiles traceSize [np10_4m]   

                       | (pNo == "105m") = genFiles traceSize [np10_5m]
                       
                       | (pNo == "106m") = genFiles traceSize [np10_6m]    
                       
                       | (pNo == "107m") = genFiles traceSize [np10_7m]

                       -- Hiding empty events
                       | (pNo == "101e") = genFiles traceSize [np10_1e]  
                       
                       | (pNo == "102e") = genFiles traceSize [np10_2e]

                       | (pNo == "103e") = genFiles traceSize [np10_3e]
                       
                       | (pNo == "104e") = genFiles traceSize [np10_4e]   

                       | (pNo == "105e") = genFiles traceSize [np10_5e]
                       
                       | (pNo == "106e") = genFiles traceSize [np10_6e]    
                       
                       | (pNo == "107e") = genFiles traceSize [np10_7e]
                                              
                       -- Hiding in one side of binary operator
                       -- Hiding
                       | (pNo == "102s") = genFiles traceSize [np10_2s]

                       | (pNo == "103s") = genFiles traceSize [np10_3s]
                       
                       | (pNo == "104s") = genFiles traceSize [np10_4s]   

                       | (pNo == "105s") = genFiles traceSize [np10_5s]
                       
                       | (pNo == "106s") = genFiles traceSize [np10_6s]    
                       
                       | (pNo == "107s") = genFiles traceSize [np10_7s]

                       -- Hiding multiple events
                       | (pNo == "102ms") = genFiles traceSize [np10_2ms]

                       | (pNo == "103ms") = genFiles traceSize [np10_3ms]
                       
                       | (pNo == "104ms") = genFiles traceSize [np10_4ms]   

                       | (pNo == "105ms") = genFiles traceSize [np10_5ms]
                       
                       | (pNo == "106ms") = genFiles traceSize [np10_6ms]    
                       
                       | (pNo == "107ms") = genFiles traceSize [np10_7ms]

                       -- Hiding empty events
                       | (pNo == "102es") = genFiles traceSize [np10_2es]

                       | (pNo == "103es") = genFiles traceSize [np10_3es]
                       
                       | (pNo == "104es") = genFiles traceSize [np10_4es]   

                       | (pNo == "105es") = genFiles traceSize [np10_5es]
                       
                       | (pNo == "106es") = genFiles traceSize [np10_6es]    
                       
                       | (pNo == "107es") = genFiles traceSize [np10_7es]
                       
                       
                       -- Rename
                       | (pNo == "111") = genFiles traceSize [np11_1]  
                       
                       | (pNo == "112") = genFiles traceSize [np11_2]

                       | (pNo == "113") = genFiles traceSize [np11_3]
                       
                       | (pNo == "114") = genFiles traceSize [np11_4]   

                       | (pNo == "115") = genFiles traceSize [np11_5]
                       
                       | (pNo == "116") = genFiles traceSize [np11_6]    
                       
                       | (pNo == "117") = genFiles traceSize [np11_7]
                       
                       --other special cases
                       | (pNo == "121") = genFiles traceSize [np12_1]                       
                       
                       | (pNo == "122") = genFiles traceSize [np12_2] 
                       
                       
                       -- Exception  --------------------------------
                       | (pNo == "13C") = genFiles traceSize [np13_C]  
                       
                       | (pNo == "13D") = genFiles traceSize [np13_D]

                       | (pNo == "13E") = genFiles traceSize [np13_E]

                       | (pNo == "132") = genFiles traceSize [np13_2]
                       
                       | (pNo == "133") = genFiles traceSize [np13_3]    
                       
                       | (pNo == "134") = genFiles traceSize [np13_4]
                       
                       | (pNo == "135") = genFiles traceSize [np13_5]
                       
                       | (pNo == "136") = genFiles traceSize [np13_6] 
                                                                    
                       
                       -- RoboChart models --------------------------
                       | (pNo == "123") = genFiles traceSize [np12_3]
                                         
                       | (pNo == "124") = genFiles traceSize [np12_4]
                       
                       | (pNo == "125") = genFiles traceSize [npa_1]    -- SKIP0, strict termination                
                       
                       | (pNo == "126") = genFiles traceSize [npa_2]    -- countdown, the trict time budget 
                       
                       -- Automatic Door System
                       | (pNo == "ADS") = genFiles traceSize [npADS] 
                       
                       | (pNo == "trg") = genFiles traceSize [ptraceGen]
                       
                       -- out of range
                       | otherwise      = sequence [(putStrLn "Invalid process number, please check again.")] 
                        
                       

           

--------------------------------------------------------------------------------------------           
-- ~~~~~~~~~~~~~~~~~~~~~~~ Definition of the processes  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -- 


----  Constant processes  ------------------------------------------------------------------

-- Example 0.1 
p0_1 = NamedProc "p0_1" STOP

-- Example 0.2 
p0_2 = NamedProc "p0_2" Stop

-- Example 0.3 
p0_3 = NamedProc "p0_3" SKIP

-- Example 0.4 
p0_4 = NamedProc "p0_4" Skipu

-- Example 0.5 
p0_5 = NamedProc "p0_5" (WAIT 2)

-- Example 0.6
p0_6 = NamedProc "p0_6" (Waitu 2)

-- Example 0.7
p0_7 = NamedProc "p0_7" (EDeadline (ID "e1") 3)

-- todo, moving prefix to constant process


--01 Prefix ----------------------------------------------------------------------------------------

-- Example 10 
p1_0 = NamedProc "p1_0" (Prefix (ID "e1") STOP)


-- Example 11 
p1_1 = NamedProc "p1_1" (Prefix (ID "e1") Stopu)


-- Example 12 
p1_2 = NamedProc "p1_2" (Prefix (ID "e1") SKIP)


-- Example 13 
p1_3 = NamedProc "p1_3" (Prefix (ID "e1") Skipu)


-- Example 14 
p1_4 = NamedProc "p1_4" (Prefix (ID "e1") (WAIT 2) )


-- Example 15 
p1_5 = NamedProc "p1_5" (Prefix (ID "e1") (Waitu 2))


-- Example 16 : Prefix with prefix 
p1_6 = NamedProc "p1_6" (Prefix (ID "e1") (Prefix (ID "e2") SKIP))


-- Example 17: Prefix with Internal choice
p1_7 = NamedProc "p1_7" (Prefix (ID "e1") (IntChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


-- Example 18: Prefix with External choice
p1_8 = NamedProc "p1_8" (Prefix (ID "e1") (ExtChoice (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)))


-- Example 19: Prefix with Interleave 
p1_9 = NamedProc "p1_9" (Prefix (ID "e1") (Interleave (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP)))


-- Example 1A: Prefix with Generallise parallel 
p1_A = NamedProc "p1_A" (Prefix (ID "e1") (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP) [ID "e2"]))


-- Example 1B: Prefix with Sequential composition 
p1_B = NamedProc "p1_B" (Prefix (ID "e1") (Seq (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)))


-- Example 1C: Recursive  Process (RP)   
p1_C = NamedProc "p1_B"  (Prefix (ID "e1") (ProcID "p1_C"))


-- Example 1D: Timeout (To)  
p1_D = NamedProc "p1_D"  (Prefix (ID "e1")  (Timeout (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) 2))


-- Example 1E: Interrupt (It) 
p1_E = NamedProc "p1_E"  (Prefix (ID "e1")  (Interrupt (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)))

            
-- Example 1F:  Event Deadline (ED)  
p1_F = NamedProc "p1_E"  (Prefix (ID "e1")  (EDeadline (ID "e1") 3))

     
-- Example 1G:  Hiding (Hd)               
p1_G = NamedProc "p1_E"  (Prefix (ID "e1")  (Hiding (Prefix (ID "e1") SKIP) [(ID "e1")]) )


-- Example 1H:  Renaming (Rn)    
p1_H = NamedProc "p1_E"  (Prefix (ID "e1")  (Rename (Prefix (ID "e1") SKIP) [((ID "e1"), (ID "e3"))])  )  

         
-- Example 1J:  Exception (Ex)        
p1_J = NamedProc "p1_E"  (Prefix (ID "e1")  (Exception (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) [ID "e1"]) )



--02 Internal choice -------------------------------------------------------------------------  

-- Example 2.1 : Internal choice with prefix 
-- E? Invalid syntax, (p1 |~| p2) -> p


-- Example 0.5 
p2_0 = NamedProc "p2_0" (IntChoice (Prefix (ID "e1") STOP)  (Prefix (ID "e2") STOP))


-- Example 0.5 
p2_1 = NamedProc "p2_1" (IntChoice (Prefix (ID "e1") Stopu) (Prefix (ID "e2") Stopu))


-- Example 0.5 
p2_2 = NamedProc "p2_2" (IntChoice (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))


-- Example 0.5 
p2_3 = NamedProc "p2_3" (IntChoice (Prefix (ID "e1") Skipu) (Prefix (ID "e2") Skipu))


-- Example 0.5 
p2_4 = NamedProc "p2_4" (IntChoice (Prefix (ID "e1") (WAIT 1)) (Prefix (ID "e2") SKIP) (WAIT 2))


-- Example 0.5 
p2_5 = NamedProc "p2_5" (IntChoice (Prefix (ID "e1") (Waitu 1)) (Prefix (ID "e2") (Waitu 2)))


-- Example 0.5 
-- np2_6 = NamedProc "p26" (IntChoice (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))
-- Internal choice with prefix 
-- E? Invalid syntax, (p1 |~| p2) -> p


-- Example 2.2: Internal choice with Internal choice
p2_7  = NamedProc "p2_7" 
                  (IntChoice (Prefix (ID "e2") SKIP) (IntChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


-- Example 2.3: Internal choice with External choice
p2_8 = NamedProc "p2_8" 
                 (IntChoice (Prefix (ID "e1") SKIP) (ExtChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


-- Example 2.4: Internal choice with Interleave 
p2_9 = NamedProc "p2_9" 
                  (IntChoice (Prefix (ID "e1") SKIP) 
                             (Interleave (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP)))

-- Example 2.5: Internal choice with Generallise parallel 
p2_A = NamedProc "p2_A" 
                 (IntChoice (Prefix (ID "e1") SKIP) 
                            (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP) [ID "e2"]))


-- Example 2.6: Internal choice with Sequential composition 
p2_B = NamedProc "p2_B" 
                  (IntChoice (Prefix (ID "e1") SKIP) 
                             (Seq (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)))

-- Example : Internal choice with recursive process 
p2_C = NamedProc "p2_C" 
                   (IntChoice  (Prefix (ID "e1") (ProcID "p2_C"))  
                               (Prefix (ID "e1") (ProcID "p2_C")))   
        
-- Example : Internal choice with Timeout
p2_D = NamedProc "p2_D" 
                   (IntChoice 
                        (Timeout (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) 2)
                        (Timeout (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) 2)
                   )


-- Example 2.7: Internal choice with Interrupt  
p2_E = NamedProc "p2_E" 
                  (IntChoice (Prefix (ID "e1") SKIP) 
                             (Interrupt (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)))


-- Example : Internal choice with event deadline 
p2_F = NamedProc "p2_F" 
                  (IntChoice (EDeadline (ID "e1") 3)  
                  (EDeadline (ID "e1") 3))
        

-- Example : Internal choice with hiding
p2_G = NamedProc "p2_G" 
                  (IntChoice  (Hiding (Prefix (ID "e1") SKIP) [(ID "e1")])  
                              (Hiding (Prefix (ID "e2") SKIP) [(ID "e1")]))
        

-- Example : Internal choice with renaming
p2_H = NamedProc "p2_H" 
                  (IntChoice  (Rename (Prefix (ID "e1") SKIP) [((ID "e1"), (ID "e3"))])
                              (Rename (Prefix (ID "e1") SKIP) [((ID "e1"), (ID "e3"))])
                  )


-- Example : Internal choice with exception
p2_J = NamedProc "p2_J" 
                 (IntChoice  
                    (Prefix (ID "e1") SKIP)
                    (Exception (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) [ID "e1"])  
                 )
        

        
--03 External choice -----------------------------------------------------------------------------------  

-- Example 0.5 
p3_0 = NamedProc "p3_0" (ExtChoice (Prefix (ID "e1") STOP)  (Prefix (ID "e2") STOP))


-- Example 0.5 
p3_1 = NamedProc "p3_1" (ExtChoice (Prefix (ID "e1") Stopu) (Prefix (ID "e2") Stopu))


-- Example 0.5 
p3_2 = NamedProc "p3_2" (ExtChoice (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))


-- Example 0.5 
p3_3 = NamedProc "p3_3" (ExtChoice (Prefix (ID "e1") Skipu) (Prefix (ID "e2") Skipu))


-- Example 0.5 
p3_4 = NamedProc "p3_4" (ExtChoice (Prefix (ID "e1") (WAIT 1)) (Prefix (ID "e2") SKIP) (WAIT 2))


-- Example 0.5 
p3_5 = NamedProc "p3_5" (ExtChoice (Prefix (ID "e1") (Waitu 1)) (Prefix (ID "e2") (Waitu 2)))


-- Example 0.5 
-- p3_6 = NamedProc "p3_6" (ExtChoice (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))
-- Internal choice with prefix 
-- E? Invalid syntax, (p1 |~| p2) -> p


-- Example 2.2: Internal choice with Internal choice
p3_7  = NamedProc "p3_7" (ExtChoice (Prefix (ID "e2") SKIP) (IntChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


-- Example 2.3: Internal choice with External choice
p3_8 = NamedProc "p3_8" (ExtChoice (Prefix (ID "e1") SKIP) (ExtChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


-- Example 2.4: Internal choice with Interleave 
p3_9 = NamedProc "p3_9" 
       (ExtChoice (Prefix (ID "e1") SKIP) (Interleave (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP)))

-- Example 2.5: Internal choice with Generallise parallel 
p3_A = NamedProc "p3_A" 
       (ExtChoice (Prefix (ID "e1") SKIP) (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP) [ID "e2"]))


-- Example 2.6: Internal choice with Sequential composition 
p3_B = NamedProc "p3_B" 
        (ExtChoice (Prefix (ID "e1") SKIP) (Seq (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)))


p3_C = NamedProc "p3_C" 
                 (ExtChoice  (Prefix (ID "e1") (ProcID "p3_C"))  (Prefix (ID "e1") (ProcID "p3_C")))   
        

p3_D = NamedProc "p3_D" 
                   (ExtChoice 
                        (Timeout (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) 2)
                        (Timeout (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) 2)
                   )


-- Example 2.7: Internal with Interrupt  
p3_E = NamedProc "p3_E" 
                 (ExtChoice (Prefix (ID "e1") SKIP) (Interrupt (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)))


p3_F = NamedProc "p3_F" 
                 (ExtChoice (EDeadline (ID "e1") 3)  (EDeadline (ID "e1") 3))
        

p3_G = NamedProc "p3_G" 
                 (ExtChoice (Hiding (Prefix (ID "e1") SKIP) [(ID "e1")])  (Hiding (Prefix (ID "e2") SKIP) [(ID "e1")]))
        

p3_H = NamedProc "p3_H" 
                 (ExtChoice (Rename (Prefix (ID "e1") SKIP) [((ID "e1"), (ID "e3"))])
                            (Rename (Prefix (ID "e1") SKIP) [((ID "e1"), (ID "e3"))])
                 )

        
p3_J = NamedProc "p3_J" 
                 (ExtChoice
                    (Prefix (ID "e1") SKIP)
                    (Exception (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) [ID "e1"])   

        



--04  Interleave ----------------------------------------------------------------------------------------
-- Example 0.5 
p4_0 = NamedProc "p4_0" (Interleave (Prefix (ID "e1") STOP)  (Prefix (ID "e2") STOP))


-- Example 0.5 
p4_1 = NamedProc "p4_1" (Interleave (Prefix (ID "e1") Stopu) (Prefix (ID "e2") Stopu))


-- Example 0.5 
p4_2 = NamedProc "p4_2" (Interleave (Prefix (ID "e1") SKIP)  (Prefix (ID "e2") SKIP))


-- Example 0.5 
p4_3 = NamedProc "p4_3" (Interleave (Prefix (ID "e1") Skipu) (Prefix (ID "e2") Skipu))


-- Example 0.5 
p4_4 = NamedProc "p4_4" (Interleave (Prefix (ID "e1") (WAIT 1)) (Prefix (ID "e2") SKIP) (WAIT 2))


-- Example 0.5 
p4_5 = NamedProc "p4_5" (Interleave (Prefix (ID "e1") (Waitu 1)) (Prefix (ID "e2") (Waitu 2)))


-- Example 0.5 
-- p4_6 = NamedProc "p4_6" (Interleave (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))
-- Internal choice with prefix 
-- E? Invalid syntax, (p1 |~| p2) -> p


-- Example 2.2: Internal choice with Internal choice
p4_7  = NamedProc "p4_7" (Interleave (Prefix (ID "e2") SKIP) (IntChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


-- Example 2.3: Internal choice with External choice
p4_8 = NamedProc "p4_8" (Interleave (Prefix (ID "e1") SKIP) (ExtChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


-- Example 2.4: Internal choice with Interleave 
p4_9 = NamedProc "p4_9" 
       (Interleave (Prefix (ID "e1") SKIP) (Interleave (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP)))

-- Example 2.5: Internal choice with Generallise parallel 
p4_A = NamedProc "p4_A" 
       (Interleave (Prefix (ID "e1") SKIP) (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP) [ID "e2"]))


-- Example 2.6: Internal choice with Sequential composition 
p4_B = NamedProc "p4_B" 
        (Interleave (Prefix (ID "e1") SKIP) (Seq (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)))


-- Example 2.7:  Interleave with Recursive process
p4_C = NamedProc "p4_C" 
                 (Interleave  (Prefix (ID "e1") (ProcID "p4_C"))  (Prefix (ID "e1") (ProcID "p4_C")))   
        

-- Example 2.7:  Interleave with Timeout
p4_D = NamedProc "p4_D" 
                   (Interleave 
                        (Timeout (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) 2)
                        (Timeout (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) 2)
                   )


-- Example 2.7: Interleave with Interrupt  
p4_E = NamedProc "p4_E" 
        (Interleave (Prefix (ID "e1") SKIP) (Interrupt (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)))


-- Example Interleave with Event deadline
p4_F = NamedProc "p4_F" 
                 (Interleave (EDeadline (ID "e1") 3)  (EDeadline (ID "e1") 3))
        

-- Example Interleave with Hiding
p4_G = NamedProc "p4_G" 
                 (Interleave  
                        (Hiding (Prefix (ID "e1") SKIP) [(ID "e1")])  
                        (Hiding (Prefix (ID "e2") SKIP) [(ID "e1")]))
        

-- Example Interleave with Renaming
p4_H = NamedProc "p4_H" 
                 (Interleave  
                    (Rename (Prefix (ID "e1") SKIP) [((ID "e1"), (ID "e3"))]) 
                    (Rename (Prefix (ID "e1") SKIP) [((ID "e1"), (ID "e3"))])
                 )

-- Example Interleave with exception
p4_J = NamedProc "p4_J" 
                 (Interleave  
                    (Prefix (ID "e1") SKIP)
                    (Exception (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) [ID "e1"])  
                 )
        

-- Example 5.4: Generallise parallel with Interleave --------------------------------------------------
-- Example 0.5 
p5_0 = NamedProc "p5_0" 
                 (GenPar 
                     (Prefix (ID "e1") STOP)  
                     (Prefix (ID "e1") STOP)
                     [ID "e1"]                      
                  )


-- Example 0.5 
p5_1 = NamedProc "p5_1" 
                 (GenPar 
                    (Prefix (ID "e1") Stopu) 
                    (Prefix (ID "e1") Stopu)
                    [ID "e1"]
                 )


-- Example 0.5 
p5_2 = NamedProc "p5_2" 
                 (GenPar 
                    (Prefix (ID "e1") SKIP)  
                    (Prefix (ID "e2") SKIP)
                    [ID "e1"]
                 )


-- Example 0.5 
p5_3 = NamedProc "p5_3" 
                 (GenPar (Prefix (ID "e1") Skipu) 
                         (Prefix (ID "e2") Skipu)
                         [ID "e2"]
                 )


-- Example 0.5 
p5_4 = NamedProc "p5_4" 
                 (GenPar 
                    (Prefix (ID "e1") (WAIT 1)) 
                    (Prefix (ID "e2") (WAIT 2))
                    [ID "e2"]
                 )


-- Example 0.5 
p5_5 = NamedProc "p5_5" 
                 (GenPar 
                    (Prefix (ID "e1") (Waitu 2)) 
                    (Prefix (ID "e2") (Waitu 2))
                    [ID "e2"]                    
                    )


-- Example 0.5 
-- p5_6 = NamedProc "p5_6" (GenPar (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))
-- Internal choice with prefix 
-- E? Invalid syntax, (p1 |~| p2) -> p


-- Example 2.2: Generallised Parallel with Internal choice
p5_7  = NamedProc "p5_7" 
                  (GenPar 
                       (Prefix (ID "e2") SKIP) 
                       (IntChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP))
                       [ID "e2"]
                  )


-- Example 2.3: Generallised Parallel with External choice
p5_8 = NamedProc "p5_8" 
                 (GenPar 
                    (Prefix (ID "e1") SKIP) 
                    (ExtChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP))
                    [ID "e2"]
                 )


-- Example 2.4: Generallised Parallel with Interleave 
p5_9 = NamedProc "p5_9" 
                 (GenPar 
                    (Prefix (ID "e1") SKIP) 
                    (Interleave (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP))
                    [ID "e2"]
                 )

-- Example 2.5: Generallised Parallel with Generallise parallel 
p5_A = NamedProc "p5_A" 
                 (GenPar 
                    (Prefix (ID "e1") SKIP) 
                    (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP) [ID "e2"])
                    [ID "e2"]
                 )


-- Example 2.6: Generallised Parallel with Sequential composition 
p5_B = NamedProc "p5_B" 
                 (GenPar 
                    (Prefix (ID "e1") SKIP) 
                    (Seq (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))
                    [ID "e2"]
                 )


--  Generallised Parallel with recursive process 
p5_C = NamedProc "p5_C" 
                 (GenPar  
                    (Prefix (ID "e1") (ProcID "p5_C"))  
                    (Prefix (ID "e1") (ProcID "p5_C"))
                    [ID "e2"]
                 )   
        
--  Generallised Parallel with Timeout
p5_D = NamedProc "p5_D" 
                   (GenPar 
                        (Timeout (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) 2)
                        (Timeout (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) 2)
                        [ID "e2"]
                   )



-- Example 2.7: Generallised Parallel with Interrupt  
p5_E = NamedProc "p5_E" 
                 (GenPar 
                    (Prefix (ID "e1") SKIP) 
                    (Interrupt (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))
                    [ID "e2"]
                 )

--  Generallised Parallel with  Event deadline
p5_F = NamedProc "p5_F" 
                 (GenPar 
                    (EDeadline (ID "e1") 3)  
                    (EDeadline (ID "e1") 3)
                    [ID "e2"]
                 )
        

--  Generallised Parallel with hiding
p5_G = NamedProc "p5_G" 
                 (GenPar  
                     (Hiding (Prefix (ID "e1") SKIP) [(ID "e1")])  
                     (Hiding (Prefix (ID "e2") SKIP) [(ID "e1")])
                     [ID "e2"]
                 )
        
--  Generallised Parallel with renaming        
p5_H = NamedProc "p5_H" 
                 (GenPar  
                    (Rename (Prefix (ID "e1") SKIP) [((ID "e1"), (ID "e3"))])  
                    (Rename (Prefix (ID "e1") SKIP) [((ID "e1"), (ID "e3"))])
                    [ID "e3"]
                 )


--  Generallised Parallel with exception        
p5_J = NamedProc "p5_J" 
                 (GenPar
                    (Prefix (ID "e1") SKIP)
                    (Exception (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) [ID "e1"])  
                    [ID "e2"]
                 )
        

-- Sequential composition -------------------------------------------------------------------------  

-- Sequential composition 
p6_0 = NamedProc "p6_0" (Seq (Prefix (ID "e1") STOP)  (Prefix (ID "e2") STOP))


-- Sequential composition 
p6_1 = NamedProc "p6_1" (Seq (Prefix (ID "e1") Stopu) (Prefix (ID "e2") Stopu))


-- Sequential composition 
p6_2 = NamedProc "p6_2" (Seq (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))


-- Sequential composition 
p6_3 = NamedProc "p6_3" (Seq (Prefix (ID "e1") Skipu) (Prefix (ID "e2") Skipu))


-- Sequential composition 
p6_4 = NamedProc "p6_4" (Seq (Prefix (ID "e1") (WAIT 1)) (Prefix (ID "e2") SKIP) (WAIT 2))


-- Sequential composition 
p6_5 = NamedProc "p6_5" (Seq (Prefix (ID "e1") (Waitu 1)) (Prefix (ID "e2") (Waitu 2)))


-- Sequential composition 
-- np6_6 = NamedProc "p26" (Seq (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))
-- Internal choice with prefix 
-- E? Invalid syntax, (p1 |~| p2) -> p


-- Sequential composition with Internal choice
p6_7  = NamedProc "p6_7" (Seq (Prefix (ID "e2") SKIP) (IntChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


-- Sequential composition with External choice
p6_8 = NamedProc "p6_8" (Seq (Prefix (ID "e1") SKIP) (ExtChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


-- Sequential composition with Interleave 
p6_9 = NamedProc "p6_9" 
       (Seq (Prefix (ID "e1") SKIP) (Interleave (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP)))


-- Sequential composition with Generallise parallel 
p6_A = NamedProc "p6_A" 
       (Seq (Prefix (ID "e1") SKIP) (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP) [ID "e2"]))


-- Sequential composition with Sequential composition 
p6_B = NamedProc "p6_B" 
        (Seq (Prefix (ID "e1") SKIP) (Seq (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)))


-- Sequential composition
p6_C = NamedProc "p6_C" 
        (Seq  (Prefix (ID "e1") (ProcID "p6_C"))  (Prefix (ID "e1") (ProcID "p6_C")))   
        
        
-- Sequential composition
p6_D = NamedProc "p6_D" 
                 (Seq 
                     (Timeout (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) 2)
                     (Timeout (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) 2)
                 )


-- Sequential composition  
p6_E = NamedProc "p6_E" 
                 (Seq (Prefix (ID "e1") SKIP) (Interrupt (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)))


-- Sequential composition
p6_F = NamedProc "p6_F" 
                 (Seq (EDeadline (ID "e1") 3)  (EDeadline (ID "e1") 3))
        

-- Sequential composition
p6_G = NamedProc "p6_G" 
                 (Seq  (Hiding (Prefix (ID "e1") SKIP) [(ID "e1")])  (Hiding (Prefix (ID "e2") SKIP) [(ID "e1")]))
        

-- Sequential composition
p6_H = NamedProc "p6_H" 
                 (Seq  (Rename (Prefix (ID "e1") SKIP) [((ID "e1"), (ID "e3"))])  
                       (Rename (Prefix (ID "e1") SKIP) [((ID "e1"), (ID "e3"))])
                 )


-- Sequential composition        
p6_J = NamedProc "p6_J" 
                 (Seq  
                    (Prefix (ID "e1") SKIP)
                    (Exception (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) [ID "e1"])  
                 )
        


-- Recursive process -------------------------------------------------------------------------  
-- todo

-- P7_0



-- Interrupt -------------------------------------------------------------------------  

-- Interrupt 
p8_0 = NamedProc "p8_0" (Interrupt 
                             (Prefix (ID "e1") STOP)  
                             (Prefix (ID "e2") STOP)
                        )


-- Interrupt 
p8_1 = NamedProc "p8_1" (Interrupt 
                             (Prefix (ID "e1") Stopu) 
                             (Prefix (ID "e2") Stopu)
                        )


-- Interrupt 
p8_2 = NamedProc "p8_2" (Interrupt 
                            (Prefix (ID "e1") SKIP) 
                            (Prefix (ID "e2") SKIP)
                        )


-- Interrupt 
p8_3 = NamedProc "p8_3" (Interrupt 
                            (Prefix (ID "e1") Skipu) 
                            (Prefix (ID "e2") Skipu)
                        )


-- Interrupt 
p8_4 = NamedProc "p8_4" (Interrupt 
                            (Prefix (ID "e1") (WAIT 1)) 
                            (Prefix (ID "e2") (WAIT 2))
                        )


-- Interrupt 
p8_5 = NamedProc "p8_5" (Interrupt 
                            (Prefix (ID "e1") (Waitu 1)) 
                            (Prefix (ID "e2") (Waitu 2))
                        )


-- Interrupt with prefix
-- np8_6 = NamedProc "p26" (Interrupt (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))
-- Internal choice with prefix 
-- E? Invalid syntax, (p1 |~| p2) -> p


-- Interrupt with Internal choice
p8_7  = NamedProc "p8_7" (Interrupt 
                            (Prefix (ID "e2") SKIP) 
                            (IntChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP))
                         )


-- Interrupt with External choice
p8_8 = NamedProc "p8_8" (Interrupt 
                            (Prefix (ID "e1") SKIP) 
                            (ExtChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP))
                        )


-- Interrupt with Interleave 
p8_9 = NamedProc "p8_9" (Interrupt 
                            (Prefix (ID "e1") SKIP) 
                            (Interleave (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP))
                        )


-- Interrupt with Generallise parallel 
p8_A = NamedProc "p8_A" (Interrupt 
                            (Prefix (ID "e1") SKIP) 
                            (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP) [ID "e2"])
                        )


-- Interrupt with Interruptuential composition 
p8_B = NamedProc "p8_B" (Interrupt 
                            (Prefix (ID "e1") SKIP) 
                            (Seq (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))
                        )


-- Interrupt
p8_C = NamedProc "p8_C" (Interrupt  
                            (Prefix (ID "e1") (ProcID "p8_C"))  
                            (Prefix (ID "e1") (ProcID "p8_C"))
                        )   
        
        
-- Interrupt
p8_D = NamedProc "p8_D" (Interrupt 
                            (Timeout (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) 2)
                            (Timeout (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) 2)
                        )


-- Interrupt  
p8_E = NamedProc "p8_E" (Interrupt 
                            (Prefix (ID "e1") SKIP) 
                            (Interrupt (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))
                        )


-- Interrupt
p8_F = NamedProc "p8_F" (Interrupt 
                            (EDeadline (ID "e1") 3)  
                            (EDeadline (ID "e1") 3)
                        )
        

-- Interrupt
p8_G = NamedProc "p8_G" (Interrupt  
                            (Hiding (Prefix (ID "e1") SKIP) [(ID "e1")])  
                            (Hiding (Prefix (ID "e2") SKIP) [(ID "e1")])
                        )
        

-- Interrupt
p8_H = NamedProc "p8_H" (Interrupt 
                            (Rename (Prefix (ID "e1") SKIP) [((ID "e1"), (ID "e3"))])
                            (Rename (Prefix (ID "e1") SKIP) [((ID "e1"), (ID "e3"))])
                        )


-- Interrupt        
p8_J = NamedProc "p8_J" (Interrupt  
                            (Prefix (ID "e1") SKIP)
                            (Exception (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) [ID "e1"])  
                        )
        


-- Timeout  -------------------------------------------------------------------------------------
p9_0 = NamedProc "p9_0" 
                 (Timeout 
                     (Prefix (ID "e1") STOP)  
                     (Prefix (ID "e1") STOP)
                     2                      
                  )


-- Example 0.5 
p9_1 = NamedProc "p9_1" 
                 (Timeout 
                    (Prefix (ID "e1") Stopu) 
                    (Prefix (ID "e1") Stopu)
                    2
                 )


-- Example 0.5 
p9_2 = NamedProc "p9_2" 
                 (Timeout 
                    (Prefix (ID "e1") SKIP)  
                    (Prefix (ID "e2") SKIP)
                    2
                 )


-- Example 0.5 
p9_3 = NamedProc "p9_3" 
                 (Timeout 
                    (Prefix (ID "e1") Skipu) 
                    (Prefix (ID "e2") Skipu)
                    2
                 )


-- Example 0.5 
p9_4 = NamedProc "p9_4" 
                 (Timeout 
                    (Prefix (ID "e1") (WAIT 1)) 
                    (Prefix (ID "e2") (WAIT 2))
                    2
                 )


-- Example 0.5 
p9_5 = NamedProc "p9_5" 
                 (Timeout 
                    (Prefix (ID "e1") (Waitu 2)) 
                    (Prefix (ID "e2") (Waitu 2))
                    2                    
                    )


-- Example 0.5 
-- p9_6 = NamedProc "p9_6" (Timeout (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))
-- Internal choice with prefix 
-- E? Invalid syntax, (p1 |~| p2) -> p


-- Example 2.2: Timeout with Internal choice
p9_7  = NamedProc "p9_7" 
                  (Timeout 
                       (Prefix (ID "e2") SKIP) 
                       (IntChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP))
                       2
                  )


-- Example 2.3: Timeout with External choice
p9_8 = NamedProc "p9_8" 
                 (Timeout 
                    (Prefix (ID "e1") SKIP) 
                    (ExtChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP))
                    2
                 )


-- Example 2.4: Timeout with Interleave 
p9_9 = NamedProc "p9_9" 
                 (Timeout 
                    (Prefix (ID "e1") SKIP) 
                    (Interleave (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP))
                    2
                 )

-- Example 2.5: Timeout with Generallise parallel____ 
p9_A = NamedProc "p9_A" 
                 (Timeout 
                    (Prefix (ID "e1") SKIP) 
                    (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP) [ID "e2"])
                    2
                 )


-- Example 2.6: Timeout with Sequential composition 
p9_B = NamedProc "p9_B" 
                 (Timeout 
                    (Prefix (ID "e1") SKIP) 
                    (Seq (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))
                    2
                 )


--  Timeout with recursive process 
p9_C = NamedProc "p9_C" 
                 (Timeout  
                    (Prefix (ID "e1") (ProcID "p9_C"))  
                    (Prefix (ID "e1") (ProcID "p9_C"))
                    2
                 )   
        
--  Timeout with Timeout
p9_D = NamedProc "p9_D" 
                   (Timeout 
                        (Timeout (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) 2)
                        (Timeout (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) 2)
                        2
                   )



-- Example 2.7: Timeout with Interrupt  
p9_E = NamedProc "p9_E" 
                 (Timeout 
                    (Prefix (ID "e1") SKIP) 
                    (Interrupt (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))
                    2
                 )

--  Timeout with  Event deadline
p9_F = NamedProc "p9_F" 
                 (Timeout 
                    (EDeadline (ID "e1") 3)  
                    (EDeadline (ID "e1") 3)
                    2
                 )
        

--  Timeout with hiding
p9_G = NamedProc "p9_G" 
                 (Timeout  
                     (Hiding (Prefix (ID "e1") SKIP) [(ID "e1")])  
                     (Hiding (Prefix (ID "e2") SKIP) [(ID "e1")])
                     2
                 )
        
--  Timeout with renaming        
p9_H = NamedProc "p9_H" 
                 (Timeout  
                    (Rename (Prefix (ID "e1") SKIP) [((ID "e1"), (ID "e3"))])
                    (Rename (Prefix (ID "e1") SKIP) [((ID "e1"), (ID "e3"))])
                    2
                 )


--  Timeout with exception        
p9_J = NamedProc "p9_J" 
                 (Timeout
                    (Prefix (ID "e1") SKIP)
                    (Exception (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) [ID "e1"])  
                    2
                 )
        
        
-- Hiding -------------------------------------------------------------------------------------

-- Hiding with deadlock
pA_0  = NamedProc "pA_0" 
                  (Hiding (Prefix (ID "e1") STOP) [(ID "e1")])


-- Hiding with urgent deadlock
pA_1  = NamedProc "pA_1" 
                  (Hiding (Prefix (ID "e1") Stopu) [(ID "e1")])


-- Hiding with termination
pA_2  = NamedProc "pA_2" 
                  (Hiding (Prefix (ID "e1") SKIP) [(ID "e1")])
                  

-- Hiding with urgent termination
pA_3  = NamedProc "pA_3" 
                  (Hiding (Prefix (ID "e1") Skipu) [(ID "e1")])
                  
-- Hiding with delay
pA_4  = NamedProc "pA_4" 
                  (Hiding (Prefix (ID "e1") (WAIT 2)) [(ID "e1")])


-- Hiding with strict delay
pA_5  = NamedProc "pA_5" 
                  (Hiding (Prefix (ID "e1") (Waitu 2)) [(ID "e1")])

                  
-- Hiding with prefix
pA_6  = NamedProc "pA_6" 
                  (Hiding (Prefix (ID "e1") SKIP) [(ID "e1")])
                  

-- Hiding with Internal choice 
pA_7  = NamedProc   "A_7" 
                     (Hiding (IntChoice (Prefix (ID "e1") SKIP) (Prefix (ID "e1") SKIP)) 
                             [(ID "e1")])
                  
-- Hiding with External choice 
pA_8  = NamedProc   "A_8" 
                     (Hiding (ExtChoice (Prefix (ID "e1") SKIP) (Prefix (ID "e1") SKIP)) 
                             [(ID "e1")])
                  

-- Hiding with Interleave 
pA_9  = NamedProc "pA_9" 
                  (Hiding (Interleave (Prefix (ID "e1") SKIP) (Prefix (ID "e1") SKIP))  
                  [(ID "e1")] )


-- Hiding with Generallise parallel 
pA_A   = NamedProc  "pA_A" 
                    (Hiding (GenPar (Prefix (ID "e2") SKIP) 
                                    (Prefix (ID "e2") SKIP) 
                                    [ID "e2"]) 
                            [(ID "e2")]  
                    )
                    
                    
-- Hiding with Sequential composition
pA_B  = NamedProc "pA_B" 
                  (Hiding (Seq (Prefix (ID "e1") SKIP) (Prefix (ID "e1") SKIP))  
                          [(ID "e1")] )
                    

-- Hiding with recursive process
pA_C  = NamedProc "pA_C" 
                  (Hiding (Prefix (ID "e1") (ProcID "pA_C") )  
                          [(ID "e1")] )
                          

-- Hiding with recursive process
pA_D  = NamedProc "pA_D" 
                  (Hiding  (Timeout (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) 2)
                           [(ID "e1")] )
                           
                      
                      
-- Hiding with Interrupt
pA_E  = NamedProc "pA_E" 
                  (Hiding  (Interrupt (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)
                           [(ID "e1")] )


-- Hiding with event deadline
pA_F  = NamedProc "pA_F" 
                  (Hiding  (EDeadline (ID "e1") 3) 
                           [(ID "e1")] )
        


-- Hiding with event deadline
pA_G  = NamedProc "pA_G" 
                  (Hiding  (Hiding (Prefix (ID "e1") SKIP) [(ID "e1")]) 
                           [(ID "e1")] )


-- Hiding with event renaming
pA_H  = NamedProc "pA_H" 
                  (Hiding  (Rename (Prefix (ID "e1") SKIP) [((ID "e1"), (ID "e3"))])
                           [(ID "e3")] )

-- Hiding with exception
pA_J  = NamedProc "pA_J" 
                  (Hiding  (Exception (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) [ID "e1"])  
                           [(ID "e3")] )


--  Rename  ----------------------------------------------------------

-- Rename with deadlock
pB_0  = NamedProc "pA_0" 
                  (Rename (Prefix (ID "e1") STOP) 
                          [((ID "e1"), (ID "e3"))])


-- Rename with urgent deadlock
pB_1  = NamedProc "pA_1" 
                  (Rename (Prefix (ID "e1") Stopu) 
                          [((ID "e1"), (ID "e3"))])


-- Rename with termination
pB_2  = NamedProc "pA_2" 
                  (Rename (Prefix (ID "e1") SKIP) 
                          [((ID "e1"), (ID "e3"))])
                  

-- Rename with urgent termination
pB_3  = NamedProc "pA_3" 
                  (Rename (Prefix (ID "e1") Skipu) 
                          [((ID "e1"), (ID "e3"))])
                  
-- Rename with delay
pB_4  = NamedProc "pA_4" 
                  (Rename (Prefix (ID "e1") (WAIT 2)) 
                          [((ID "e1"), (ID "e3"))])


-- Rename with strict delay
pB_5  = NamedProc "pA_5" 
                  (Rename (Prefix (ID "e1") (Waitu 2)) 
                          [((ID "e1"), (ID "e3"))])

                  
-- Rename with prefix
pB_6  = NamedProc "pA_6" 
                  (Rename (Prefix (ID "e1") SKIP) 
                          [((ID "e1"), (ID "e3"))])
                  

-- Rename with Internal choice 
pB_7  = NamedProc "A_7" 
                  (Rename (IntChoice (Prefix (ID "e1") SKIP) (Prefix (ID "e1") SKIP)) 
                          [((ID "e1"), (ID "e3"))])
                  
-- Rename with External choice 
pB_8  = NamedProc "A_8" 
                  (Rename (ExtChoice (Prefix (ID "e1") SKIP) (Prefix (ID "e1") SKIP)) 
                          [((ID "e1"), (ID "e3"))])
                  

-- Rename with Interleave 
pB_9  = NamedProc "pA_9" 
                  (Rename (Interleave (Prefix (ID "e1") SKIP) (Prefix (ID "e1") SKIP))  
                          [((ID "e1"), (ID "e3"))])


-- Rename with Generallise parallel 
pB_A   = NamedProc  "pA_A" 
                    (Rename (GenPar (Prefix (ID "e2") SKIP) 
                                    (Prefix (ID "e2") SKIP) 
                                    [ID "e2"]) 
                            [((ID "e2"), (ID "e3"))]
                    )
                    
                    
-- Rename with Sequential composition
pB_B  = NamedProc "pA_B" 
                  (Rename (Seq (Prefix (ID "e1") SKIP) (Prefix (ID "e1") SKIP))  
                          [((ID "e1"), (ID "e3"))])
                    

-- Rename with recursive process
pB_C  = NamedProc "pA_C" 
                  (Rename (Prefix (ID "e1") (ProcID "pA_C") )  
                          [((ID "e1"), (ID "e3"))]
                  )
                          

-- Rename with timeout process
pB_D  = NamedProc "pA_D" 
                  (Rename  (Timeout (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) 2)
                           [((ID "e1"), (ID "e3"))]
                  )
                           
                      
                      
-- Rename with Interrupt
pB_E  = NamedProc "pA_E" 
                  (Rename  (Interrupt (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)
                           [((ID "e1"), (ID "e3"))])


-- Rename with event deadline
pB_F  = NamedProc "pA_F" 
                  (Rename  (EDeadline (ID "e1") 3) 
                           [((ID "e1"), (ID "e3"))]
                  )
        


-- Rename with event deadline
pB_G  = NamedProc "pA_G" 
                  (Rename  (Hiding (Prefix (ID "e1") SKIP) [(ID "e1")]) 
                           [((ID "e1"), (ID "e3"))]
                  )


-- Rename with renaming
pB_H  = NamedProc "pA_H" 
                  (Rename  (Rename (Prefix (ID "e1") SKIP) [((ID "e1"), (ID "e3"))])
                           [((ID "e1"), (ID "e3"))]
                  )

-- Rename with exception
pB_J  = NamedProc "pA_J" 
                  (Rename  (Exception (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) [ID "e1"])  
                           [((ID "e1"), (ID "e3"))]
                  )


                           

--  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- Hiding a single events in np***, multiple events np***m and empty events np***e

-- Hiding with prefix
np10_1  = NamedProc "p10_1" 
         (Hiding (Prefix (ID "e1") SKIP) [(ID "e1")])
         
-- Hiding multiple events
np10_1m  = NamedProc "p10_1m" 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1"), (ID "e2") ])

-- Hiding empty events
np10_1e  = NamedProc "p10_1e" 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [ ])
         

-- Example 3.2: Hiding with Internal choice 
np10_2  = NamedProc   "p10_2" 
         (Hiding (IntChoice (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) [(ID "e1")]  )

np10_2m  = NamedProc   "p10_2m" 
         (Hiding (IntChoice (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) [(ID "e1"), (ID "e2")] )

np10_2e  = NamedProc   "p10_2e" 
         (Hiding (IntChoice (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) []  )


-- Example 3.3: Hiding with External choice 
np10_3  = NamedProc "p10_3" 
         (Hiding (ExtChoice (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) [(ID "e1")]  )
         
np10_3m  = NamedProc "p10_3m" 
         (Hiding (ExtChoice (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) [(ID "e1"), (ID "e2")]  )

np10_3e  = NamedProc "p10_3e" 
         (Hiding (ExtChoice (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) [ ]  )
         

-- Example 3.4: Hiding with Interleave 
np10_4  = NamedProc "p10_4" 
         (Hiding (Interleave (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))  [(ID "e1")] )

np10_4m  = NamedProc "p10_4m" 
         (Hiding (Interleave (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))  [(ID "e1"), (ID "e1")] )

np10_4e  = NamedProc "p10_4e" 
         (Hiding (Interleave (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))  [ ] )


-- Example 3.5: Hiding with Generallise parallel 
np10_5   = NamedProc   "p10_5" 
         (Hiding (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP) [ID "e2"]) [(ID "e2")]  )

np10_5m  = NamedProc   "p10_5m" 
         (Hiding (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP) [ID "e2"]) [(ID "e2"), (ID "e2")]  )

np10_5e  = NamedProc   "p10_5e" 
         (Hiding (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP) [ID "e2"]) [ ]  )


-- Example 3.6: Hiding with Sequential composition 
np10_6   = NamedProc "p10_6" 
         (Hiding (Seq (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))  [(ID "e1")]  )

np10_6m  = NamedProc "p10_6m" 
         (Hiding (Seq (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))  [(ID "e1"), (ID "e2")]  )

np10_6e  = NamedProc "p10_6e" 
         (Hiding (Seq (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))  [ ]  )


-- Example 3.7: Hiding with Sequential composition 
np10_7   = NamedProc "p10_7" 
         (Hiding (Interrupt (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))  [(ID "e1")]    )

np10_7m  = NamedProc "p10_7m" 
         (Hiding (Interrupt (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))  [(ID "e1"), (ID "e2")]    )

np10_7e  = NamedProc "p10_7e" 
         (Hiding (Interrupt (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))  [ ]    )


-- Additional examples for hiding in one side of binary operators   -----------
-- The examples involve hiding single event, multiple events and empty events

-- Example 3.2: Hiding in one side of internal choice 
np10_2s   = NamedProc   "p10_2s" 
         (IntChoice 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1")])
         (Prefix (ID "e2") SKIP))

np10_2ms  = NamedProc   "p10_2ms" 
         (IntChoice 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1"), (ID "e2")])
         (Prefix (ID "e2") SKIP))

np10_2es  = NamedProc   "p10_2es" 
         (IntChoice 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [ ])
         (Prefix (ID "e2") SKIP))


-- Example 3.3: Hiding in one side of external choice 
np10_3s  = NamedProc "p10_3s" 
         (ExtChoice 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1")])
         (Prefix (ID "e2") SKIP))
         
np10_3ms  = NamedProc "p10_3ms" 
         (ExtChoice 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1"), (ID "e2")])
         (Prefix (ID "e2") SKIP))


np10_3es  = NamedProc "p10_3es" 
         (ExtChoice 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [ ])
         (Prefix (ID "e2") SKIP))
         

-- Example 3.4: Hiding in one side of Interleave
np10_4s  = NamedProc "p10_4" 
         (Interleave
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1")])
         (Prefix (ID "e2") SKIP))         

np10_4ms  = NamedProc "p10_4m" 
         (Interleave 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1"), (ID "e2")])
         (Prefix (ID "e2") SKIP))


np10_4es  = NamedProc "p10_4e" 
         (Interleave 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [])
         (Prefix (ID "e2") SKIP))


-- Example 3.5: Hiding in one side of Generallise parallel 
np10_5s   = NamedProc   "p10_5" 
         (GenPar
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1"), (ID "e2")])
         (Prefix (ID "e2") SKIP)
         [(ID "e2")] 
         )

np10_5ms  = NamedProc   "p10_5m" 
         (GenPar
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1"), (ID "e2")])
         (Prefix (ID "e2") SKIP)
         [(ID "e2")] 
         )

np10_5es  = NamedProc   "p10_5e" 
         (GenPar
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [])
         (Prefix (ID "e2") SKIP)
         [(ID "e2")] 
         )



-- Example 3.6: Hiding in one side of sequential composition 
np10_6s   = NamedProc "p10_6" 
         (Seq 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1")])
         (Prefix (ID "e2") SKIP)
         )

np10_6ms  = NamedProc "p10_6m" 
         (Seq 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1"), (ID "e2")])
         (Prefix (ID "e2") SKIP)
         )

np10_6es  = NamedProc "p10_6e" 
         (Seq 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [])
         (Prefix (ID "e2") SKIP)
         )


-- Example 3.7: Hiding in one side of Interrupt composition 
np10_7s   = NamedProc "p10_7" 
         (Interrupt 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1")])
         (Prefix (ID "e2") SKIP)
         )


np10_7ms  = NamedProc "p10_7m" 
         (Interrupt
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1"), (ID "e2")])
         (Prefix (ID "e2") SKIP)
         )

np10_7es  = NamedProc "p10_7e" 
         (Interrupt
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [] )
         (Prefix (ID "e2") SKIP)
         )





--  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- Example 3.1 : External choice with prefix 
-- E? Invalid syntax, (p1 [] p2) -> p

 -- Example 0.6 
p3_1 = NamedProc "p0_6" (ExtChoice (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))


-- Example 3.2: External choice with Internal choice 
p3_2  = NamedProc  "p3_2" 
                   (ExtChoice (Prefix (ID "e1") SKIP) (IntChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


-- Example 3.3: External choice with External choice 
p3_3  = NamedProc "p3_3" 
                  (ExtChoice (Prefix (ID "e1") SKIP) (ExtChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


-- Example 3.4: External choice with Interleave 
p3_4  = NamedProc "p3_4" 
                  (ExtChoice (Prefix (ID "e1") SKIP) 
                              (Interleave (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP)))


-- Example 3.5: External choice with Generallise parallel 
p3_5  = NamedProc "p3_5" 
                  (ExtChoice (Prefix (ID "e1") SKIP) 
                                (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP) [ID "e2"]))


-- Example 3.6: External choice with Sequential composition 
p3_6  = NamedProc "p3_6" 
                  (ExtChoice (Prefix (ID "e1") SKIP) 
                              (Seq (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


-- Example 3.7: External choice with Sequential composition 
p3_7  = NamedProc "p3_7" 
                  (ExtChoice (Prefix (ID "e1") SKIP) 
                              (Interrupt (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


-- ????????? Complete the remaining combination
-- Example 3.7: External choice with 
p3_8  = NamedProc "p3_8" 


--04  Interleave ----------------------------------------------------------------------------------------

-- Example  : Interleave with deadlock
p4_0 = NamedProc "p4_0" (Interleave (Prefix (ID "e1") STOP) (Prefix (ID "e1") STOP))


-- Example  : Interleave with urgent deadlock
p4_1 = NamedProc "p4_1" (Interleave (Prefix (ID "e1") Stopu) (Prefix (ID "e1") Stopu))


-- Example  : Interleave with termination
p4_2 = NamedProc "p4_2" (Interleave (Prefix (ID "e1") SKIP) (Prefix (ID "e1") SKIP))


-- Example  : Interleave with urgent termination
p4_3 = NamedProc "p4_3" (Interleave (Prefix (ID "e1") Skipu) (Prefix (ID "e1") Skipu))


-- Example  : Interleave with delay
p4_4 = NamedProc "p4_4" (Interleave (Prefix (ID "e1") (WAIT 2)) (Prefix (ID "e1") (WAIT 2)))


-- Example  : Interleave with urgent delay
p4_5 = NamedProc "p4_5" (Interleave (Prefix (ID "e1") (Waitu 2)) (Prefix (ID "e1") (Waitu 2)))


-- Example 4.1 : Interleave with prefix 
-- P46 = Invalid syntax,  (p1 [] p2) -> p


-- Example 4.2: Interleave with Internal choice 
p4_7  = NamedProc "p4_7" 
                  (Interleave (Prefix (ID "e1") SKIP) (IntChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


-- Example 4.3: Interleave with External choice
p4_8  = NamedProc  "p4_8" 
                   (Interleave (Prefix (ID "e1") SKIP) (ExtChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


-- Example 4.4: Interleave with Interleave 
p4_9  = NamedProc  "p4_9" 
                   (Interleave (Prefix (ID "e1") SKIP) (Interleave (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP)))

-- Example 4.5: Interleave with Generallise parallel 
p4_A  = NamedProc "p4_A" 
                  (Interleave (Prefix (ID "e1") SKIP) 
                              (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP) [ID "e2"]))


-- Example 4.6: Interleave with  Sequential composition
p4_B  = NamedProc  "p4_B" 
                   (Interleave (Prefix (ID "e1") SKIP) 
                               (Seq (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))

-- Example 4.7: Interleave with Interrupt 
p4_C  = NamedProc  "p4_C" 
                   (Interleave (Prefix (ID "e1") SKIP) 
                               (Interrupt (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))

-- Example 4.D: Interleave with Interrupt 
p4_D  = NamedProc  "p4_D" 
                   (Interleave (Timeout (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) 2)
                               (Timeout (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) 2))

-- Example 4.7: Interleave with Interleave 
p4_E  = NamedProc  "p4_E" 
                   (Interleave (Prefix (ID "e1") SKIP) 
                               (Interleave (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))

--05 Generallise parallel

-- Example 5.1 : Interleave with prefix 
-- E? Invalid syntax, (p1 [] p2) -> p

-- Example 0.9 
np0_9 = NamedProc "p0_9" (GenPar (Prefix (ID "e1") SKIP) (Prefix (ID "e1") SKIP) [ID "e1"])


-- Example 5.2: Generallise parallel with Internal choice----------------------------------------------
np5_2  = NamedProc  "p5_2" 
         (GenPar (Prefix (ID "e1") SKIP) (IntChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e1") SKIP)) [ID "e1"])

-- Example 5.3: Generallise parallel with External choice----------------------------------------------
np5_3  = NamedProc  "p5_3" 
         (GenPar (Prefix (ID "e2") SKIP) (ExtChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e1") SKIP)) [ID "e2"]) 


-- Example 5.4: Generallise parallel with Interleave --------------------------------------------------
np5_4  = NamedProc  "p5_4" 
         (GenPar (Prefix (ID "e2") SKIP) (Interleave (Prefix (ID "e2") SKIP) (Prefix (ID "e1") SKIP)) [ID "e2"])


-- Example 5.4a: Generallise parallel with Interleave --------------------------------------------------
-- p5_4a = (e2-> (SKIP))[|{e2}|]((e2-> (e3-> (SKIP)))|||(e2-> (e4-> (SKIP))))

np5_4a  = NamedProc  "p5_4a" 
--         (GenPar (Prefix (ID "e2") SKIP) (Interleave (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP)) [])
          (GenPar (Prefix (ID "e2") SKIP) (Interleave (Prefix (ID "e2") (Prefix (ID "e3") SKIP)) (Prefix (ID "e2") (Prefix (ID "e4") SKIP))) [ID "e2"])


-- Example 5.4a: Generallise parallel with Interleave --------------------------------------------------
np5_4b  = NamedProc  "p5_4b" 
          (GenPar (Prefix (ID "e2") (Prefix (ID "e2") SKIP)) (Interleave (Prefix (ID "e2") (Prefix (ID "e3") SKIP)) (Prefix (ID "e2") (Prefix (ID "e4") SKIP))) [ID "e2"])


-- Example 5.5: Generallise parallel with Generallise parallel ----------------------------------------
np5_5  =  NamedProc "p5_5" 
          (GenPar (Prefix (ID "e2") SKIP) (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP) [ID "e2"]) [ID "e2"])


-- Example 5.6: Generallise parallel with Sequential composition --------------------------------------
-- p5_6 = (e1-> (SKIP))[|{e2}|]((e2-> (SKIP));(e3-> (SKIP)))
np5_6  =  NamedProc  "p5_6" 
          (GenPar (Prefix (ID "e1") SKIP) (Seq (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) [ID "e1"])

-- Example 5.6: Generallise parallel with Interrupt-----------------------------------------------------
np5_7  =  NamedProc  "p5_7" 
          (GenPar (Prefix (ID "e1") SKIP) (Interrupt (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) [ID "e1"])


-- Additional test examples for synchronisations
---------------------------------------------------------------------------
-- P01:  (cs->SKIP)[|{}|]((cs->SKIP) [|{}](cs->SKIP))  -- P ||| (Q ||| S)
nsp6_1   = NamedProc "sp6_1" (GenPar (Prefix (ID "cs") SKIP) (GenPar (Prefix (ID "cs") SKIP) 
          (Prefix (ID "cs") SKIP) []) [])

---------------------------------------------------------------------------
-- P02: ((cs->SKIP)[|{}|] (cs->SKIP))[|{}](cs->SKIP)  -- (P ||| Q) ||| S
nsp6_2  = NamedProc "sp6_2" (GenPar (GenPar (Prefix (ID "cs") SKIP) 
          (Prefix (ID "cs") SKIP) []) (Prefix (ID "cs") SKIP) [])

---------------------------------------------------------------------------
-- P03:  (cs->SKIP)[|{cs}|]((cs->SKIP) [|{}](cs->SKIP))  -- P |[{cs}]| (Q ||| S)
nsp6_3  = NamedProc "sp6_3" (GenPar (Prefix (ID "cs") SKIP) (GenPar (Prefix (ID "cs") SKIP) 
          (Prefix (ID "cs") SKIP) [ID "cs"]) [])

---------------------------------------------------------------------------
-- P04: ((cs->SKIP)[|{cs}|] (cs->SKIP))[|{}|](cs->SKIP)  -- (P |[{cs}]| Q) ||| S
nsp6_4  = NamedProc  "sp6_4" (GenPar (GenPar (Prefix (ID "cs") SKIP) 
          (Prefix (ID "cs") SKIP) [ID "cs"]) (Prefix (ID "cs") SKIP) [])


---------------------------------------------------------------------------
-- P05:  (cs->SKIP)[|{}|]((cs->SKIP) [|{cs}](cs->SKIP)) -- P ||| (Q |[{cs}]| S)
nsp6_5  = NamedProc "sp6_5" (GenPar (Prefix (ID "cs")     SKIP) 
         (GenPar (Prefix (ID "cs") SKIP)(Prefix (ID "cs") SKIP) [] ) [ID "cs"])


---------------------------------------------------------------------------
-- P06: ((cs->SKIP)[|{}|] (cs->SKIP))[|{cs}](cs->SKIP) -- -- (P ||| Q) |[{cs}]| S
nsp6_6  = NamedProc "sp6_6" (GenPar (GenPar (Prefix (ID "cs") SKIP) 
          (Prefix (ID "cs") SKIP) []) 
          (Prefix (ID "cs") SKIP) [ID "cs"])

---------------------------------------------------------------------------
-- PO7:  (cs->SKIP)[|{cs}|]((cs->SKIP) [|{cs}](cs->SKIP))  --  P |[{cs}]| (Q |[{cs}]| S)
nsp6_7  = NamedProc  "sp6_7" (GenPar (Prefix (ID "cs") SKIP) (GenPar (Prefix (ID "cs") SKIP) 
          (Prefix (ID "cs") SKIP) [ID "cs"]) [ID "cs"])


---------------------------------------------------------------------------
-- P08: ((cs->SKIP)[|{cs}|](cs->SKIP))[|{cs}](cs->SKIP)   --  (P |[{cs}]| Q) |[{cs}]| S
nsp6_8  = NamedProc "sp6_8" (GenPar (GenPar (Prefix (ID "cs") SKIP) 
          (Prefix (ID "cs") SKIP) [ID "cs"]) (Prefix (ID "cs") SKIP) [ID "cs"])

---------------------------------------------------------------------------
-- P09: ((cs->SKIP)[|{cs}|] (cs->SKIP))|||((cs1->SKIP)[|{cs1}|] (cs1->SKIP)) -- --  (P |[{cs}]| Q) ||\ (R |[{cs1}]| S)
nsp6_9  = NamedProc "sp6_9" (GenPar (GenPar (Prefix (ID "cs" ) SKIP) (Prefix (ID "cs" ) SKIP) [ID "cs" ]) 
          (GenPar (Prefix (ID "cs1") SKIP) (Prefix (ID "cs1") SKIP) [ID "cs1"]) [])


---------------------------------------------------------------------------
-- P10: ((cs->SKIP)[|{cs}|] (cs->SKIP))|||((cs->SKIP)[|{cs}|] (cs->SKIP))  -- (P |[{cs}]| Q) ||\ (R |[{cs}]| S)
nsp6_10  = NamedProc "sp6_10" (GenPar (GenPar (Prefix (ID "cs") SKIP) (Prefix (ID "cs") SKIP) [ID "cs"]) 
           (GenPar (Prefix (ID "cs") SKIP) (Prefix (ID "cs") SKIP) [ID "cs"]) [])

---------------------------------------------------------------------------
-- Todo: investigate infinite recursive concurrent
-- P1 = e1 -> e2 -> e1 -> e2 -> e1 -> P1     -- Infinite interleaving
-- pP1 = P1 ||| P1   

p6_11   =  (Prefix (ID "e1") (Prefix (ID "e2") (Prefix (ID "e1")  (Prefix (ID "e2") 
           (Prefix (ID "e1") SKIP )))))

nsp6_11 =  NamedProc  "sp6_11" (GenPar p6_11  p6_11  [] )


-- p6_11   =  NamedProc  "p6_11" (Prefix (ID "e1") (Prefix (ID "e2") (Prefix (ID "e1")  (Prefix (ID "e2") 
--           (Prefix (ID "e1") (ProcID "p6_11" ))))))

-- nsp6_11 =  NamedProc  "sp6_11" (GenPar (ProcID "p6_11")  (ProcID "p6_11")  [] )

---------------------------------------------------------------------------------------------------------
-- P1 = e1 -> e2 -> e1 -> e2 -> e1 -> P1    -- Infinite concurrency with single synchronisation
-- pP2 = P1 [|{e1}|]  P1   
nsp6_12 =  NamedProc  "sp6_12" (GenPar p6_11  p6_11  [ID "e1"] )
-- nsp6_12 =  NamedProc  "sp6_12" (GenPar (ProcID "p6_11")  (ProcID "p6_11")  [ID "e1"] )

---------------------------------------------------------------------------------------------------------
-- P1 = e1 -> e2 -> e1 -> e2 -> e1 -> P1   --  Infinite concurrency with multiple synchronisation
-- pP3 = P1 [|{e1, e2}|]  P1   

nsp6_13 =  NamedProc  "sp6_13" (GenPar  p6_11  p6_11  [ID "e1", ID "e2"] )

-- nsp6_13 =  NamedProc  "sp6_13" (GenPar (ProcID "p6_11")  (ProcID "p6_11")  [ID "e1", ID "e2"] )


-- Example for illustrating traces with different permutation
----------------------------------------------------------------------------------------------          
-- fp1 = (e1 -> e1 -> e1 -> e1 -> e1 -> SKIP) [] (e2 -> SKIP)    -- Exploring traces with various lengths
           
nsp6_14  =  NamedProc  "sp6_14"  
             (ExtChoice ((Prefix (ID "e1") (Prefix (ID "e1") (Prefix (ID "e1")  (Prefix (ID "e1") 
             (Prefix (ID "e1") SKIP )))))) (Prefix (ID "e2") SKIP))


----------------------------------------------------------------------------------------------
-- pp2 = e1 -> e2 -> e1 -> e2 -> e1 -> SKIP    -- Exploring traces with various permutations
-- fp2 = P1 ||| P1   

nsp6_15  =  NamedProc  "sp6_15" (GenPar pp2 pp2 [])
pp2      =  (Prefix (ID "e1") (Prefix (ID "e2") (Prefix (ID "e1")  (Prefix (ID "e2") 
            (Prefix (ID "e1") SKIP )))))
           

----------------------------------------------------------------------------------------------
-- 07 Sequential Composition

-- Example 7.1 : Interleave with prefix 
-- E? Invalid syntax,  (p1 [] p2) -> p

-- Example 0.7 
np0_7 = NamedProc "p0_7" (Seq (Prefix (ID "e2") SKIP) (Prefix (ID "e1") SKIP))


-- Example 7.2: Sequential Composition with Internal choice 
np7_2  = NamedProc  "p7_2" 
         (Seq (Prefix (ID "e1") SKIP) (IntChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


-- Example 7.3: Sequential Composition with External choice
np7_3  = NamedProc  "p7_3" 
         (Seq   (Prefix (ID "e1") SKIP) (ExtChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


-- Example 7.4: Sequential Composition with Interleave 
np7_4  = NamedProc  "p7_4" 
         (Seq (Prefix (ID "e1") SKIP) (Interleave (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP)))

-- Example 7.5: Sequential Composition with Generallise parallel 
np7_5  = NamedProc  "p7_5" 
         (Seq (Prefix (ID "e1") SKIP) (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP) [ID "e2"]))


-- Example 4.6: Sequential Composition with Sequential composition 
np7_6  = NamedProc  "p7_6" 
         (Seq (Prefix (ID "e1") SKIP) (Seq (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


-- Example 4.6: Sequential Composition with Interrupt
np7_7  = NamedProc  "p7_7" 
         (Seq (Prefix (ID "e1") SKIP) (Interrupt (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


-- Interrupt  Examples  ---------------------------------------------

-- Example 8.1 : Interrupt with prefix 
-- E? Invalid syntax, (p1 /\ p2) -> p, but change as (p1 /\ p2)

-- Example 1.7: Prefix with Interrupt composition 
np1_7 = NamedProc "p1_7" (Prefix (ID "e1") (Interrupt (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) )


np8_1 = NamedProc "p8_1" (Interrupt (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) )
--np8_01 = NamedProc "p8_01" (Interrupt (Prefix (ID "e1") STOP) (Prefix (ID "e2") SKIP) )
-- np11 = (e1-> (STOP))/\(e2-> (SKIP))

-- Example 8.2: External choice with Internal choice 
np8_2  = NamedProc   "p8_2" 
         (Interrupt (Prefix (ID "e1") SKIP) (IntChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


-- Example 8.3: Interrupt with External choice 
np8_3  = NamedProc "p8_3" 
         (Interrupt (Prefix (ID "e1") SKIP) (ExtChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


-- Example 8.4: Interrupt with Interleave 
np8_4  = NamedProc "p8_4" 
         (Interrupt (Prefix (ID "e1") SKIP) (Interleave (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP)))


-- Example 8.5: Interrupt with Generallise parallel 
np8_5  = NamedProc   "p8_5" 
         (Interrupt (Prefix (ID "e1") SKIP) (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP) [ID "e2"]))

--np8_5  = NamedProc   "p8_5" 
--         (Interrupt (Prefix (ID "e1") SKIP) (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP) []))


-- Example 8.6: Interrupt with Sequential composition 
np8_6  = NamedProc "p8_6" 
         (Interrupt (Prefix (ID "e1") SKIP) (Seq (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))

-- Example 8.6: Interrupt with Sequential composition 
np8_7  = NamedProc "p8_7" 
         (Interrupt (Prefix (ID "e1") SKIP) (Interrupt (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


--09 Timeout Examples -------------------------------------------------------------------------  

-- Basic timeout
np9_1 = NamedProc "p9_1" (Timeout (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) 2 )


-- Example 9.1 : Timeout with prefix 
-- E? Invalid syntax, (p1 |~| p2) -> p

-- Example 9.2: Timeout with Internal choice
np9_2  = NamedProc "p9_2" 
        (Timeout (Prefix (ID "e2") SKIP) (IntChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)) 2)


-- Example 9.3: Timeout with External choice
np9_3 = NamedProc "p9_3" 
        (Timeout (Prefix (ID "e1") SKIP) (ExtChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)) 2)


-- Example 9.4: Timeout with Interleave 
np9_4 = NamedProc "p9_4" 
        (Timeout (Prefix (ID "e1") SKIP) (Interleave (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP)) 2)

-- Example 9.5: Timeout with Generallise parallel 
np9_5 = NamedProc "p9_5" 
        (Timeout (Prefix (ID "e1") SKIP) (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP) [ID "e2"]) 2)


-- Example 9.6: Timeout with Sequential composition 
np9_6 = NamedProc "p9_6" 
        (Timeout (Prefix (ID "e1") SKIP) (Seq (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))  2)


-- Example 9.7: Timeout with Interrupt  
np9_7 = NamedProc "p9_7" 
        (Timeout (Prefix (ID "e1") SKIP) (Interrupt (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) 2)


-- Example 9.8: Timeout with Timeout  
np9_8 = NamedProc "p9_8" 
        (Timeout (Prefix (ID "e1") SKIP) (Timeout (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) 1)  2)
-- p9_8 = (e1-> (SKIP))[5>((e1-> (SKIP))[3>(e2-> (SKIP)))


-- Hiding ---------------------------------------------------------------------------------
-- Hiding a single events in np***, multiple events np***m and empty events np***e

-- Hiding with prefix
np10_1  = NamedProc "p10_1" 
         (Hiding (Prefix (ID "e1") SKIP) [(ID "e1")])
         
-- Hiding multiple events
np10_1m  = NamedProc "p10_1m" 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1"), (ID "e2") ])

-- Hiding empty events
np10_1e  = NamedProc "p10_1e" 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [ ])
         


-- Example 3.2: Hiding with Internal choice 
np10_2  = NamedProc   "p10_2" 
         (Hiding (IntChoice (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) [(ID "e1")]  )

np10_2m  = NamedProc   "p10_2m" 
         (Hiding (IntChoice (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) [(ID "e1"), (ID "e2")] )

np10_2e  = NamedProc   "p10_2e" 
         (Hiding (IntChoice (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) []  )


-- Example 3.3: Hiding with External choice 
np10_3  = NamedProc "p10_3" 
         (Hiding (ExtChoice (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) [(ID "e1")]  )
         
np10_3m  = NamedProc "p10_3m" 
         (Hiding (ExtChoice (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) [(ID "e1"), (ID "e2")]  )

np10_3e  = NamedProc "p10_3e" 
         (Hiding (ExtChoice (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) [ ]  )
         

-- Example 3.4: Hiding with Interleave 
np10_4  = NamedProc "p10_4" 
         (Hiding (Interleave (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))  [(ID "e1")] )

np10_4m  = NamedProc "p10_4m" 
         (Hiding (Interleave (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))  [(ID "e1"), (ID "e1")] )

np10_4e  = NamedProc "p10_4e" 
         (Hiding (Interleave (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))  [ ] )


-- Example 3.5: Hiding with Generallise parallel 
np10_5   = NamedProc   "p10_5" 
         (Hiding (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP) [ID "e2"]) [(ID "e2")]  )

np10_5m  = NamedProc   "p10_5m" 
         (Hiding (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP) [ID "e2"]) [(ID "e2"), (ID "e2")]  )

np10_5e  = NamedProc   "p10_5e" 
         (Hiding (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP) [ID "e2"]) [ ]  )


-- Example 3.6: Hiding with Sequential composition 
np10_6   = NamedProc "p10_6" 
         (Hiding (Seq (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))  [(ID "e1")]  )

np10_6m  = NamedProc "p10_6m" 
         (Hiding (Seq (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))  [(ID "e1"), (ID "e2")]  )

np10_6e  = NamedProc "p10_6e" 
         (Hiding (Seq (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))  [ ]  )


-- Example 3.7: Hiding with Sequential composition 
np10_7   = NamedProc "p10_7" 
         (Hiding (Interrupt (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))  [(ID "e1")]    )

np10_7m  = NamedProc "p10_7m" 
         (Hiding (Interrupt (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))  [(ID "e1"), (ID "e2")]    )

np10_7e  = NamedProc "p10_7e" 
         (Hiding (Interrupt (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))  [ ]    )


-- Additional examples for hiding in one side of binary operators   -----------
-- The examples involve hiding single event, multiple events and empty events

-- Example 3.2: Hiding in one side of internal choice 
np10_2s   = NamedProc   "p10_2s" 
         (IntChoice 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1")])
         (Prefix (ID "e2") SKIP))

np10_2ms  = NamedProc   "p10_2ms" 
         (IntChoice 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1"), (ID "e2")])
         (Prefix (ID "e2") SKIP))

np10_2es  = NamedProc   "p10_2es" 
         (IntChoice 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [ ])
         (Prefix (ID "e2") SKIP))


-- Example 3.3: Hiding in one side of external choice 
np10_3s  = NamedProc "p10_3s" 
         (ExtChoice 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1")])
         (Prefix (ID "e2") SKIP))
         
np10_3ms  = NamedProc "p10_3ms" 
         (ExtChoice 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1"), (ID "e2")])
         (Prefix (ID "e2") SKIP))


np10_3es  = NamedProc "p10_3es" 
         (ExtChoice 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [ ])
         (Prefix (ID "e2") SKIP))
         

-- Example 3.4: Hiding in one side of Interleave
np10_4s  = NamedProc "p10_4" 
         (Interleave
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1")])
         (Prefix (ID "e2") SKIP))         

np10_4ms  = NamedProc "p10_4m" 
         (Interleave 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1"), (ID "e2")])
         (Prefix (ID "e2") SKIP))


np10_4es  = NamedProc "p10_4e" 
         (Interleave 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [])
         (Prefix (ID "e2") SKIP))


-- Example 3.5: Hiding in one side of Generallise parallel 
np10_5s   = NamedProc   "p10_5" 
         (GenPar
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1"), (ID "e2")])
         (Prefix (ID "e2") SKIP)
         [(ID "e2")] 
         )

np10_5ms  = NamedProc   "p10_5m" 
         (GenPar
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1"), (ID "e2")])
         (Prefix (ID "e2") SKIP)
         [(ID "e2")] 
         )

np10_5es  = NamedProc   "p10_5e" 
         (GenPar
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [])
         (Prefix (ID "e2") SKIP)
         [(ID "e2")] 
         )



-- Example 3.6: Hiding in one side of sequential composition 
np10_6s   = NamedProc "p10_6" 
         (Seq 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1")])
         (Prefix (ID "e2") SKIP)
         )

np10_6ms  = NamedProc "p10_6m" 
         (Seq 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1"), (ID "e2")])
         (Prefix (ID "e2") SKIP)
         )

np10_6es  = NamedProc "p10_6e" 
         (Seq 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [])
         (Prefix (ID "e2") SKIP)
         )


-- Example 3.7: Hiding in one side of Interrupt composition 
np10_7s   = NamedProc "p10_7" 
         (Interrupt 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1")])
         (Prefix (ID "e2") SKIP)
         )


np10_7ms  = NamedProc "p10_7m" 
         (Interrupt
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1"), (ID "e2")])
         (Prefix (ID "e2") SKIP)
         )

np10_7es  = NamedProc "p10_7e" 
         (Interrupt
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [] )
         (Prefix (ID "e2") SKIP)
         )


-- Renaming  ------------------------------------------------------------------
-- Renaming with prefix
np11_1  = NamedProc "p11_1" 
         (Rename (Prefix (ID "e1") SKIP) 
         [((ID "e1"), (ID "e3"))])


np111  = NamedProc "p11_1" 
         (Rename (Prefix (ID "e1") SKIP) 
         [((ID "e1"), (ID "e3")),  ((ID "e4"), (ID "e5"))   ])


-- Example 3.2: Renaming with Internal choice 
np11_2  = NamedProc   "p11_2" 
         (Rename (IntChoice (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) 
         [((ID "e1"), (ID "e3"))] )


-- Example 3.3: Renaming with External choice 
np11_3  = NamedProc "p11_3" 
         (Rename (ExtChoice (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) 
         [((ID "e1"), (ID "e3"))]  )


-- Example 3.4: Renaming with Interleave 
np11_4  = NamedProc "p11_4" 
         (Rename (Interleave (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) 
         [((ID "e1"), (ID "e3"))]  )


-- Example 3.5: Renaming with Generallise parallel 
np11_5  = NamedProc   "p11_5" 
         (Rename (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP) [ID "e2"])  
         [((ID "e1"), (ID "e3"))]  )


-- Example 3.6: Renaming with Sequential composition 
np11_6  = NamedProc "p11_6" 
         (Rename (Seq (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) 
         [((ID "e1"), (ID "e3"))] )


-- Example 3.7: Renaming with Sequential composition 
np11_7  = NamedProc "p11_7" 
         (Rename (Interrupt (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))  
         [((ID "e1"), (ID "e3"))]   )

-- Other test cases -----------------------------------------------------
-- p12_1 = (STOP)[|{c1}|]((c-> (SKIP))/\(c1-> (SKIP)))
np12_1  = NamedProc  "p12_1" 
         (GenPar  STOP 
         (Interrupt (Prefix (ID "c") SKIP) (Prefix (ID "c1") SKIP) ) 
         [ID "c1"])

-- p12_2 = (e1-> (SKIP))/\(((e1-> (SKIP))[|{e1}|](STOP))[|{}|](e2-> (SKIP)))
np12_2  = NamedProc   "p12_2" 
         (Interrupt 
         (Prefix (ID "e1") SKIP) 
         (GenPar 
         (GenPar 
         (Prefix (ID "e1") SKIP)  STOP   [ID "e1"])
         (Prefix (ID "e2") SKIP)  [ ]))

---------------------------------------------------------------------------------
-- 13. Examples for the operator of exception.

-- Example 11 
npB     = NamedProc "pB" (Exception (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) [ID "e1"])


-- Example 13.2: Exception parallel with Internal choice----------------------------------------------
np13_C  = NamedProc  "p13C" 
         (Exception  STOP (Prefix (ID "e2") SKIP) [ID "e1"])

-- Example 13.2: Exception parallel with Internal choice----------------------------------------------
np13_D  = NamedProc  "p13D" 
         (Exception  SKIP (Prefix (ID "e2") SKIP) [ID "e1"])


-- Example 13.2: Exception parallel with Internal choice----------------------------------------------
np13_E  = NamedProc  "p13_E" 
         (Exception  (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) [ID "e1"])


-- Example 13.2: Exception parallel with Internal choice----------------------------------------------
np13_2  = NamedProc  "p13_2" 
         (Exception (Prefix (ID "e1") SKIP) (IntChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e1") SKIP)) [ID "e1"])


-- Example 13.3: Exception parallel with External choice----------------------------------------------
np13_3  = NamedProc  "p13_3" 
         (Exception (Prefix (ID "e2") SKIP) (ExtChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e1") SKIP)) [ID "e2"]) 


-- Example 13.4: Exception parallel with Interleave --------------------------------------------------
np13_4  = NamedProc  "p13_4" 
         (Exception (Prefix (ID "e2") SKIP) (Interleave (Prefix (ID "e2") SKIP) (Prefix (ID "e1") SKIP)) [ID "e2"])


-- Example 13.5: Exception parallel with Exception parallel ----------------------------------------
np13_5  =  NamedProc "p13_5" 
          (Exception (Prefix (ID "e2") SKIP) (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP) [ID "e2"]) [ID "e2"])


-- Example 13.6: Exception parallel with Sequential composition --------------------------------------
np13_6  =  NamedProc  "p13_6" 
          (Exception (Prefix (ID "e1") SKIP) (Seq (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) [ID "e1"])


-- Example 13.7: Exception parallel with Interrupt-----------------------------------------------------
np13_7  =  NamedProc  "p13_7" 
          (Exception (Prefix (ID "e1") SKIP) (Interrupt (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) [ID "e1"])

---------------------------------------------------------------------------------
-- Simplified specification of RoboChart model of a simple moving forward system.
-- A timed version model of tock-CSP suitable for timed section of FDR
---------------------------------------------------------------------------------

{-
Tspec = EntryMoving; obstacle-> SKIP0; EntryTurning; Countdown(SMovement_PI/SMovement_av); Tspec

EntryMoving = EDeadline(moveCall, 0); EDeadline(moveRet, 0); Countdown(1) 

EntryTurning = EDeadline(moveCall, 0); EDeadline(moveRet,0) 
-}

-- Tspec = EntryMoving; obstacle-> SKIP0; EntryTurning; Countdown(SMovement_PI/SMovement_av); Tspec
np12_4 = NamedProc "Tspec" 
           (Seq 
           (Seq (entryMovingT)
           (Seq (Prefix (ID "obstacle") Skipu ) 
           (Seq (entryTurningT)  (Waitu 3)
           )))
           (ProcID "Tspec")
           )
           
-- EntryMoving = EDeadline(moveCall, 0); EDeadline(moveRet, 0); WAIT(1) 
entryMovingT  = Seq 
               (EDeadline (ID "moveCall")  0)
               (Seq (EDeadline (ID "moveRet")  0)  (Waitu 1))


-- EntryTurning = EDeadline(moveCall, 0); EDeadline(moveRet,0) 
entryTurningT = Seq 
               (EDeadline (ID "moveCall")  0)
               (EDeadline (ID "moveRet" )  0)
               


----------------------------------------------------------------------------------
-- For explaining trace generation
ptraceGen = NamedProc  "ptraceGen" 
                       (Prefix (ID "e1") (Interleave (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))
         
   






---------------------------------------------------------------------------------
-- Simplify specifications of obstacle detection system
---------------------------------------------------------------------------------
{-
channel moveCall, moveRet, obstacle, tock
-- Constant values from the model
SMovement_PI = 10
SMovement_av = 5

Spec = EntryMoving; Obs; EntryTurning; wait(SMovement_PI/SMovement_av); Spec
-- The delay associated with EntryMoving avoids a possible requirement for the
-- two move operations in the same cycle. 
EntryMoving = moveCall -> moveRet -> |~| i: {1..10} @ wait(i)
Obs = obstacle -> SKIP [] tock ->  Obs
EntryTurning = moveCall -> moveRet -> SKIP

wait(n) = if n == 0 then SKIP else tock -> wait(n-1)

assert Spec :[deadlock free]
assert Spec :[deterministic]
assert Spec :[divergence free]

-- The short specification is a correct semantics of the RoboChart model. 
-- assert Spec [FD= T_CFootBot
-- assert T_CFootBot [FD= Spec
-}


aa_  = genFiles 1  [np12_3]
----------------------------------------------------------------------
-- Init attempt for translating RoboChart
-- Spec = EntryMoving; Obs; EntryTurning; wait(SMovement_PI/SMovement_av); Spec
np12_3 = NamedProc "Spec" 
           (Seq entryMoving
           (Seq obs
           (Seq entryTurning 
           -- SMovement_PI/SMovement_av = 45/15
           (Seq (Wait 3) (ProcID "Spec") ))))

--EntryMoving = moveCall -> moveRet -> |~| i: {1..10} @ wait(i)
-- NamedProc "EntryMoving"
--           (Prefix (ID "moveCall) (Prefix (ID "moveRet") 
entryMoving  = (Prefix (ID "moveCall") (Prefix (ID "moveRet") 
           (IntChoice  (Wait 1)
           (IntChoice  (Wait 2)
           (IntChoice  (Wait 3)
           (IntChoice  (Wait 4)
           (IntChoice  (Wait 5)
           (IntChoice  (Wait 6)
           (IntChoice  (Wait 7)
           (IntChoice  (Wait 8)
           (IntChoice  (Wait 9)  (Wait 10)
           ))))))))))
           ) 


-- Obs = obstacle -> SKIP [] tock ->  Obs
-- NamedProc "Obs" 
--         (ExtChoice
obs =    (ExtChoice         
         (Prefix (ID "obstacle") SKIP )
         (Prefix (ID "tock")  (ProcID "Obs"))
         )

-- EntryTurning = moveCall -> moveRet -> SKIP
-- NamedProc  "EntryTurning"
entryTurning = (Prefix (ID "moveCall")  
               (Prefix (ID "moveRet") SKIP )
               )


npADS = NamedProc "ADS" (Prefix (ID "open") (Prefix (ID "tock") (Prefix (ID "close") SKIP)))
