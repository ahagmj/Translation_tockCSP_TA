{-
This program reads CSP file with its trace and update the CSP file for generating another trace.
-}
-------------------------------------------
import qualified Data.Text as T
import qualified Data.Text.IO as TIO
import qualified Data.ByteString.Char8 as B
import Data.List.Split as S
import System.Environment   
import System.Directory  
import System.IO  
import Data.List 
import TA
import CSP



main = do 
        [cspFile, traceFile] <- getArgs
        csp                  <- B.readFile cspFile
        trace                <- B.readFile traceFile       
        B.writeFile cspFile  (B.pack (updateCSP (B.unpack csp, B.unpack trace)))
--        B.writeFile ("p01/p01.csp")  (B.pack (updateCSP (B.unpack cspC, B.unpack traceC)))


-- Update the CSP file with an additional process, which is created from a generated trace  
-- Takes CSP file with a trace and generate a new CSP file with an updated process for generating another trace
updateCSP :: (String, String) -> String
updateCSP    (csp, trace)     =  (ls !! 0) ++ "--processEnd" ++ tp ++
                                 "\n--traceProc" ++ (ls2!!0) ++ rf ++ (ls2 !! 1)
          where
             ls       =   S.splitOn "--processEnd"  csp
             ls1      =   S.splitOn "--traceProc"   (ls  !! 1)
             ls2      =   S.splitOn ") [T="         (ls1 !! 1)   
             cspTrace = ((S.splitOn "\n" trace) !! 3)
             evs      =   S.splitOn "," (tail $ init cspTrace)
             (tp, rf) =   if   ((ls1!!0) == "\n\n") 
                          then (("\n\ntp01 = ("     ++ show (trace2Proc evs)) ++ ")", (" [] tp01) [T= "))
                          else (((ls1!!0) ++ "[] (" ++ show (trace2Proc evs)) ++ ")", ") [T=")
                                    
       

trace2Proc :: [String] -> CSPproc
trace2Proc    []      =  (Prefix (ID " mark") SKIP)
trace2Proc    (e:es)   =  Prefix (ID e) (trace2Proc es)
--trace2Proc    [e]      =  Prefix (ID e) (Prefix (ID " mark") SKIP)





