-- This program subtracts valid traces from invalid traces, that are generated from adding possible forbidden initials.

-------------------------------------------------------------------
import System.Environment   
import System.Directory  
import System.IO  
import TA
import TF
import CSP
import Data.List
import Data.List.Split
import Data.Char
import qualified Data.ByteString.Char8 as B
import System.Environment   


main = do 
       [newTraces, traceFileFDR, dr] <- getArgs
       genTrace     <- B.readFile newTraces  
       traceFDR     <- B.readFile traceFileFDR       


       -- read the traces and subtract invlid traces and write it back to the file of the newTraces
       B.writeFile (newTraces)   --  (dr ++ "/" ++ newTraces) 
                   (B.pack (subtractTraces (B.unpack genTrace)  (B.unpack traceFDR) ) )


-----------------------------------
-- Extract the traces from their file and subtract valid traces from invalid traces and return the invalid traces
subtractTraces :: String -> String      -> String
subtractTraces    gTraces   tracesFDR   =  ishowLinesSt ((uniq $ lines gTraces)  \\ (uniq $ lines tracesFDR))


