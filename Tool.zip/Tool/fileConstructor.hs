-- File structure
--   Brief description of the file: 
--     This program reads AST  of CSP from a text file and constructs a .csp file for FDR.        
--     

-------------------------
import System.Environment   
import System.Directory  
import System.IO  
import Data.List
import TA

-------------------------------------------------------------------------------------------------------------------------
main = do 
        -- Read the input files as argument, FDR trace, Uppaal trace, directory and process name
        [astFile, length] <- getArgs
        astText   <- readFile astFile
        
        writeFile  (astFile ++ ".hs")  (fileFrame length ++ (ishowListSt (lines astText)) ++ "]")
        
        
        
fileFrame l = 
    "import TF \nimport CSP \nimport TA  \nimport Data.List \nimport System.Directory  \n\n" ++
    "main  = do print \"start\"  \n\n" ++ 
    "           createDirectoryIfMissing True \"GenFiles\" \n\n" ++  
    "           genFiles " ++ l ++ " ["        
