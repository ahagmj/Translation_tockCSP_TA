-- About this program
 -- This program is a Haskell implementation of the translation function that translates tock-CSP into TA for UPPAAL.
 -- Structure of the file. An overview of the contents is as follows.
 -- 1. Definition of the translation function 
 -- 2. A function env that generates a TA for the model of environment
 -- 3. A function syncTA that generates a TA for controlling synchronisations
 -- 4. A function genFiles that generates relevant files and folders for verification using both FDR and UPPAAL
 -- 5. Definition of the other functions used in the program

----------------------------- For better readability make sure this line is not broken --------------------------------

module TF where

import System.Directory
import Data.List
import CSP -- Imports the definition of the abstract syntax tock-CSP suitable for timed section of FDR.
import TA  -- Imports the definition of the abstract syntax of TA suitable for UPPAAL.


-- Types used in the program.
type ProcName       =  String               -- An identifier for each TA
type BranchID       =  String               -- Binary identity for the braches
type StartID        =  Int                  -- An index for the start event
type FinishID       =  Int                  -- An index for the finish event
type SyncPoint      = (Event, String)       -- Assign an identifier for a sync point
type UsedNames      = ([Event],             -- Synchronisations events
                      [SyncPoint],          -- Synchronisation map that assign name to each sync point
                      [Event],              -- Hidden events
                      [(Event, Event)],     -- Rename events
                      [Event],              -- External choice events
                      [Event],              -- Interrupt events
                      [Event],              -- Initial of interrupting process
                      ([Event], String)     -- Exceptions event with the ID of exception process
                      )

--                        (syncEv, syncPoint, hide, rename, exChs, intrr, iniIntrr,  excps) =  usedNames

-- Definition of function transTA ----------------------------------------------------------------------------
transTA :: CSPproc -> ProcName ->  BranchID -> StartID -> FinishID -> UsedNames -> ([TA], [Event], [SyncPoint])   


-- TA  Name Parameters DeclTag  [Location]  [Branchpoint]  Init [Transition]
--------------------------------------------------------------------------------------------------------------
-- STOP translation  
transTA   STOP  procName  bid  sid  fid  usedNames =
   ([(TA  idTA  []  [] locs [] (Init loc1)  trans)], [], [])
  where
    idTA  = "taSTOP__" ++ bid ++ "_" ++ show sid  
   
     --   = Location  ID     Name  Label      LocType
    loc1  = Location "id1"  "s1"   EmptyLabel None
    loc2  = Location "id2"  "s2"   EmptyLabel None
    locs  = [loc1, loc2]

     --   = Transition Source Target [Label] [Nail]
    tran1 = Transition loc1   loc2   [lab1]  []
    tran2 = Transition loc2   loc2   [lab2]  []
    trans =  [tran1, tran2]

    lab1  = Sync (VariableID  sEvnt   [])  Ques
    lab2  = Sync (VariableID "tock"   [])  Ques     

    sEvnt = startEvent procName bid sid                                 


--------------------------------------------------------------------------------------------------------------
-- Urgent deadlock, STOP translation  
transTA   Stopu  procName  bid  sid  fid  usedNames =
           ([(TA  idTA  []  [] locs [] (Init loc1)  trans)], [], [])
          -- TA    Name Parameters DeclTag  [Location]  [Branchpoint]  Init [Transition]
              where 
                idTA  = "taStopu_" ++ bid ++ "_" ++ show sid
                
                 --   = Location  ID     Name  Label      LocType
                loc1  = Location "id1"  "s1"   EmptyLabel None
                loc2  = Location "id2"  "s2"   EmptyLabel None
                locs  = [loc1, loc2]

                 --   = Transition Source Target [Label] [Nail]
                tran1 = Transition loc1   loc2   [lab1]  []
                tran2 = Transition loc2   loc2   [lab2]  []
                trans =  [tran1, tran2]

                lab1  = Sync (VariableID sEvnt  [])  Ques
                lab2  = Sync (VariableID "tock" [])  Ques
                sEvnt = startEvent procName bid sid                 
                     


-------------------------------------------------------------------------------------------------------------
-- SKIP translation
transTA  SKIP procName  bid  sid  fid  usedNames =
             ([(TA  idTA []  [] locs [] (Init loc1)  trans)], [], [])
             where 
                idTA  =  "taWait_n" ++ bid ++ "_" ++ show sid 
                loc1  =  Location "id1" "s1" EmptyLabel None
                loc2  =  Location "id2" "s2" EmptyLabel None
                loc3  =  Location "id3" "s3" EmptyLabel CommittedLoc
                locs  =  [loc1, loc2, loc3]   -- , loc4]

                tran1 =  Transition loc1 loc2 [lab1]    []
                tran2 =  Transition loc2 loc2 [lab2]    []      
                tran3 =  Transition loc2 loc3 [lab3]    []
                tran4 =  Transition loc3 loc1 [lab4]    []                                       
                trans =  [tran1, tran2, tran3, tran4] ++ (transIntrpt intrpts loc1 loc2)

                lab1  =  Sync (VariableID    sEvnt                    [])  Ques
                lab2  =  Sync (VariableID    "tock"                   [])  Ques   
                lab3  =  Sync (VariableID    "tick"                   [])  Excl  
                lab4  =  Sync (VariableID    ("finishID" ++ show fid) [])  Excl 

                sEvnt = startEvent procName bid sid 
                                          
                -- Get event for possible interrupts
                (_, _, _, _, _, intrpts, _, _) =  usedNames
                                  

-----------------------------------------------------------------------------------------------------------------
-- Immediate termination Skipu 
transTA   Skipu     procName  bid  sid  fid  usedNames =
              ([(TA  idTA  []  [] locs [] (Init loc1)  trans)], [], [])
                 --TA =  TA  Name Parameters DeclTag  [Location]  [Branchpoint]  Init [Transition]
              where 
                idTA  =  "taSkipu_" ++ bid ++ "_" ++ show sid
                loc1  =  Location "id1" "s1" EmptyLabel None
                loc2  =  Location "id2" "s2" EmptyLabel None
                loc3  =  Location "id3" "s3" EmptyLabel CommittedLoc
                -- data Location = Location ID Name Label LocType
                locs  =  [loc1, loc2, loc3]   -- , loc4]

                tran1 =  Transition loc1 loc2 [lab1]    []            
                tran3 =  Transition loc2 loc3 [lab3]    []
                tran4 =  Transition loc3 loc1 [lab4]    []                                       
                -- data Transition = Transition Source Target [Label] [Nail]
                trans =  [tran1, tran3, tran4] ++ (transIntrpt intrpts loc1 loc2)

                lab1  =  Sync (VariableID (startEvent procName bid sid)  [])  Ques

                lab3  =   Sync   (VariableID         "tick"                  [])  Excl  
                lab4  =   Sync   (VariableID       ("finishID" ++ show fid)  [])  Excl 
                 
                (_, _, _, _, _, intrpts, _, _) =  usedNames  
     

-------------------------------------------------------------------------------------------------------------
-- Zero Delay translation 
transTA (WAIT 0)     procName  bid  sid  fid  usedNames =
  transTA    SKIP      procName  bid  sid  fid  usedNames
  
-- Delay translation 
transTA (WAIT n) procName  bid  sid  fid  usedNames =
        transTA (Prefix Tock (WAIT (n - 1))) procName  bid  sid  fid  usedNames


-----------------------------------------------------------------------------------------------------------------
-- Waitu translation, another additional constructs for RoboChart
transTA (Waitu n)    procName  bid  sid  fid  usedNames =
                    ([(TA  idTA  []  [] locs [] (Init loc1)  trans)], [], [])
                   where 
                        idTA  =  "taWait_u" ++ bid ++ "_" ++ show sid
                        loc1  =  Location "id1" "s1" EmptyLabel None
                        loc2  =  Location "id2" "s2" EmptyLabel None
                        locs  =  [loc1, loc2]   -- , loc4]

                        tran1 =  Transition loc1 loc2 ([lab1]  ++ t_reset)               [] -- Reset clock for deadline
                        tran2 =  Transition loc2 loc2 ([lab2]  ++ dlguard  ++ dlupdate)  []               
                        tran4 =  Transition loc2 loc1 ([lab4]  ++ dlguard2 ++ t_reset)   []           
                        trans =  [tran1, tran2, tran4] ++ (transIntrpt intrpts loc1 loc2)

                        lab1  =  Sync (VariableID (startEvent procName bid sid)  [])  Ques

                        -- reset deadline time        
                        t_reset   = [(Update  [(AssgExp    (ExpID "tdeadline" ) ASSIGNMENT   (Val 0)) ] )]    
                        lab2      =   Sync     (VariableID         "tock"   []) Ques     -- lable tock
                        dlguard   = [(Guard    (BinaryExp  (ExpID "tdeadline" ) Lth          (Val n)))]
                        dlupdate  = [(Update  [(AssgExp    (ExpID "tdeadline" ) AddAssg      (Val 1)) ] )]
                        dlguard2  = [(Guard    (BinaryExp  (ExpID "tdeadline" ) Equal        (Val n)))]
                        -- Add guard for deadlines
                        lab4      =   Sync     (VariableID       ("finishID" ++ show fid)  [])  Excl 

                        (_, _, _, _, _, intrpts, _, _) =  usedNames
                        

-------------------------------------------------------------------------------------------------------------
-- Prefix translation 
transTA (Prefix     e1 p)  procName  bid  sid  fid  usedNames = 
        (([(TA  idTA [] [] locs1 [] (Init loc1)  trans1)] ++ ta1), sync1, syncMapUpdate)
          where
            idTA = "taPrefix" ++ bid ++ "_" ++ show sid
             
            (syncs, syncMaps, hides, renames, exChs, intrpts, initIntrpts, excps) = usedNames
            
            -- Check if the event is part of hiding or renaming
            e = checkHidingAndRenaming e1 hides renames
            
            -- locs and trans for the possible pattern of sync, choice and interrupt: 
            -- 111,110, 101, 100, 011,010, 001, 000
            (locs1, trans1)  
                  |((not synch) && (    exChoice) && (    interupt)) = case1 
                  |((not synch) && (    exChoice) && (not interupt)) = case2 
                  |((not synch) && (not exChoice) && (    interupt)) = case3 
                  |((not synch) && (not exChoice) && (not interupt)) = case4 
                  |((    synch) && (    exChoice) && (    interupt)) = case5
                  |((    synch) && (    exChoice) && (not interupt)) = case6
                  |((    synch) && (not exChoice) && (    interupt)) = case7 
                  |((    synch) && (not exChoice) && (not interupt)) = case8
            
            synch    = elem e syncs
            exChoice = null exChs
            interupt = null initIntrpts
            
            case1 = ([loc1, loc2, loc5], 
                     [t12, t25,  t51] ++ addTran ++ transIntrpt')            
            case2 = ([loc1, loc2, loc3c, loc5], 
                     if not $ null intrpts then  [t12G, t23ci, t3c5, t51]  ++ addTran -- ++transIntrpt
                     else [t12,  t23ci, t23cgi, t3c5, t51]  ++ addTran ++ transIntrpt')
                        -- if a process can interrupt and also be interrupted, 
                        -- then it can only be interrupted after initiating its interrupt
            case3 = ([loc1, loc2,  loc3c,  loc5],   
                     [t12,  t23c,  t3c5,    t51] ++ t23e ++ addTran ++ transIntrpt')
            case4 = ([loc1, loc2,  loc3c,  loc4c,   loc5], 
                     [t12G, t23c,  t3c4ci, t3c4cgi, t4c5e,    t51] ++ addTran ++ transIntrpt')
            case5 = ([loc1, loc2,  loc3,   loc5], 
                     [t12,  t23,   t35,    t51 ]    ++ addTran     ++ transIntrpt')
            case6 = ([loc1, loc2,  loc3,   loc4c,   loc5], 
                     [t12G, t23,   t34c,   t4c5i,   t4c5gi, t51]   ++ addTran ++ transIntrpt')
            case7 = ([loc1, loc2,  loc3,   loc4,    loc5], 
                     [t12,  t23ech, t34,   t45,     t51]           ++ addTran ++ transIntrpt')
            case8 = ([loc1, loc2,  loc3,   loc4,    loc5,   loc6], 
                     [t12G, t23,   t34c,   t4c6,    t65, t65gi, t51] ++ addTran ++ transIntrpt')
            
            
                        --     =  Location  ID    Name  Label      LocType                    
            loc1   =  Location "id1"  "s1"  EmptyLabel None
            loc2   =  Location "id2"  "s2"  EmptyLabel None
            loc2c  =  Location "id2"  "s2"  EmptyLabel CommittedLoc            
            loc3   =  Location "id3"  "s3"  EmptyLabel None
            loc3c  =  Location "id3"  "s3"  EmptyLabel CommittedLoc
            loc4   =  Location "id4"  "s4"  EmptyLabel None
            loc4c  =  Location "id4"  "s4"  EmptyLabel CommittedLoc
            loc5   =  Location "id5"  "s5"  EmptyLabel CommittedLoc
            loc6   =  Location "id6"  "s6"  EmptyLabel CommittedLoc

            transIntrpt' = (transIntrpt intrpts loc1 loc2)
            
            -- Additional transitions for tock, external choice
            addTran | ((not  $ elem e syncs) && (null exChs))        = [t22]                   
                    | ((elem e syncs)        && (null exChs))        = [t22]                   
                    | ((not  $ elem e syncs) && (not $ null exChs))  = [t22]           ++ t21            
                    | otherwise                                      = [t22, t33, t44] ++ t21  


            t23ci   = Transition  loc2     loc3c   l23ci            []     
            t23cgi  = Transition  loc2     loc3c   altIntrpt        []
            l23ci   = [(Sync (VariableID   ((show e) ++ "_intrpt")  [])  Excl), 
                      (Update  [(AssgExp  (ExpID ((show e) ++ "_intrpt_guard")) ASSIGNMENT TrueExp )])]
            --  An alternative transition in case another event has initites the interrupt.
            --  Guard other possible interrupts, such that any of the interrupt can enable the alternative transition
            altIntrpt = [(Guard (ExpID (intercalate " || "  [l ++"_intrpt_guard"| (ID l) <- initIntrpts])))]          
            -- reset the guards in case of recursive process
            resetG  = [Update  [(AssgExp  (ExpID (l ++ "_intrpt_guard")) ASSIGNMENT FalseExp)| (ID l) <- initIntrpts]]
            t3c5    = Transition  loc3c    loc5    lab4e            []
            t3c4ci  = Transition  loc3c    loc4c   l23ci            []   -- enable other concurent transitions
            t3c4cgi = Transition  loc3c    loc4c   altIntrpt        []   -- guarded interrupt, incase of a concurent TA that initiate interrupt before this TA
            t4c5    = Transition  loc4c    loc5   (lab2i ++ lab2d)  []   -- block external choice
            t4c5e   = Transition  loc4c    loc5    lab4e            []    
            t34c    = Transition  loc3     loc4c   lab4             []
            t3c4c   = Transition  loc3c    loc4c   lab4e            []
            t4c5i   = Transition  loc4c    loc5    l23ci            []
            t4c5gi  = Transition  loc4c    loc5    altIntrpt        []            
            t4c6    = Transition  loc4c    loc6   (lab2i ++ lab2d)  []
            t65     = Transition  loc6     loc5    l23ci            []
            t65gi   = Transition  loc6     loc5    altIntrpt        []                        
            t12     = Transition  loc1     loc2    lab1             []
            t12G    = Transition  loc1     loc2   (lab1 ++ resetG)  []     -- reset guard           
            t23     = Transition  loc2     loc3    lab2i            []
            t2c3    = Transition  loc2c    loc3    lab2i            []            
            t23c    = Transition  loc2     loc3c  (lab2i ++ lab2d)  []    
            t23ech  = Transition  loc2     loc3   (lab2i ++ lab2d)  []                       
            
            
            -- Check hide
--            locs  | elem e hides && null exChs  = [loc1, loc2, loc5]
--                  | otherwise                  = locs1                  
            t25     = if elem e hides 
                      then Transition    loc2   loc5  ([(Sync (VariableID   "itau" []) Excl)] ) [] -- hiding
                      else Transition    loc2   loc5   lab2i             [] 
            t25r    =  Transition  loc2  loc5  ([(Sync (VariableID  (show new_e) []) Excl)] ++ labpath) [] -- renaming
            new_e   =  head [newname | (oldname, newname) <- renames, oldname == e]              
            t51     =  Transition  loc5  loc1  [lab3]             []   -- start next TA, from loc3, loc4 or loc 5    
            t33     =  Transition  loc3  loc3  [labTock]          []   -- tock transition    
            t44     =  Transition  loc4  loc4  [labTock]          []   -- tock transition   
            t35     =  Transition  loc3  loc5   lab4              []
            t22     =  Transition  loc2  loc2  [labTock]          []   -- tock transition                            
            t21     = [(Transition loc2  loc1  [(Sync  (VariableID ((show ch) ++ "_exch")  []) Ques)] [])|ch <- exChs']
            t23e    = [(Transition loc2  loc3  [(Guard (ExpID      ((show ch) ++ "_exch_ready")) )]   [])|ch <- exChs'] 
            t34     =  Transition  loc3  loc4   lab6  []
            t45     =  Transition  loc4  loc5   lab4  []
                        
            lab1    = [Sync (VariableID (startEvent procName bid sid)  [])  Ques]

            lab2i   | (elem e syncs) && (null exChs')  =    -- check the synchronisations
                        [(Guard  (BinaryExp    (ExpID ("g_" ++ (eTag e syncMaps' "")))  Equal     (Val 0))), 
                        (Update  [(AssgExp     (ExpID ("g_" ++ (eTag e syncMaps' "")))  AddAssg   (Val 1))])]
                    | (not $ null exChs') =  if  (elem e hides) then [(Sync (VariableID  "itau_exch"  []) Excl)]
                                            else [(Sync (VariableID  ((show e ) ++      "_exch")     []) Excl)]   
                    | otherwise    =  lab4e   -- Fire normal event or tock
            
            
            labpath = [(Update  [(AssgExp (ExpID "dp") AddAssg (Val 1)), -- Attach counter for trace length
                      (AssgExp  ( ExpID   ("ep_" ++ bid ++ "_" ++ show sid)) ASSIGNMENT TrueExp )])]
                                          -- Attaching path variable to this tranistion
            -- Checks for exception
            lab3    =  if elem e (fst excps)
                       then Sync (VariableID  ("startExcp" ++       (show fid   ))  [])  Excl  
                       else Sync (VariableID  ("startID"   ++ bid ++ "_" ++ show (sid+1))  [])  Excl 
            lab4    = [(Sync (VariableID  ((show e)  ++ "___sync")            [])  Ques)] 

            lab4e   | e == Tock    = [(Sync (VariableID   (show e)  []) Ques)] ++ labpath  -- Sync on tocks
                    | elem e hides = [(Sync (VariableID   ("itau")  []) Excl)]             -- for itau for hiding event
                    | otherwise    = [(Sync (VariableID   (show e)  []) Excl)] ++ labpath  -- Fire normal event
                     
            lab6    = [(Guard  (BinaryExp  (ExpID ("g_" ++ (eTag e syncMaps' ""))) Equal     (Val 0))), 
                      (Update  [(AssgExp   (ExpID ("g_" ++ (eTag e syncMaps' ""))) AddAssg   (Val 1))])]
                    
            lab2d   = [(Update [(AssgExp  (ExpID ((show ch) ++ "_exch_ready")) AddAssg   (Val 1)) | ch <- exChs'])]   

            gIntrpt = [(Guard  (BinaryExp  (ExpID "gIntrpt" ) Equal     (Val 1)))]
            
            uIntrpt = [(Update  [(AssgExp   (ExpID "gIntrpt" ) AddAssg   (Val 1))] )]
                      
            labTock = Sync (VariableID  "tock"                             [])  Ques
            
            -- Update sync points
            syncMaps' = if elem e syncs 
                        then [(e, (show e) ++ bid ++ "_" ++ show sid )]  -- ++ syncMaps_ 
                        else [] -- syncMaps_
            
            -- Combine the synchronisations together 
            syncMapUpdate = syncMaps' ++ syncMap1
            
            
            -- if the external choice event is rename, replace the event with the new name
            exChs' =  if  ( null crs ) then exChs
                      else  (exChs \\ [es']) ++ [nn']
                        
            -- rename all events for blocking external choice
            crs  = [(es, nn) | (es, nn) <- renames, ch <- exChs, ch == es]
            (es', nn') = head crs


            -- Update used names, remove external choice and interrupt if any, after the first event.    
            usedNames' = (syncs, syncMaps, hides, renames, [], intrpts, [], excps)    

            -- finally recursive call for subsequent translation.
            (ta1, sync1, syncMap1) = transTA p []  bid (sid+1) fid usedNames'


-----------------------------------------------------------------------------------------------------
-- Internal choices translation 
transTA (IntChoice  p1 p2)  procName  bid  sid  fid  usedNames =  
               ([(TA  idTA []  [] locs [] (Init loc1) trans )] ++ ta1 ++ ta2,
               sync1 ++ sync2, syncMap1 ++ syncMap2)
               where 
                    idTA  =  "taIntCho" ++ bid ++ "_" ++ show sid
                    loc1  =  Location "id1" "s1" EmptyLabel None
                    loc2  =  Location "id2" "s2" EmptyLabel CommittedLoc
                    loc3  =  Location "id3" "s3" EmptyLabel CommittedLoc
                    loc4  =  Location "id4" "s4" EmptyLabel CommittedLoc
                    locs  =  [loc1, loc2, loc3, loc4]

                    tran1 =  Transition loc1 loc2 [lab1]  []
                    tran2 =  Transition loc2 loc3 []      []
                    tran3 =  Transition loc2 loc4 []      []
                    tran4 =  Transition loc3 loc1 [lab4]  []                                       
                    tran5 =  Transition loc4 loc1 [lab5]  []                                       
                    trans =  [tran1, tran2, tran3, tran4, tran5]

                    lab1  =  Sync (VariableID (startEvent procName bid sid)  [])  Ques
        --                    lab1  = if null procName then Sync (VariableID ("startID" ++ bid ++ "_" ++ show sid) [])  Ques
        --                            else Sync (VariableID ("startID" ++ procName) [])  Ques

                    lab4  =  Sync (VariableID ("startID" ++ (bid ++ "0") ++ "_" ++ show (sid+1))  [])  Excl 
                    lab5  =  Sync (VariableID ("startID" ++ (bid ++ "1") ++ "_" ++ show (sid+2))  [])  Excl
                    
                    (ta1, sync1, syncMap1) = transTA p1 [] (bid ++ "0") (sid+1) fid usedNames
                    (ta2, sync2, syncMap2) = transTA p2 [] (bid ++ "1") (sid+2) fid usedNames


-------------------------------------------------------------------------------------------------------
-- External choice translation 
transTA (ExtChoice  p1 p2)   procName  bid  sid  fid  usedNames = 
    ([(TA  idTA [] [] locs [] (Init loc1) trans )] ++ ta1 ++ ta2,
         sync1 ++ sync2, syncMap1 ++ syncMap2)                  
         where 
              idTA  =  "taExtCho" ++ bid ++ "_" ++ show sid
              loc1  =  Location "id1" "s1" EmptyLabel None
              loc2  =  Location "id2" "s2" EmptyLabel CommittedLoc
              loc3  =  Location "id3" "s3" EmptyLabel CommittedLoc
              locs  =  [loc1, loc2, loc3]

              tran1 =  Transition loc1 loc2 [lab1]  []
              tran2 =  Transition loc2 loc3 [lab2]  []
              tran3 =  Transition loc3 loc1 [lab3]  []               
              trans = [tran1, tran2, tran3]

              lab1  =  Sync (VariableID (startEvent procName bid sid)  [])  Ques
--              lab1  = if null procName then Sync (VariableID ("startID" ++ bid ++ "_" ++ show sid) [])  Ques
--                      else Sync (VariableID ("startID" ++ procName) [])  Ques

              lab2  =   Sync (VariableID ("startID" ++ (bid ++ "0") ++ "_" ++ show (sid+1))  [])  Excl 
              lab3  =   Sync (VariableID ("startID" ++ (bid ++ "1") ++ "_" ++ show (sid+2))  [])  Excl 
              
                                      -- Update the paramter for synchronisation
              (syncEv, syncPoint, hide, rename, exChs, intrr, iniIntrr,  excps) =  usedNames 
             
              exChs'  = exChs ++ (initials p2)
              exChs'' = exChs ++ (initials p1)
             
              usedNames'  = (syncEv, syncPoint, hide, rename, exChs',  intrr, iniIntrr,  excps)
              usedNames'' = (syncEv, syncPoint, hide, rename, exChs'', intrr, iniIntrr,  excps)


              (ta1, sync1, syncMap1) =  transTA p1 [] (bid ++ "0") (sid+1) fid usedNames'
              (ta2, sync2, syncMap2) =  transTA p2 [] (bid ++ "1") (sid+2) fid usedNames''


-----------------------------------------------------------------------------------------------------
-- Translation of sequential composition 
transTA (Seq        p1 p2)    procName  bid  sid  fid  usedNames = 
            ([(TA  idTA  []  [] locs [] (Init loc1) trans )] ++ ta1 ++ ta2, sync1 ++ sync2, syncMap1 ++ syncMap2)               
           where 
             idTA  =  "taSequen" ++ bid ++ show  sid 
             loc1  =  Location "id1" "s1" EmptyLabel None
             loc2  =  Location "id2" "s2" EmptyLabel CommittedLoc
             loc3  =  Location "id3" "s3" EmptyLabel None
             loc4  =  Location "id4" "s4" EmptyLabel CommittedLoc
              -- data Location = Location ID Name Label LocType
             locs  =  [loc1, loc2, loc3, loc4]

             tran1 =  Transition loc1 loc2 [lab1]  []
             tran2 =  Transition loc2 loc3 [lab2]  []
             tran3 =  Transition loc3 loc4 [lab3]  []
             tran4 =  Transition loc4 loc1 [lab4]  []                                
             -- data Transition = Transition Source Target [Label] [Nail]
            
             trans =  [tran1, tran2, tran3, tran4]

             lab1  =  Sync (VariableID (startEvent procName bid sid)  [])  Ques
             lab2  =  Sync (VariableID ("startID"  ++ (bid ++ "0") ++ "_" ++ show (sid+1))  []) Excl 
             lab3  =  Sync (VariableID ("finishID" ++                        show (fid+1))  []) Ques 
             lab4  =  Sync (VariableID ("startID"  ++ (bid ++ "1") ++ "_" ++ show (sid+2))  []) Excl 

             (ta1, sync1, syncMap1)  = transTA p1 [] (bid ++ "0")  (sid+1) (fid+1) usedNames
             (ta2, sync2, syncMap2)  = transTA p2 [] (bid ++ "1")  (sid+2)  fid    usedNames


----------------------------------------------------------------------------------------------------
-- Interleave translation in the form of generallised parallel with empty sync 
transTA  (Interleave p1 p2)     procName  bid  sid  fid  usedNames = 
 transTA (GenPar     p1 p2 [])  procName  bid  sid  fid  usedNames
                                -- As generalised parallel with empty synch events

{-   Todo: to test the updated generallised parallel below.                                
-- Generallised parallel translation ---------------------------------------------------------------
transTA (GenPar  p1 p2 es) procName  bid  sid  fid  usedNames = 
            ([(TA  ("taGenPar" ++ bid ++ "_" ++ show sid)  []  [] locs [] (Init loc1) trans )] ++ ta1 ++ ta2, es ++ sync1 ++ sync2, syncMap1 ++ syncMap2)
            where
                -- Update the paramter for synchronisation
                (syncEv, syncPoint, hide, rename, exChs, intrr, iniIntrr,  excps) =  usedNames 

                syncEv'   = es ++ syncEv

                loc1   =  Location "id1"  "s1"  EmptyLabel None
                loc2   =  Location "id2"  "s2"  EmptyLabel CommittedLoc
                loc2a  =  Location "id2a" "s2a" EmptyLabel CommittedLoc
                loc3   =  Location "id3"  "s3"  EmptyLabel CommittedLoc
                loc4   =  Location "id4"  "s4"  EmptyLabel None
                loc5   =  Location "id5"  "s5"  EmptyLabel None
                loc6   =  Location "id6"  "s6"  EmptyLabel None
                loc7   =  Location "id7"  "s7"  EmptyLabel CommittedLoc
                
                locs   = [loc1, loc2, loc2a, loc3, loc4, loc5, loc6, loc7]
                
             -- data Transition = Transition Source Target [Label] [Nail]
                tran1  =  Transition loc1  loc2  [lab1]  []
                tran1a =  Transition loc2  loc2a [lab3]  [] 
                tran1b =  Transition loc2a loc4  [lab2]  []
                tran2  =  Transition loc2  loc3  [lab2]  []
                tran3  =  Transition loc3  loc4  [lab3]  []
                tran4  =  Transition loc4  loc5  [lab4]  []                                       
                tran5  =  Transition loc4  loc6  [lab5]  [] 
                tran6  =  Transition loc5  loc7  [lab5]  [] 
                tran7  =  Transition loc6  loc7  [lab4]  [] 
                tran8  =  Transition loc7  loc1  [lab6]  []                                 
                
                trans  =  [tran1, tran1a, tran1b, tran2, tran3, tran4, tran5, tran6, tran7, tran8]

                lab1  =  Sync (VariableID (startEvent procName bid sid)  [])  Ques
                lab2  =  Sync (VariableID ("startID"  ++ (bid ++ "0") ++ "_" ++ show (sid+1)) []) Excl 
                lab3  =  Sync (VariableID ("startID"  ++ (bid ++ "1") ++ "_" ++ show (sid+2)) []) Excl 
                lab4  =  Sync (VariableID ("finishID"                        ++ show (fid+1)) []) Ques
                lab5  =  Sync (VariableID ("finishID"                        ++ show (fid+2)) []) Ques
                lab6  =  Sync (VariableID ("finishID"                        ++ show  fid   ) []) Excl 

                usedNames' = (syncEv', syncPoint, hide, rename, exChs, intrr, iniIntrr,  excps)

                (ta1, sync1, syncMap1) = transTA p1 [] (bid ++ "0") (sid+1) (fid+1) usedNames'
                (ta2, sync2, syncMap2) = transTA p2 [] (bid ++ "1") (sid+2) (fid+2) usedNames'
-}


-- Updated generallised parallel translation ---------------------------------------------------------------
transTA (GenPar  p1 p2 es) procName  bid  sid  fid  usedNames = 
     ([(TA  idTA  []  [] locs [] (Init loc1) trans )] ++ 
      ta1 ++ ta2, es ++ sync1 ++ sync2, syncMap1 ++ syncMap2)
  where
    idTA   = "taGenPar" ++ bid ++ "_" ++ show sid
    loc1   =  Location  "id1"  "s1"    EmptyLabel None
    loc2   =  Location  "id2"  "s2"    EmptyLabel CommittedLoc
    loc3   =  Location  "id3"  "s3"    EmptyLabel CommittedLoc
    loc4   =  Location  "id4"  "s4"    EmptyLabel CommittedLoc
    loc5   =  Location  "id5"  "s5"    EmptyLabel None
    loc6   =  Location  "id6"  "s6"    EmptyLabel None
    loc7   =  Location  "id7"  "s7"    EmptyLabel None
    loc8   =  Location  "id8"  "s8"    EmptyLabel CommittedLoc
    locs   =  [loc1, loc2, loc3, loc4, loc5, loc6, loc7, loc8]
    tran1  =  Transition loc1   loc2   [lab1]  []
    tran2  =  Transition loc2   loc3   [lab3]  [] 
    tran3  =  Transition loc3   loc5   [lab2]  []
    tran4  =  Transition loc2   loc4   [lab2]  []
    tran5  =  Transition loc4   loc5   [lab3]  []
    tran6  =  Transition loc5   loc6   [lab4]  []                                       
    tran7  =  Transition loc5   loc7   [lab5]  [] 
    tran8  =  Transition loc6   loc8   [lab5]  [] 
    tran9  =  Transition loc7   loc8   [lab4]  [] 
    tran10 =  Transition loc8   loc1   [lab6]  []                                     
    trans  =  [tran1, tran2, tran3, tran4, tran5, 
               tran6, tran7, tran8, tran9, tran10]

    lab1  =  Sync (VariableID (startEvent procName bid sid)  [])  Ques
    lab2  =  Sync (VariableID ("startID"  ++ (bid ++ "0_") ++ show (sid+1)) []) Excl 
    lab3  =  Sync (VariableID ("startID"  ++ (bid ++ "1_") ++ show (sid+2)) []) Excl 
    lab4  =  Sync (VariableID ("finishID" ++ show (fid+1)) []) Ques
    lab5  =  Sync (VariableID ("finishID" ++ show (fid+2)) []) Ques
    lab6  =  Sync (VariableID ("finishID" ++ show    fid ) []) Excl 

    -- Update the parameter for synchronisation
    (syncEv, syncPoint, hide, rename, exChs, intrr, iniIntrr,  
        excps) = usedNames 
    syncEv'    = es ++ syncEv    
    usedNames' = (syncEv', syncPoint, hide, rename, exChs, intrr, iniIntrr,  excps)

    (ta1, sync1, syncMap1) = transTA p1 [] (bid ++ "0") (sid+1) (fid+1) usedNames'
    (ta2, sync2, syncMap2) = transTA p2 [] (bid ++ "1") (sid+2) (fid+2) usedNames'


{-    
    lab1  =  Sync (VariableID (startEvent procName bid sid)  [])  Ques
    lab2  =  Sync (VariableID ("startID"  ++ (bid ++ "0") ++ "_" ++ show (sid+1)) []) Excl 
    lab3  =  Sync (VariableID ("startID"  ++ (bid ++ "1") ++ "_" ++ show (sid+2)) []) Excl 
    lab4  =  Sync (VariableID ("finishID"                        ++ show (fid+1)) []) Ques
    lab5  =  Sync (VariableID ("finishID"                        ++ show (fid+2)) []) Ques
    lab6  =  Sync (VariableID ("finishID"                        ++ show  fid   ) []) Excl 

    usedNames' = (syncEv', syncPoint, hide, rename, exChs, intrr, iniIntrr,  excps)

    (ta1, sync1, syncMap1) = transTA p1 [] (bid ++ "0") (sid+1) (fid+1) usedNames'
    (ta2, sync2, syncMap2) = transTA p2 [] (bid ++ "1") (sid+2) (fid+2) usedNames'
-}



-- Interrupt translation ------------------------------------------------------------------------------
transTA (Interrupt  p1 p2 )   procName  bid  sid  fid  usedNames = 
        ([(TA idTA [] [] locs [] (Init loc1) trans )] ++ ta1 ++ ta2, sync1 ++ sync2, syncMap1 ++ syncMap2)                  
        where
           idTA  =  "taIntrpt" ++ bid ++ "_" ++ show sid 
           loc1  =  Location "id1"  "s1"  EmptyLabel None
           loc2  =  Location "id2"  "s2"  EmptyLabel CommittedLoc  -- None
           loc3  =  Location "id3"  "s3"  EmptyLabel CommittedLoc
           locs  =  [loc1, loc2, loc3]

           t12   =  Transition loc1  loc2  [lab1]  []
           t23   =  Transition loc2  loc3  [lab2]  [] 
           t31   =  Transition loc3  loc1  [lab3]  []          
           trans =  [t12, t23, t31]

           lab1  =  Sync (VariableID (startEvent procName bid sid)  [])  Ques

           lab2  =   Sync (VariableID ("startID" ++ (bid ++ "0") ++ "_" ++ show (sid+1))  [])  Excl 
           lab3  =   Sync (VariableID ("startID" ++ (bid ++ "1") ++ "_" ++ show (sid+2))  [])  Excl 

           -- Update the paramters for interrupts
           (syncEv, syncPoint, hide, rename, exChs, intrr, iniIntrr,  excps) =  usedNames 
           
           intrr'      = intrr      ++ (initials p2)
           iniIntrr'   = iniIntrr   ++ (initials p2)
             
           usedNames'  = (syncEv, syncPoint, hide, rename, exChs, intrr', iniIntrr,   excps)
           usedNames'' = (syncEv, syncPoint, hide, rename, exChs, intrr,  iniIntrr',  excps)
           
           (ta1, sync1, syncMap1) = transTA p1 [] (bid ++ "0") (sid+1) fid usedNames'
           (ta2, sync2, syncMap2) = transTA p2 [] (bid ++ "1") (sid+2) fid usedNames''

--------------------------------------------------------------------------------------------------------
-- Timeout translation ---------------------------------------
-- According to Joel thesis [1], the timeout is translated into external choices as follows
-- (P [d> Q) = P [] (WAIT(d);timeout -> Q) \{timeout}
-- [1] Ouaknine, Joel. Discrete analysis of continuous behaviour in real-time concurrent systems. 
-- Diss. University of Oxford, 2000.

transTA (Timeout    p1 p2 d)  procName  bid sid fid usedNames = 
           transTA (IntChoice  p1 (Seq (WAIT d) p2 ))  procName  bid sid fid usedNames


----------------------------------------------------------------------------------------------------------------
-- Hiding translation ----------------------------------------
transTA (Hiding     p  es )   procName  bid  sid  fid  usedNames = 
        transTA ( p )  procName     bid sid fid usedNames'
        where
           (syncEv, syncPoint, hide, rename, exChs, intrr, iniIntrr,  excps) =  usedNames 
           usedNames'   = (syncEv, syncPoint, (es ++ hide), rename, exChs, intrr, iniIntrr,  excps)
           -- Update the parameter for hiding
           -- The remaining translation is under the translation of prefix 
        

-----------------------------------------------------------------------------------------------------------------
---- Renaming translation 
transTA (Rename     p  pes)  procName  bid sid fid usedNames 
        = transTA ( p )      procName  bid sid fid usedNames'
        where
           (syncEv, syncPoint, hide, rename, exChs, intrr, iniIntrr,  excps) =  usedNames 
           usedNames'   = (syncEv, syncPoint, hide, (rename ++ pes), exChs, intrr, iniIntrr,  excps)
           -- Update the parameter for renaming
           -- The remaining translation is under the translation of prefix              

-----------------------------------------------------------------------------------------------------------------
transTA (Exception  p1 p2 es) procName  bid  sid  fid  usedNames =
           ([(TA  idTA  []  [] locs [] (Init loc1) trans )] ++ ta1 ++ ta2,
                 sync1 ++ sync2, syncMap1 ++ syncMap2)               
           where 
             idTA  =  "taException" ++ bid ++ show  sid 
             loc1  =  Location "id1" "s1" EmptyLabel None
             loc2  =  Location "id2" "s2" EmptyLabel CommittedLoc
             loc3  =  Location "id3" "s3" EmptyLabel None
             loc4  =  Location "id4" "s4" EmptyLabel CommittedLoc
--             loc5  =  Location "id5" "s5" EmptyLabel None
             loc6  =  Location "id6" "s6" EmptyLabel CommittedLoc
             loc7  =  Location "id7" "s7" EmptyLabel None
             loc8  =  Location "id8" "s8" EmptyLabel CommittedLoc
--             loc9  =  Location "id9" "s9" EmptyLabel None
             
              -- data Location = Location ID Name Label LocType
             locs  =  [loc1, loc2, loc3, loc4, loc6, loc7, loc8]

             tran1 =  Transition loc1 loc2 [lab1]  []
             tran2 =  Transition loc2 loc3 [lab2]  []
             tran3 =  Transition loc3 loc4 [lab3]  []
             tran4 =  Transition loc4 loc1 [lab4]  []
             tran5 =  Transition loc3 loc6 [lab5]  []                                
             tran6 =  Transition loc6 loc7 [lab6]  []  
             tran7 =  Transition loc7 loc8 [lab7]  []          
             tran8 =  Transition loc8 loc1 [lab8]  []                
             -- data Transition = Transition Source Target [Label] [Nail]
            
             trans =  [tran1, tran2, tran3, tran4, tran5, tran6, tran7, tran8]

             lab1  =  Sync (VariableID (startEvent procName bid sid)  [])  Ques
--             lab1  =  if   null procName then Sync (VariableID ("startID" ++ bid ++ "_" ++ show sid) [])  Ques
--                      else Sync (VariableID ("startID" ++ procName) [])  Ques
             lab2  =  Sync (VariableID ("startID"   ++ (bid ++ "0") ++ "_" ++ show (sid+1))  []) Excl 
             lab3  =  Sync (VariableID ("finishID"  ++                        show (fid+1))  []) Ques
             lab4  =  Sync (VariableID ("finishID"  ++                        show (fid  ))  []) Excl              
             lab5  =  Sync (VariableID ("startExcp" ++                        show (fid+1))  []) Ques   
             lab6  =  Sync (VariableID ("startID"   ++ (bid ++ "1") ++ "_" ++ show (sid+2))  []) Excl
             lab7  =  Sync (VariableID ("finishID"  ++                        show (fid+1))  []) Ques 
             lab8  =  lab4
             
             -- Update the paramter for exception
             (syncEv, syncPoint, hide, rename, exChs, intrr, iniIntrr,  excps) =  usedNames 
             
             excps'     = (((fst excps) ++ es), snd excps)
             
             usedNames' = (syncEv, syncPoint, hide, rename, exChs, intrr, iniIntrr,  excps')
              
              -- translate the subsequent TAs
             (ta1, sync1, syncMap1)  = transTA p1 [] (bid ++ "0")  (sid+1) (fid+1) usedNames'
             (ta2, sync2, syncMap2)  = transTA p2 [] (bid ++ "1")  (sid+2) (fid+1) usedNames'
            

-----------------------------------------------------------------------------------------------------------------
-- Event deadline translation, additional construct for RoboChart 
transTA (EDeadline e n)    procName  bid  sid  fid  usedNames =
                  ([(TA  idTA []  [] locs [] (Init loc1)  trans)], [], [])
                   where 
                        idTA  =  "taDeadln" ++ bid ++ "_" ++ show sid
                        loc1  =  Location "id1" "s1" EmptyLabel None
                        loc2  =  Location "id2" "s2" EmptyLabel None
                        loc3  =  Location "id3" "s3" EmptyLabel CommittedLoc
                        -- data Location = Location ID Name Label LocType
                        locs  =  [loc1, loc2, loc3]   -- , loc4]

                        tran1 =  Transition loc1 loc2 ([lab1] ++ t_reset  ++ dlguard3)    []
                        tran2 =  Transition loc2 loc2 ([lab2] ++ dlguard1  ++ dlupdate)   []               
                        tran3 =  Transition loc2 loc3 ([lab3] ++ dlguard2 ++ labpath )   []
                        tran4 =  Transition loc3 loc1  [lab4]    []                                       
                        -- data Transition = Transition Source Target [Label] [Nail]
                        trans =  [tran1, tran2, tran3, tran4] ++ (transIntrpt intrpts loc1 loc2)

                        lab1  =  Sync (VariableID (startEvent procName bid sid)  [])  Ques

                        -- reset deadline time        
                        t_reset   =  [(Update  [(AssgExp   (ExpID "tdeadline" ) ASSIGNMENT   (Val 0))] )]    

                        lab2      =  Sync   (VariableID         "tock"                  [])  Ques     -- lable tock
                        lab3      =  Sync   (VariableID         (show e)                [])  Excl  
                        lab4      =  Sync   (VariableID       ("finishID" ++ show fid)  [])  Excl 
                        

                        dlguard1  = [(Guard   (BinaryExp  (ExpID "tdeadline" ) Lth     (Val n)))]
                        dlupdate  = [(Update  [(AssgExp   (ExpID "tdeadline" ) AddAssg (Val 1))] )]
                        
                        dlguard2  = [(Guard   (BinaryExp  (ExpID "tdeadline" ) Lte     (Val n)))]
                        dlguard3  = [(Guard   (BinaryExp  (ExpID "tdeadline" ) Gth     (Val n)))]        
                        
                        -- dl_reset  = [(Update  [(AssgExp   (ExpID "tdeadline" ) ASSIGNMENT (Val 1))] )]
                        
                        -- Add guard for deadlines

                        -- Attaching path variable to this tranistion            
                        labpath   = [(Update  [(AssgExp (ExpID "dp") AddAssg (Val 1)), -- Attach counter dp
                                     (AssgExp  (ExpID ("ep_" ++ bid ++ "_" ++ show sid)) ASSIGNMENT TrueExp )])]
                        
                        -- Get possible interrupts
                        (_, _, _, _, _, intrpts, _, _) =  usedNames          

                                                
------------------------------------------------------------------------------------------------------------
-- Named process translation 
transTA (ProcID      pid )   procName  bid  sid  fid  usedNames = 
                    ([(TA  idTA  []  [] locs [] (Init loc1) trans )], [], [])
                      where 
                        idTA  =  "taNamedP" ++ bid ++ show  sid 
                        loc1  =  Location "id1" "s1" EmptyLabel None
                        loc2  =  Location "id2" "s2" EmptyLabel None

                        locs  =  [loc1, loc2]

                        tran1 =  Transition loc1 loc2 [lab1]  []
                        tran2 =  Transition loc2 loc1 [lab2]  []
                        -- data Transition = Transition Source Target [Label] [Nail]

                        trans =  [tran1, tran2]                        

                        lab1  =  Sync (VariableID (startEvent procName bid sid)  [])  Ques
--                        lab1  =  Sync (VariableID ("startID"  ++  bid ++ show  sid )  []) Ques
--                        lab1  = if null procName then Sync (VariableID ("startID" ++ bid ++ "_" ++ show sid) [])  Ques
--                                else Sync (VariableID ("startID" ++ procName) [])  Ques

                        lab2  =  Sync (VariableID ("startID"    ++  pid              )  []) Excl 


-----------------------------------------------------------------------------------------------------------------
transTA (Parproc    id n )   procName  bid  sid  fid  usedNames = ([],[],[])
-- Parameterised process to be implemented



-------------------------------------------------------------------------------------------------
-- A function that combines the translations into a suitable file structure for UPPAAL
transform :: NamedProc  -> Int -> Template
transform    npr           n   =  Template   []      decls       temps     ins      (System ins)  []       n
       -- CSPprocess traceSize = Template   Imports  Declaration TA  InstTag   System       Queries  TraceSize
     where
       NamedProc pid pr = npr
       decls = [( VariableDecl  (Type Meta TypeChan)   -- Declares channels
               ([(VariableID   "tick"                   [])                                 ] ++ --declare event tick
                [(VariableID   "iitick"                 [])                                 ] ++ --intermediary tick
               -- Todo, for improvement, to consider replacing tick with iitick
                [(VariableID   "itau"                   [])                                 ] ++  -- declare itau 
--                [(VariableID   "startID0_0"             [])                                 ] ++  
               [( VariableID  ("startID"   ++   id   )  []) | id <- (sids ++ uniq (pid:(processIDs pr)))] ++ --plus PIDs
--               [(VariableID   ("finishID"  ++   id   )  []) | id <- (sids ++ uniq (pid:(processIDs pr)))] ++ --FIDs 
               [(VariableID   ("startExcp"++ (show id)) []) | id <- [0..15]] ++ --Excp
               [(VariableID   ("finishID"++  (show id)) []) | id <- [0..15]] ++    -- declare finish 15 IDs
               [(VariableID   (ev  ++ "_intrpt")        []) | (ID ev) <- (uniq $ events pr) ] ++
               -- declare  all events in the process   
               [(VariableID   (id)                      []) | (ID id) <- (removeSync $ removeExch $ uniq $ events pr),
               id /= "tock", id /= "tick" ] )),
               -- avoid multiple declaration with removing external choice, sync and tock event
               -- Declare broadcast channels
               ( VariableDecl (Type Broadcast TypeChan) ([(VariableID "tock"                          [])  ] ++ 
               [(VariableID   (id ++ "_exch")        []) | (ID id) <- (uniq (events pr) ++ [(ID "itau")])  ] ++ 
               [(VariableID    id                    []) | (ID id) <- (uniq (onlySync (events pr)))        ] ++ 
               [(VariableID   (ev ++ "___sync")      []) | (ID ev) <- syncEvents ] )),               
               (VariableDecl  (Type Meta TypeClock)  [(VariableID     "ck"      [])]),   -- Declare clock ck
               -- Declares Boolean variables
               (VariableDecl  (Type Meta TypeBool) ([(VariableIDInit ("ep_" ++ d) [] (Initialiser (Val 0)))| 
                                                    d <- sids, not (null d)]  ++   -- )),     -- path identity
                                                    [(VariableIDInit ("ep_FID0")  [] (Initialiser (Val 0)))] ++
                                                    [(VariableIDInit ("ep_" ++ e ++ "_sync") [] (Initialiser (Val 0)))|
                                                    (ID e) <- (uniq (events pr)) ] ++  -- path ID with sync
                                                    [(VariableIDInit (e ++ "_intrpt_guard") [] (Initialiser (Val 0)))|
                                                    (ID e) <- (uniq (events pr)) ]  -- interrupt guard
                                                    )), 
               -- Declares integer variables
               (VariableDecl (Type Meta TypeInt  ) 
                     ([(VariableIDInit ("d"++d)   [] (Initialiser (Val 0)))| d <- sids, not (null d)] ++ 
                     -- declare the delay var d                                    
                     [(VariableIDInit "ready_c"   [] (Initialiser (Val 0))),  --for synch
                     (VariableIDInit  "gIntrpt"   [] (Initialiser (Val 0))),  --for synch 
                     (VariableIDInit  "guard_c"   [] (Initialiser (Val 1))),
                     (VariableIDInit  "start"     [] (Initialiser (Val 0))),
                     (VariableIDInit  "dp"        [] (Initialiser (Val 0))),    -- depth decl
                     (VariableIDInit  "tdeadline" [] (Initialiser (Val 0)))] ++  -- for timed deadline
                     [(VariableID ("g_" ++ tag)   [] )  | (e, tag) <- uniq syncMaps] ++
                     [(VariableID (id   ++ "_exch_ready" ) []) | (ID id ) <- ((uniq (events pr)) ++ [(ID "itau")])]
                     )   )]
                                                
       (pTA, syncs, syncMaps) = (transTA pr pid "0" 0 0 ([], [], [], [], [], [], [], ([],[])))
--       (pTA, syncs, syncMaps) = (transTA pr pid "0" 0 0 [] [] [] [] [] [] [] ([],[]) [] )
       temps = (env pid (removeSync $ removeExch $ uniq $ events pr)):pTA ++ [syncTA syncs syncMaps]
             -- TA for env, translation and syncronisation.
             -- Concatenates TA for a model of the environment using the function env, 
             -- with the TA for the collection of TAs that defines a process, and the TA synchronisation controller. 
             -- (env (uniq $ events)) to ensure that the TA for env does not have multiple trans with the same event 

       -- Instantiates the templates of the TA
       ins  = [(Instantiation ('p':id) t []) | (t, id) <- (zip temps (map (\(TA id _ _ _ _ _ _) -> id) temps))]

       -- Extracts the start ids from the template ids (size is 8), for generating and declaring the startIDs.
       sids       = (map snd (map (splitAt 8) (map (\(TA id _ _ _ _ _ _) -> id) (tail temps))))       
       syncEvents = uniq  [id | (id, tag) <- uniq syncMaps] 



----------------------------------------------------------------------------------------------------------------------
-- 3. Function for generating the TA of the environment. The function takes name of first process and all other events
env :: String -> [Event] -> TA
--         = TA Name  Parameters [Declaration]  [Location]  [Branchpoint]  Init       [Transition]
env pid es = TA "Env" []         []             [loc]       []             (Init loc) trans
           where 
             loc   = Location "taEnv" "taEnv" EmptyLabel None
             trans = [(Transition loc loc [(Sync    (VariableID id          [])  Ques)] [])|(ID id) <- es] ++ 
                     [Transition  loc loc [(Sync    (VariableID "startID0_0"             [])  Excl),
--                                           (Sync    (VariableID "startID001"            [])  Excl),
                                           (Guard   (BinaryExp  (ExpID "start")  Equal      (Val 0))),
                                           (Update  [(AssgExp   (ExpID "start")  ASSIGNMENT (Val 1))])]  [], 
                     Transition  loc loc  [(Sync    (VariableID ("startID" ++ pid)      [])  Excl),
                                           (Guard   (BinaryExp  (ExpID "start")  Equal      (Val 0))),
                                           (Update  [(AssgExp   (ExpID "start")  ASSIGNMENT (Val 1))])]  [], 
                     Transition   loc loc [(Sync    (VariableID "finishID0" [])  Ques),
                                           (Update  [(AssgExp   (ExpID "dp"   )  AddAssg (Val 1)), -- counter dp
                                           (AssgExp  (ExpID     ("ep_FID0"   ))  ASSIGNMENT TrueExp )])  ] [],
--                                                   (Update  [(AssgExp (ExpID "dp") AddAssg (Val 1))]) ] [],
                     Transition   loc loc [(Sync    (VariableID "tick"      [])  Ques)] [],  
                     Transition   loc loc [(Sync    (VariableID "iitick"    [])  Ques)] [],  
                     Transition   loc loc [(Sync    (VariableID "itau"      [])  Ques)] [],  
                     Transition   loc loc [(Sync    (VariableID "tock"      [])  Excl),                 
                                           (Guard   (BinaryExp  (ExpID "ck"  )  Lte         (Val 1))), 
                                           (Update  [AssgExp     (ExpID "ck"  )  ASSIGNMENT  (Val 0)] )]   []]


-- Examples -------------------------------------
env1 = env  "p1" (events (Prefix (ID "e1") SKIP))
env2 = env  "p2" (events p2)


-------------------------------------------------------------------------------------------------------------------
-- 4. Generates TA for controlling the synchronisations point
-- The definition of "trans" below, adds a prefix "v_" to an event name to form a variable name that each TA increments to register its readiness to sync.
syncTA :: [Event] -> [SyncPoint] -> TA
syncTA    events      syncMaps  = TA "SyncTA" [] [] (loc:locs) [] (Init loc) tran0s 
                    where 
                    loc    =   Location   "SyncPoint" "SyncPoint" EmptyLabel None                   
                    locs   = [(Location   ("s"++ show e)   ("s"++ show e) EmptyLabel CommittedLoc) | e <- uniq events]
                    tran0s =   transGen    loc (uniq events)  syncMaps  events
                    

-------------------------------------------------------------------------------------------------------------------
--  Generates transitions for the sync controller
--          States      syncEvents  syncMaps      syncEvents->  Transitions
transGen :: Location -> [Event] -> [SyncPoint] -> [Event]    -> [Transition]
transGen    l0          []            _            _       =  []
transGen    l0          (e:es)       syncMaps      syncs   =  [(Transition l0 l [(Sync   (VariableID (show e) []) Excl),
                    (Guard      (ExpID ((addExpr [("g_" ++ tag) | (e1, tag) <- syncMaps, e == e1 ]) 
                    ++ " == " ++  show ((length  [e1 | e1 <- syncs, e == e1 ]) + 1) ) )), 
                    (Update ([ AssgExp  (ExpID   ("g_" ++ tag)) ASSIGNMENT  (Val 0) |(e1, tag) <- syncMaps, e == e1 ] ++
                    labpath  ))     ]   [])]   ++
                    [Transition l   l0  [(Sync (VariableID ((show e) ++ "___sync") []) Excl)] [] ] ++ 
                    (transGen   l0  es   syncMaps syncs)  
                    where
                       l        = (Location ("s"++ show e) ("s"++ show e) EmptyLabel CommittedLoc)
                       labpath  = [(AssgExp (ExpID  "dp" ) AddAssg (Val 1)),  -- Attach counter dp for trace length
                                  (AssgExp  (ExpID ("ep_" ++ show e ++"_sync")) ASSIGNMENT TrueExp )]


---------------------------------------------------------------------------------------------
--5. Function for generating files and folders for both FDR and UPPAAL systems
genFiles :: Int     -> [NamedProc] -> IO [()]
genFiles    _          []           = sequence []
genFiles    traceSize  ps           = 
            sequence ((cspFolders ++ cspFiles ++ uppaalFolders ++ uppaalFiles) ++ [syntax, events] ++ 
            [monitorFolder, monitorTA])  
            where 
                (NamedProc pName pr) = head ps
                
                -- Write the concrete syntax of the process into a file for output together with the result
                syntax  = writeFile  ("GenFiles/" ++ pName ++ "/FDR/syntax")  
                                     (ishowLinesSt [show p | p <- ps] )
                
                -- Create directory for each size 1..5
                cspFolders    = map (\x -> (createDirectoryIfMissing True ("GenFiles/"      ++ 
                                pName ++ "/FDR/" ++ pName ++ "_s" ++ show x)))  [1..traceSize]
                
                -- Write a CSP file for each size
                cspFiles      = map (\x -> (writeFile ("GenFiles/" ++ pName ++ "/FDR/" ++ pName ++ "_s" ++ show x ++ 
                                "/"  ++    pName    ++ "_s" ++ show x ++ ".csp") (cspfile ps x))) [1..traceSize]

                -- Write the alphabets of the process into a text file event
                events        = writeFile  ("GenFiles/" ++ pName ++ "/FDR/events")  (ishowLines (eventsNPND (head ps)))
                
                -- Create directory for Uppaal files
                uppaalFolders = map (\x -> (createDirectoryIfMissing True ("GenFiles/" ++ 
                                pName ++ "/Uppaal/" ++ pName ++ "_s" ++ show x)))  [1..traceSize]

                -- Transform the processs into TA for UPPAAL
                uppaalFiles   = map (\x -> (writeFile ("GenFiles/" ++ pName ++ "/Uppaal/" ++ pName ++ "_s" ++
                                show x ++ "/" ++ pName ++ "_s" ++ show x ++ ".xml") 
                                (fileHeader ++ show (transform (head ps) x) ))) [1..traceSize]

                monitorFolder = createDirectoryIfMissing True ("GenFiles/" ++ pName ++ "/monitor" )

                -- Transform the processs into TA for UPPAAL
                monitorTA    =  writeFile ("GenFiles/" ++ pName ++ "/monitor/" ++ pName ++ "_TA" ++ ".xml") 
                                (fileHeader ++ show (transform (head ps) 0 ))


-------------------------------------------------------------------------------------------------------------------
--6. Other functions  
-- plus sign, addExpr concatenates string with operator  
addExpr :: [String]    -> String
addExpr    []          =  ""
addExpr    [e]         =  e
addExpr    (e:es)      =  e ++ " + " ++ addExpr es

-- logical and, andExpr concatenates string with logical operator 'and'
andExpr :: [String]    -> String
andExpr    []          =  ""
andExpr    [e]         =  e
andExpr    (e:es)      =  e ++ " and " ++ andExpr es

-- Remove external choice events
removeExch    :: [Event] -> [Event]
removeExch es =  [x | x  <- es, (take 5 (reverse (show x)))  /= (reverse "_exch")]

-- Remove sync events
removeSync    :: [Event] -> [Event]
removeSync es =  [x | x  <- es, (take 5 (reverse (show x)))  /= (reverse "_sync")]

-- Only external choice events
onlyExch    :: [Event] -> [Event]
onlyExch es =  [x | x  <- es, (take 5 (reverse (show x)))  == (reverse "_exch")]

-- Only synch events
onlySync    :: [Event] -> [Event]
onlySync es =  [x | x  <- es, (take 5 (reverse (show x)))  == (reverse "_sync")]

--count :: Event -> [Event] -> Int
count :: Eq a => a -> [a] -> Int
count            e     es =  length [ne | ne <- es, ne == e]

-- Get the first element of a list of pairs
ifstdom xs = [f | (f,s) <- xs ]

-- Return a tag of an event e from sync with a string s in between
-- eTag :: Event -> [(Event, String)] -> Maybe String 
eTag :: Event -> [(Event, String)] -> String -> String 
eTag    e        []                   s         =  []
eTag    e        (x:tags)             s         =  if e == fst x then (s ++ snd x)
                                                   else eTag e tags s


checkHidingAndRenaming :: Event -> [Event] -> [(Event, Event)] -> Event
checkHidingAndRenaming    e1        hides      renames          | elem e1   hides   = ID "itau"    --  if the event is part of the hide
                                                                | elem e1   oldname = head [nn | (es, nn) <- renames, es == e1]  -- if the event is part of rename
                                                                | otherwise         = e1  -- neither
                                                    --                 | (not $ null ces) && (elem e1 hides) = 
--                                                                | otherwise       = snd (head ces)

                                                                -- Find its new rename event from the parameter rename
                                                                where  
                                                                 oldname  = [on | (on, nn)  <- renames]
--                                                                 ces  = [(es, nn) | (es, nn) <- renames, es == e1]
                                                                --            (es', nn') = head ces

-- definition of notNull
notNull = not . null

startEvent :: String      -> String -> Int  -> String
startEvent    processName    bid       sid  = 
                             if notNull processName 
                             then "startID" ++ processName
                             else "startID" ++ bid ++ "_" ++ show sid

transIntrpt :: [Event] -> Location -> Location -> [Transition]
transIntrpt    intrpts    l1          l2       =  
                     if   null intrpts 
                     then []
                     else [(Transition l2 l1 [(Sync (VariableID ((show l ) ++ "_intrpt") []) Ques)] [])|l <- intrpts]
