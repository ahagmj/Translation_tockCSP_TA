-- File structure:
--   Data type for CSP process CSPproc 
--   Brief description: to do
--   Definitions
--   Examples
--------------------------------------------------------------
module CSP where

import Data.List
import TA


---------------------------------------------------------------
-- Definition of function for generating tock-CSP file (in timed section).
cspfile       :: [NamedProc] -> Int -> String
cspfile           nps            n   =  
                     "channel " ++ ishowList (uniq ((concat (map eventsNP nps)) ++ [Tick, Tock])) ++
                     ", mark, itick" ++   "\n\n"  ++
                     "external prioritise  \n\n"  ++
                     "OneStep(_) = 0       \n\n"  ++
                     "Timed(OneStep) {     \n\n"  ++
                     ishowLines nps ++ "\n--processEnd\n\n--traceProc\n\n"                                      ++ 
                     -- "The two comments (--processEnd  -- traceProc\n\n") are used to extract and modify the CSP file.

                     (show (Proc (head nps))) ++ "t = (" ++ show (Proc (head nps))  ++
                      ";itick -> STOP) [|{"    ++ (events' [Tock] ) ++
-- factoring       ";itick -> STOP) [|{"    ++ (ishowList (uniq $ eventsNPND (head nps) \\ [Tock]) ) ++
--                     ";itick -> STOP) [|{"    ++ (ishowList (uniq $ concat (map eventsNPND nps) \\ [Tock]) ) ++
--                     "tock, itick}|] sl(" ++ show n ++")"  ++
{- without tock -}   " itick}|] sl(" ++ show n ++")"  ++

                     " \n\n} \n\n" ++
                                                               -- Condition for extracting traces
                     "sl(n) = (if n == 0 then mark -> SKIP else ([] ev : {"   ++   (events' []) ++  
--                     "sl(n) = (if n == 0 then mark -> SKIP else ([] ev : {"                                     ++
--                     " tock, itick} @ ev -> sl(n-1)))  \n\n"    ++
{- without tock -}   " itick} @ ev -> sl(n-1)))  \n\n"    ++
--{- without tock -} (ishowList $ uniq $ concat (map eventsNPND nps) ) ++ ", itick} @ ev -> sl(n-1)))"     ++ "\n\n"  ++
--  {- without tock -}  (ishowList $ uniq $ eventsNPND (head nps) ) ++ ", itick} @ ev -> sl(n-1)))"     ++ "\n\n"  ++
--                     "assert " ++ show (Proc (head nps)) ++ ":[deadlock free]"  ++
                     "assert ("++ show (Proc (head nps)) ++ ";itick -> STOP) [T= (prioritise( "              ++ 
                     (show (Proc (head nps)))  ++ "t, < {}, {mark}, {itick, tick}, {tock}> )) "              ++
                     "\n\n\n -- Definition of event deadline\n"      ++
                     "Skipu = SKIP \n"                     ++
                     "Waitu(t) = if t <= 0 then Skipu else tock -> Waitu(t-1)   \n"                  ++
                     "EDeadline(e, t) = (e -> Skipu) [|{e}|] (Waitu(t) /\\ e->Skipu) \n" 
                    where 
                    events' es = if ishowList (uniq $ eventsNPND (head nps) \\ es ) == [] then []
                                 else ishowList (uniq $ eventsNPND (head nps) \\ es ) ++ ","
                                    


              
-------------------------------------------------------------------
-- Examples for writing the tockCSP process into CSP file
write1 =  writeFile "cspfile1.csp" (cspfile [p7a, p7b] 3)

write2 =  writeFile "cspfile2.csp" (cspfile [np1, np2, np3, np4, np5, np6, np8, np9, np10, np11, np12, np13, np14] 3)
-- The processes are defined at the bottom

-------------------------------------------------------------------
-- type Name = String
type Parameter = String


-- Named CSP process ----------------------------------------------
data NamedProc = NamedProc    Name                CSPproc  
               | NamedParProc Name CSP.Parameter  CSPproc


instance Show NamedProc where
            show (NamedProc    id     proc) = id ++ " = " ++ show proc
            show (NamedParProc id par proc) = id ++ "(" ++ par ++ ")" ++ " = " ++ show proc
            

-- Events of a named process---------------------------------------
eventsNP :: NamedProc           -> [Event]
eventsNP   (NamedProc    _   p) =   events p
eventsNP   (NamedParProc _ _ p) =   events p


-- Data type for CSP process --------------------------------------
data CSPproc  =  STOP
               | Stopu
               | SKIP
               | Skipu                      -- Immediate termination              
               | WAIT         Int           -- int for now, to consider expression, but this will affect its transTA 
               | Waitu        Int           -- Strict delay
               | Prefix       Event     CSPproc
               | IntChoice    CSPproc   CSPproc
               | ExtChoice    CSPproc   CSPproc
               | Seq          CSPproc   CSPproc
               | Interleave   CSPproc   CSPproc
               | GenPar       CSPproc   CSPproc     [Event]
               | Interrupt    CSPproc   CSPproc
               | Timeout      CSPproc   CSPproc Int
               | Hiding       CSPproc   [Event]
               | Rename       CSPproc   [(Event, Event)]
               | Proc         NamedProc
               | Exception    CSPproc   CSPproc     [Event]
               -- Additional constructs for RoboChart
               | EDeadline    Event     Int   -- Strict deadline
               | ProcID       String  
               | Parproc      String    Expression
               
   
                       
instance Show CSPproc where
             show STOP                 = "STOP"
             show Stopu                = "Stopu"             
             show SKIP                 = "SKIP"
             show Skipu                = "Skipu"             
             show (WAIT       exp )    = "WAIT(" ++ show exp  ++ ")"
             show (Waitu      exp )    = "Waitu("++ show exp  ++ ")"             
             show (Prefix     e  p)    =        show e  ++  "-> ("     ++ show p       ++ ")"
             show (IntChoice  p1 p2)   = "(" ++ show p1 ++ ")|~|("     ++ show p2      ++ ")"
             show (ExtChoice  p1 p2)   = "(" ++ show p1 ++ ")[]("      ++ show p2      ++ ")"
             show (Seq        p1 p2)   = "(" ++ show p1 ++ ");("       ++ show p2      ++ ")"
             show (Interleave p1 p2)   = "(" ++ show p1 ++ ")|||("     ++ show p2      ++ ")"
             show (GenPar     p1 p2 es)= "(" ++ show p1 ++ ")[|{"      ++ ishowList es ++ "}|]("++ show p2 ++ ")"
             show (Interrupt  p1 p2)   = "(" ++ show p1 ++ ")/\\("     ++ show p2      ++ ")"
             show (Timeout    p1 p2 d) = "(" ++ show p1 ++ ")|~|(WAIT("++ show d  ++ ");(" ++ show p2 ++      "))"
--           show (Timeout    p1 p2 n )= "(" ++ show p1 ++ ")["   ++ n            ++ ">("  ++ show p2 ++ ")"  
--           ?? To discuss Timeout with Pedro
             show (Hiding     p  es)   = "(" ++ show p  ++ ")\\{" ++ ishowList es ++ "}"
             show (Rename     p  esp)  = "(" ++ show p  ++ ")[["  ++ showRen esp  ++ "]]"
                                           where showRen []          = ""
                                                 showRen [(x,y)]     = show x ++ "<-" ++ show y 
                                                 showRen ((x,y):es)  = show x ++ "<-" ++ show y ++", " ++ showRen es
             show (Proc (NamedProc id _ ))  = id
             show (Exception p1 p2 es    )  =  "(" ++ show p1 ++ ")[|{"      ++ ishowList es ++ "}|>("++ show p2 ++ ")" 
             -- Additional constructs for RoboChart
             show (EDeadline  e   n     )   = "EDeadline("++ show e ++ ", " ++ show n ++ ")"             
--             show  Skipu                    = "Skipu"   -- Immediate termination
--             show (Waitu    n       )   = "Waitu(" ++ show n ++ ")"   -- Strict delay
             show (ProcID     id     ) =  id
             show (Parproc    id n   ) =  id ++ "(" ++ show n ++ ")"

--             show (Proc       np     ) = show np         

               
-- Data type for an event ------------------------------------
data Event = ID String 
           | Tock 
           | Tick deriving Eq
           
instance Show Event where
        show (ID a) = a
        show Tock   = "tock" 
        show Tick   = "tick" 


---- Todo merge events and eventsND, they are similar.
---------------------------------------------------------------                         
-- Functions that returns a list of event for a CSP process. 
events :: CSPproc             -> [Event]
events   (ProcID     _    )   =  []   
events   (Parproc    _ _  )   =  [] 
events    STOP                =  []
events    Stopu               =  []
events    SKIP                =  [Tick] 
events   (WAIT       _  )     =  [Tock, Tick]
events   (Prefix     e p)     =  [e]      ++ events p
events   (IntChoice  p q)     =  events p ++ events q
events   (ExtChoice  p q)     =  events p ++ events q -- ++ [ID ((show e) ++ "_exch") | e <- (initials p ++ initials q)]
-- events    (ExtChoice  p q)     =  events p ++ events q
events   (Seq        p q)     =  events p ++ events q 
events   (Interleave p q)     =  events p ++ events q  
events   (GenPar     p q es)  =  events p ++ events q ++ [ID ((show e) ++ "_sync")  | e <- es]  -- for sync events declarations
events   (Interrupt  p q)     =  events p ++ events q
events   (Timeout    p q _)   =  events p ++ events q
--events    (Timeout    p q n) =  events p ++ events q
events   (Hiding     p es)    = (events p) ++ es    -- \\ es  -- to address hiding, ++ es in case of hiding non alphabet of p, for generating correct CSP file.
-- At the moment, subtraction of the hidden events. 
events   (Rename p es) =  (events p) ++ (concat (map (\(x,y) -> [x,y]) es)) 
-- events   (Rename p [(e1,e2)]) =  (events p) ++ [e2] ++ [e1]    -- \\ [e1]   ++ e1 in case of renaming non alphabet of p, for generating correct CSP file.
-- Similar to the previous one, removes the renamed events
events   (Proc  _           ) =  []
events   (Exception p  q es ) =  (events p) ++ (events q) ++ es
-- Additional constructs for RoboChart
events   (EDeadline   e  n  ) =  [e, Tock] 
events    Skipu               =  [Tick]        -- Immediate termination
events   (Waitu   _         ) =  [Tock]        -- Strict delay
-- events   (showEvents_SMovement  p _ )  = events p
-- events   ( _                ) =  []
-- events   (_           p    _)  =  events p
   

--------------------------------------------------------------
-- Gets events with no added decorations
-- Functions that returns a list of event for a CSP process. 
eventsND :: CSPproc             ->  [Event]
eventsND    (ProcID     _    )   =  []   
eventsND    (Parproc    _ _  )   =  [] 
eventsND    STOP                 =  []
eventsND    Stopu                =  []
eventsND    SKIP                 =  [Tick] 
eventsND    (WAIT    _)          =  [Tock,Tick]   -- if (n > 0) then [Tock,Tick] else [Tick] -- [Tick]
eventsND    (Waitu   _         ) =  [Tick, Tock]      -- Strict delay
eventsND    (Prefix     e p)     =  [e] ++ eventsND p
eventsND    (IntChoice  p q)     =  eventsND p ++ eventsND q
eventsND    (ExtChoice  p q)     =  eventsND p ++ eventsND q
eventsND    (Seq        p q)     =  eventsND p ++ eventsND q 
eventsND    (Interleave p q)     =  eventsND p ++ eventsND q  
eventsND    (GenPar     p q es)  =  eventsND p ++ eventsND q  -- for sync eventsND 
eventsND    (Interrupt  p q)     =  eventsND p ++ eventsND q
eventsND    (Timeout    p q _ )  =  eventsND p ++ eventsND q
eventsND    (Hiding     p es)    = (eventsND p)  ++ es  -- es    
--  Todo(for further work) Address events for hiding, ++ es in case of hiding non alphabet of p, for generating correct CSP file.                                                                      
-- At the moment, subtraction of the hidden eventsND. 
eventsND    (Rename p es) = (eventsND p) ++  (concat (map (\(x,y) -> [x,y]) es))   -- ++ [e1], 
-- Todo for further work; in case of renaming non alphabet of p,
eventsND    (Proc  _           ) =  []
eventsND    (Exception  p q es ) =  eventsND p ++ eventsND q ++ es
eventsND    (EDeadline  e  n  )  =  [e, Tock]    
eventsND    _                    =  [] 
-- Similar to the previous one, removes the renamed events
    
--------------------------------------------------------------
-- Events of named process with no added decorations
-- Modifications for eventsNPND = events of a process with no decorations
eventsNPND :: NamedProc            -> [Event]
eventsNPND   (NamedProc    _ p)     =  eventsND p
eventsNPND   (NamedParProc _ _ p)   =  eventsND p


--------------------------------------------------------------
-- Functions that returns initials of a CSP process. 
initials :: CSPproc                        ->  [Event]
initials   (ProcID      _               )   =  [] 
initials   (Parproc     _ _             )   =  []
initials    STOP                            =  []
initials    SKIP                            =  [] 
initials   (WAIT       n)                   =  []
initials   (Prefix     e p)                 =  [e]
initials   (IntChoice  p q)                 =  initials p ++ initials q
initials   (ExtChoice  p q)                 =  initials p ++ initials q
initials   (Seq        p q)                 =  initials p ++ initials q 
initials   (Interleave p q)                 =  initials p ++ initials q  
initials   (GenPar     p q es)              =  initials p ++ initials q
initials   (Interrupt  p q)                 =  initials p ++ initials q
initials   (Timeout    p q  _ )             =  initials p ++ initials q
initials   (Hiding     p es)                =((initials p) \\ es ) ++ ([(ID "itau")]) 
                                              -- (initials p) \\ es  -- To update: apply the hiding and then initials
                                              -- for the case of hiding initials
initials   (Rename     p _)                 = (initials p)        -- To update: apply the renaming and then initials
initials   (Proc      (NamedProc _  p))     =  initials p
initials   (Exception  p    q    _    )     =  initials p   
initials   (EDeadline  e    n         )     =  [e, Tock] 
initials    Skipu                           =  []        -- Immediate termination
initials   (Waitu   _         )             =  [Tock]    -- Strict delay
   
--initials    (Parproc   (NamedParProc _ _ p)) =   initials p 


--------------------------------------------------------------
-- Functions that returns ids use in the definition of process.
-- The IDs are use in the declations of the transform TA.
processIDs :: CSPproc                          -> [String]
processIDs    (ProcID     id                )  =  [id] 
processIDs    (Parproc    id _              )  =  [id]
processIDs    STOP                             =  []
processIDs    Stopu                            =  []
processIDs    SKIP                             =  []
processIDs    Skipu                            =  []        -- Immediate termination 
processIDs    (WAIT       n)                   =  []
processIDs    (Waitu  _        )               =  []        -- Strict delay
processIDs    (Prefix     e p)                 =  processIDs p
processIDs    (IntChoice  p q)                 =  processIDs p ++ processIDs q
processIDs    (ExtChoice  p q)                 =  processIDs p ++ processIDs q
processIDs    (Seq        p q)                 =  processIDs p ++ processIDs q 
processIDs    (Interleave p q)                 =  processIDs p ++ processIDs q  
processIDs    (GenPar     p q es)              =  processIDs p ++ processIDs q
processIDs    (Interrupt  p q)                 =  processIDs p ++ processIDs q
processIDs    (Timeout    p q _)               =  processIDs p ++ processIDs q
processIDs    (Hiding     p es)                = (processIDs p)   
processIDs    (Rename     p _ )                = (processIDs p)        
processIDs    (Proc       (NamedProc _  p))    =  processIDs p
processIDs    (Exception  p q _ )              =  processIDs p ++ processIDs q   
processIDs    (EDeadline  _  _  )              =  []
--processIDs    _                                =  []


-- Other examples below -------------------------------------- 
-- Example 1 -------------------------------------------------
p1 :: CSPproc
p1 = Prefix (ID "e1") STOP
-- >> e1->STOP

events1 = events p1
-- >> [e1]

np1 = NamedProc "np1" p1


-- Example 2-------------------------------------------------
p2 :: CSPproc
p2 = IntChoice (Prefix (ID "e1") STOP) (Prefix (ID "e2") SKIP)
-- >> (e1->STOP)|-|(e2->SKIP)

events2 = events p2
-- >> [e1,e2,tock]

np2 = NamedProc "np2" p2


-- Example 3 ------------------------------------------------
p3 :: CSPproc
p3 = ExtChoice (Prefix (ID "e1") STOP) (Prefix (ID "e2") SKIP)
-- >> (e1->STOP)[](e2->SKIP)

events3 = events p3
-- >> [e1,e2,tock]

np3 = NamedProc "np3" p3

-- Example 4 -----------------------------------------------
p4 :: CSPproc
p4 = Hiding (Prefix (ID "e1") STOP)  [(ID "e1")]
-- >> (e1->STOP)\{e1}

events4 = events p4
-- >> [] 

np4 = NamedProc "np4" p4

-- Example 5 -----------------------------------------------
p5 :: CSPproc
p5 = Rename (Prefix (ID "e1") STOP)  [(ID "e1", ID "e2")]
-- >> (e1->STOP)[[e1<-e2]]

events5 = events p5
-- >> [ID "e2"]

np5 = NamedProc "np5" p5

-- Example 6 : Recursive------------------------------------
-- p3 :: CSPproc
-- p3 = ExtChoice (Prefix (ID "e1") np3) (Prefix (ID "e2") SKIP)
-- >> (e1->STOP)[](e2->SKIP)

-- events3 = events p3
-- >> [e1,e2,tock]

np6 = NamedProc "np6" (ExtChoice (Prefix (ID "e1") (Proc np6)) (Prefix (ID "e2") SKIP))

-- Example 7 : Mutual recursion ----------------------------

p7a, p7b :: NamedProc
p7a      =  NamedProc "p7a" (Prefix (ID "e1") (Proc p7b))
p7b      =  NamedProc "p7b" (Prefix (ID "e2") (Proc p7a))


-- Example 8 : Parameterised process ----------------------
np8 = NamedParProc "np8" "n" (Seq ( WAIT 3) (ExtChoice (Prefix (ID "e1") (Proc np6)) (Prefix (ID "e2") SKIP)))
--np8 = NamedParProc "np8" "n" (Seq ( $ Val 3) (ExtChoice (Prefix (ID "e1") (Proc np6)) (Prefix (ID "e2") SKIP)))


-- Example 9 : Recursion with parameterised process -------
np9 = NamedParProc "np9" "n" (Seq ( WAIT 3) (ExtChoice (Prefix (ID "e1") (ProcID "np9" )) (Prefix (ID "e2") SKIP)))
-- np9 = NamedParProc "np9" "n" (Seq ( $ Val 3) (ExtChoice (Prefix (ID "e1") (Parproc np9 )) (Prefix (ID "e2") SKIP)))


-- Example 10 ---------------------------------------------
np10 = NamedProc "np10" (GenPar (Prefix (ID "e1") STOP) (Prefix (ID "e2") SKIP) [(ID "e1")])
-- np10 = (e1-> (STOP))[|{e1}|](e2-> (SKIP))


-- Example 11 ---------------------------------------------
np11 = NamedProc "np11" (Interrupt (Prefix (ID "e1") STOP) (Prefix (ID "e2") SKIP) )
-- np11 = (e1-> (STOP))/\(e2-> (SKIP))


-- Example 12 ---------------------------------------------
np12 = NamedParProc "np12" "n" (Timeout (Prefix (ID "e1") (Proc np6)) (Prefix (ID "e2") SKIP)  5)
-- np12 = NamedParProc "np12" "n" (Timeout (Prefix (ID "e1") (Proc np6)) (Prefix (ID "e2") SKIP) "n" )


-- Example 13 ---------------------------------------------
np13 = NamedProc "np13" (Hiding (Prefix (ID "e1") STOP) [(ID "e1")])


-- Example 14 ---------------------------------------------
np14 = NamedProc "np14" (Rename (Prefix (ID "e1") STOP) [((ID "e1"), (ID "e5"))])
            
            
-- Example 15 ------------------------------------------------
p15 :: CSPproc
p15 = Timeout (Prefix (ID "e1") STOP) (Prefix (ID "e2") SKIP) 5
-- (e1-> (STOP))|~|(WAIT(5);e2-> (SKIP))


-- Example 16 ------------------------------------------------
np16 :: NamedProc
np16 = NamedProc "np16" (EDeadline (ID "e1") 3)
-- np16 = EDeadline(e1, 3)


-- Example 17 ------------------------------------------------
np17 :: NamedProc
np17 = NamedProc "np17" (Skipu)
-- np17 = Skipu


-- Example 18 ------------------------------------------------
np18 :: NamedProc
np18 = NamedProc "np18" (Waitu 3)
-- np18 = Waitu(3)


-- Example 19 ---------------------------------------------
np19 = NamedProc "np19" (Exception (Prefix (ID "e1") STOP) (Prefix (ID "e2") SKIP) [(ID "e1")])
-- ev   =  events (Exception (Prefix (ID "e1") STOP) (Prefix (ID "e2") SKIP) [(ID "e1")])
--np19 = (e1-> (STOP))[|{e1}|>(e2-> (SKIP))


-----------------------------------------------------------
-- An existing function get only unique elements from a list, and avoids all multiple occurances. 
-- The function unique from Data.List.Unique 
-- Removing duplicates with this utility function, which reades the first element and removes all subsequent ocurances of that element in a list.
uniq :: Eq a => [a]           -> [a]
uniq         = foldl (\seen x -> if   x `elem` seen
                                 then seen
                                 else seen ++ [x]) []
--https://stackoverflow.com/questions/16108714/removing-duplicates-from-a-list-in-haskell
-----------------------------------------------------------
