# This Bash script program generates monitor for verifying traces.
# The program reads trace and generates monitor that replaces the TA envioronment in the collections of TA that describes UPPAAL system. And then subsequently invokes UPPAAL tool for verifying the input trace. 



#!/bin/bash
#TODO: Collect the verification result from the monitor and then generalising the procedure.


# Function for generating  monitor for each trace
function genMonitorFun(){

    lineNo=1
    while IFS='' read -r line || [[ -n "$line" ]]; do
        echo "Text read from file: $line" $lineNo
        runhaskell genMonitor.hs  "$lineNo" "$line"   $3  $2     $(basename $(dirname $3))
                              #    [lineNo, trace,  dr, taFile, pName] <- getArgs
        lineNo=$(($lineNo + 1))
    done < $1
}


# Each process in the examples pass its monitor trace, traces that need to be verify with monitor
for i in GenFiles/*/monitor ; do
     genMonitorFun  $i/traceForMonitor*  $i/*TA.xml   $i
done


# Verify with the monitor -----------------
for d in GenFiles/*/monitor/monitor* ; do
      ./verifyta -t1 -X  "$d"trace  $d

      #Extract edges  
      ((sed 's|</|\n|g' | grep -o -P '(?<=<sync>).*|(?<=<edge id=").*(?=" from=)') | sed 's|\n+|,|g' )   \
      <"$d"trace1.xml  >"$(dirname $d)"/tmp    

      #Extract transitions
      ((sed 's|<transition|\n|g' | grep -o -P '(?<= edges=").*(?="/>)') | sed 's|\n+|,|g' )  \
      <"$d"trace1.xml  >"$(dirname $d)"/tmpT    

     #Collet the generated the trace from monitor
     runhaskell traceUPPAAL.hs "$(dirname $d)"/tmp  We "$(dirname $d)"/tmpT   $(dirname $d)

done



#Update trace result with verification result using monitor
for i in GenFiles/* ; do
    # Separate the traces with the following string
    echo $'\n\n\n'$(basename $i)" accepted traces with monitor --------------------------" >> $i/traceSetComparison
    cat $i/monitor/traceRes >> $i/traceSetComparison
done

#------------------------------------------------------------------------------
#Brief structure of the algorithm
#Read each line of trace
#GenMonitor and update TA with new query
#Invoke UPPAAL for verification with the new file
#Save the result in another file
#------------------------------------------------------------------------------

