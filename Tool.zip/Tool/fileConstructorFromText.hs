-- File structure
--   Brief description of the file: 
--      This program reads the AST of CSP from the terminal and constructs a .csp file for FDR.

-----------------------------------------------------------------
import System.Environment   
import System.Directory  
import System.IO  
import Data.List
import TA

-------------------------------------------------------------------------------------------------------------------------
main = do 
        -- Read the input files as argument, FDR trace, Uppaal trace, directory and process name
        astText <- getArgs
--        astText   <- readFile astFile
--        astText <- getLine

        writeFile  ("prompt.hs")  (fileFrame ++ ((init $ tail (unwords astText))) ++ "]")        
--        writeFile  ("prompt.hs")  (fileFrame ++ (ishowListSt astText) ++ "]")
--        writeFile  (astFile ++ ".hs")  (fileFrame ++ (ishowListSt (lines astText)) ++ "]")        
        
        
fileFrame = 
    "import TF \nimport CSP \nimport TA  \nimport Data.List \nimport System.Directory  \n\n" ++
    "main  = do print \"start\"  \n\n" ++ 
    "           createDirectoryIfMissing True \"GenFiles\" \n\n" ++  
    "           genFiles 5 ["        
