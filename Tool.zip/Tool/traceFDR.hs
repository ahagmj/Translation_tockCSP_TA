import qualified Data.Text as T
import qualified Data.Text.IO as TIO
import TA
import Data.List.Split as S
import System.Environment   
import System.Directory  
import System.IO  
import Data.List 


-- ?To revise this later?
main = do 
        [tf, dr] <- getArgs
        ts       <- readFile tf
        writeFile (dr ++ "/trace") ("Process " ++ dr ++ "\n\n" ++ tracesFDR ts ++ "\n\n-------------\n")


--function for generating FDR traces
tracesFDR :: String -> String
tracesFDR    s      = if ((removeSpace $ head ls) == "1") then "Pass, no counter example"     
                      else "FDR trace \n[" ++ ishowListSt traceFDR ++  "]"   -- \n\nUPPAAL trace\n[" ++
                      where ls          = lines s
                            ls1         = head $ S.splitOn ",states"  (ls!!1)
                            traceFDR    = removeTau (isubs (map show (read(ls1)::[Int]))  -- (read(ls!!1)::[Int])) 
                                               (map removeSpace (splitOneOf ":," (ls!!2))))



-- Substitutes all event nos with event names es using the event mapppings emaps from the FDR trace
isubs :: [String]  -> [String]           -> [String]
isubs    es           []                 =  es
isubs    es           [y]                =  es
isubs    es           (eNo:eName:emaps)  =  isubs (ireplace eNo eName es) emaps

-- Replace each event with its corresponding name
ireplace :: String -> String -> [String] -> [String]
ireplace    old       new       []       =  []
ireplace    old       new       (z:zs)   =  if(old == z) then new:(ireplace old new zs)
                                            else z:(ireplace old new zs)

-- Removes spaces at the begining of a string
removeSpace :: String -> String
removeSpace (' ':ss)  =  ss
removeSpace  ss       =  ss

removeTau :: [String] -> [String]
removeTau    []        = []
removeTau    (x:xs)    | (x == "0") = removeTau xs
                       | otherwise  = [x] ++ removeTau xs   



