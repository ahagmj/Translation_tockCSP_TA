-- Program descripetion: 
--------------------------------------------------------------------------
import qualified Data.Text as T
import qualified Data.Text.IO as TIO
import Data.List.Split as S
import System.Environment   
import System.Directory  
import System.IO  
import Data.List 
import qualified Data.ByteString.Char8 as B

import TA
import CSP



main = do 
        [taF, traceF]  <- getArgs
        taC            <- B.readFile taF
        traceC         <- B.readFile traceF        
        B.writeFile taF  (B.pack (updateTA (B.unpack taC, B.unpack traceC)))


-- Update the TA file with a predicate to block the path of the generated trace        
updateTA :: (String, String) -> String
updateTA    (ta, trace)     =  (ls !! 0) ++ qUpdate ++ (ls !! 1)
                                  where
                                     ls       = S.splitOn ") \n</formula>"  ta
                                     qUpdate  = " and (not (" ++ (intercalate " and" traceL) ++ ")) ) \n</formula>"
                                     traceL   = if null (last t) then init t else t   -- Remove the last empty string
                                     t        = S.splitOn "\n" trace
                                           

