-------------------------------------------------------------------------------
-- CFootBot,  AST for the relevant part of CFootBot model 
-- The generated model from RoboTool has four files, CFootBot.csp, Movement.csp, SMovement.csp and move.csp
-------------------------------------------------------------------------------
module CFootBot_AST where

import CSP   -- Import AST of CSP
import TF
import Data.List  
import Data.List.Split



main  = do
        genFiles 1 [cFootBot, ns_SMovement_Moving, ns_SMovement_Turning]


-------------------------------------------------------------------------------------------
-- CFootBot, AST for the file CFootBot.csp
-------------------------------------------------------------------------------------------
{-- 
Timed(OneStep) {
	
-- declaring module memory

CFootBot_visibleMemoryEvents = {||}
		
Memory_CFootBot_FootBot = SKIP

CFootBot = prioritise(	(Movement[[Movement_terminate <- CFootBot_terminate, Movement_obstacle <- obstacle]]
	[|union({||},
	{||})|]
	Memory_CFootBot_FootBot
	)\union({||},{||}),<CFootBot_visibleMemoryEvents,{tock}>)
	[|{|CFootBot_terminate|}|>SKIP
	
-- visible state equivalent

CFootBot_VS = prioritise(	(Movement_VS[[Movement_terminate <- CFootBot_terminate, Movement_obstacle <- obstacle]]
	[|union({||},
	{||})|]
	Memory_CFootBot_FootBot
	)\union({||},{||}),<CFootBot_visibleMemoryEvents,{tock}>)
	[|{|CFootBot_terminate|}|>SKIP
}	
--}
--------------------------------------------------------------------------------------------------
-- Since CFootBot_visibleMemoryEvents = {||} 
-- and Memory_CFootBot_FootBot = SKIP
-- then from the process CFootBot above, CFootBot becomes 
-- Movement[[Movement_terminate <- CFootBot_terminate, Movement_obstacle <- obstacle]
cFootBot = NamedProc "CFootBot" (Rename movement [ ((ID "Movement_terminate"), (ID "CFootBot_terminate")), -- ]) --,
                                                   ((ID "Movement_obstacle"),  (ID "obstacle")) ])

---------------------------------------------------------------------
-- Movement,  AST for the file Movement.csp         
---------------------------------------------------------------------------------
{--
Timed(OneStep) {
	
-- declaring controller memory

Movement_visibleMemoryEvents = {||}
		
Memory_Movement = SKIP
	
Movement = prioritise(wbisim(SMovement[[SMovement_terminate <- Movement_terminate, SMovement_obstacle <- Movement_obstacle]]
			[|union({||},
			{||})|]
			Memory_Movement
			)\union({||},
			{||}),<Movement_visibleMemoryEvents,{tock}>)
			[|{|Movement_terminate|}|>SKIP
-- VS version
Movement_VS = prioritise(wbisim(SMovement_VS[[SMovement_terminate <- Movement_terminate, SMovement_obstacle <- Movement_obstacle]]
			[|union({||},
			{||})|]
			Memory_Movement
			)\union({||},
			{||}),<Movement_visibleMemoryEvents,{tock}>)
			[|{|Movement_terminate|}|>SKIP
}
--}
-------------------------------------------------------------------------------- 
-- Since  Movement_visibleMemoryEvents = {||} 
-- and Memory_Movement = SKIP
-- then process Movement becomes SMovement[[SMovement_terminate <- Movement_terminate, SMovement_obstacle <- Movement_obstacle]]
movement = Rename sMovement [((ID "SMovement_terminate"), (ID "Movement_terminate")), 
                             ((ID "SMovement_obstacle"),  (ID "Movement_obstacle" )) ]


--------------------------------------------------------------------------------
-- SMovement, AST for the file SMovement.csp
--------------------------------------------------------------------------------
{--
Timed(OneStep) {

-- channel SMovement_enteredV, SMovement_exitV : SMovement_SIDS

-- declare clocks
SMovement_Clocks = {"MBC"}
channel SMovement_clockReset : SMovement_Clocks


-- declare deadlines
channel SMovement_deadline : SMovement_TIDS.Signal

-- compile waiting conditions

SMovement_WC_enablerSet = {"WC_SMovement_t3_0"}

channel SMovement_WC : SMovement_WC_enablerSet.Bool

SMovement_WCset = { ({|SMovement_internal__."SMovement_t3",SMovement_clockReset."MBC",SMovement_WC."WC_SMovement_t3_0"|},WC_SMovement_t3_0) }

SMovement_WCsync = {|SMovement_internal__."SMovement_t3"|}

SMovement_WCresets = {|SMovement_clockReset."MBC"|}

WC_SMovement_t3_0_reset = SMovement_clockReset."MBC" -> SMovement_WC."WC_SMovement_t3_0".false -> WC_SMovement_t3_0_body

WC_SMovement_t3_0_body = (TimedInterrupt(RUN({|SMovement_internal__."SMovement_t3",tock|}),(SMovement_PI / SMovement_av)) ; SMovement_WC."WC_SMovement_t3_0".true -> RUN({|SMovement_internal__."SMovement_t3",tock|})) /\ WC_SMovement_t3_0_reset

WC_SMovement_t3_0 = RUN({|SMovement_internal__."SMovement_t3",tock|}) /\ WC_SMovement_t3_0_reset

SMovement_WaitingConditions = || (alpha, P) : SMovement_WCset @ [alpha] wbisim(P)

CS_SMovement_Moving_sync = {|
	SMovement_enter.y.x, 
	SMovement_entered.y.x, 
	SMovement_exit.y.x, 
	SMovement_exited.y.x,
	SMovement_enter.x.y, 
	SMovement_entered.x.y, 
	SMovement_exit.x.y, 
	SMovement_exited.x.y |
	x <- {"SMovement_Moving","SMovement_Turning"},
	y <- {"SMovement_Moving"}
|}



S_SMovement_Moving = let
	T_SMovement_t2	= SMovement_obstacle__!"SMovement_t2" -> DoClockReset({SMovement_clockReset."MBC"}) ;  (					SKIP;
						SMovement_enter!"SMovement_Moving"!"SMovement_Turning" -> SMovement_entered!"SMovement_Moving"!"SMovement_Turning" ->
						S_SMovement_Moving
	)
	

	S_SMovement_Moving_execute(o__) = 
	(EDeadline(moveCall,0) ; move(SMovement_lv,0); EDeadline(moveRet,0)); WAIT(1); 
	SMovement_entered!o__!"SMovement_Moving" ->
	   (SKIP
	   										; STOP /\ (
	   											    T_SMovement_t2
	   											    []
	   											    SMovement_internal__?x:diff(SMovement_TIDS,{"__NULLTRANSITION__","SMovement_t2"}) ->
	   											      SMovement_exit?y:diff(SMovement_SIDS,{"SMovement_Moving"})!"SMovement_Moving" -> (
	   											      	SKIP;
	   											      	SMovement_exited!y!"SMovement_Moving" -> SKIP);
	   											      	S_SMovement_Moving
	   											    [] SMovement_obstacle__?x:diff(SMovement_TIDS,{"__NULLTRANSITION__","SMovement_t2"}) ->
	   											      SMovement_exit?y:diff(SMovement_SIDS,{"SMovement_Moving"})!"SMovement_Moving" -> (
	   											      	SKIP;
	   											      	SMovement_exited!y!"SMovement_Moving" -> SKIP);
	   											      	S_SMovement_Moving
	   											    )
	   										)
within
SMovement_enter?x:diff(SMovement_SIDS,{"SMovement_Moving"})!"SMovement_Moving" -> ( 
	S_SMovement_Moving_execute(x)) 
CS_SMovement_Turning_sync = {|
	SMovement_enter.y.x, 
	SMovement_entered.y.x, 
	SMovement_exit.y.x, 
	SMovement_exited.y.x,
	SMovement_enter.x.y, 
	SMovement_entered.x.y, 
	SMovement_exit.x.y, 
	SMovement_exited.x.y |
	x <- {"SMovement_Moving","SMovement_Turning"},
	y <- {"SMovement_Turning"}
|}



S_SMovement_Turning = let
	T_SMovement_t3	= SMovement_internal__!"SMovement_t3" ->  					SKIP;
						SMovement_enter!"SMovement_Turning"!"SMovement_Moving" -> SMovement_entered!"SMovement_Turning"!"SMovement_Moving" ->
						S_SMovement_Turning
	

	S_SMovement_Turning_execute(o__) = 
	(EDeadline(moveCall,0) ; move(0,SMovement_av); EDeadline(moveRet,0)); 
	SMovement_entered!o__!"SMovement_Turning" ->
	   (SKIP
	   										; STOP /\ (
	   											    T_SMovement_t3
	   											    []
	   											    SMovement_internal__?x:diff(SMovement_TIDS,{"__NULLTRANSITION__","SMovement_t3"}) ->
	   											      SMovement_exit?y:diff(SMovement_SIDS,{"SMovement_Turning"})!"SMovement_Turning" -> (
	   											      	SKIP;
	   											      	SMovement_exited!y!"SMovement_Turning" -> SKIP);
	   											      	S_SMovement_Turning
	   											    [] SMovement_obstacle__?x:diff(SMovement_TIDS,{"__NULLTRANSITION__","SMovement_t3"}) ->
	   											      SMovement_exit?y:diff(SMovement_SIDS,{"SMovement_Turning"})!"SMovement_Turning" -> (
	   											      	SKIP;
	   											      	SMovement_exited!y!"SMovement_Turning" -> SKIP);
	   											      	S_SMovement_Turning
	   											    )
	   										)
within
SMovement_enter?x:diff(SMovement_SIDS,{"SMovement_Turning"})!"SMovement_Turning" -> ( 
	S_SMovement_Turning_execute(x)) 

I_SMovement_i1 = T_SMovement_t1

SMovement_int_int = {|
	SMovement_obstacle__."SMovement_t2",
SMovement_internal__."SMovement_t2",
	SMovement_obstacle__."SMovement_t3",
SMovement_internal__."SMovement_t3"
|}


T_SMovement_t1	= SMovement_enter!"SMovement"!"SMovement_Moving" -> SMovement_entered!"SMovement"!"SMovement_Moving" ->
SKIP

S_SMovement_Moving_R = S_SMovement_Moving
 		[|diff(SMovement_int_int,SMovement_Moving_triggers)|]
 		SKIP
 		
S_SMovement_Turning_R = S_SMovement_Turning
 		[|diff(SMovement_int_int,SMovement_Turning_triggers)|]
 		SKIP
 		
 		
STM_SMovement = ShowEvents_SMovement(I_SMovement_i1
[|{|SMovement_enter.x.y,
		SMovement_entered.x.y,
		SMovement_exit.x.y,
		SMovement_exited.x.y |
		x <- diff(SMovement_SIDS,{"SMovement_Moving","SMovement_Turning"}),
		y <- {"SMovement_Moving","SMovement_Turning"}
|}|]
ShowEvents_SMovement(S_SMovement_Moving_R
  [|inter(CS_SMovement_Moving_sync,CS_SMovement_Turning_sync)|]
 S_SMovement_Turning_R,inter(CS_SMovement_Moving_sync,CS_SMovement_Turning_sync))\inter(CS_SMovement_Moving_sync,CS_SMovement_Turning_sync)
 	,{|SMovement_enter,SMovement_entered,
 	SMovement_exit,SMovement_exited|})\
 	SMovement_internal_events


-- memory process
channel getWC_SMovement : SMovement_WC_enablerSet.Bool


Memory_SMovement_WC_SMovement_t3_0(WC_SMovement_t3_0) = (
getWC_SMovement."WC_SMovement_t3_0"!WC_SMovement_t3_0 -> Memory_SMovement_WC_SMovement_t3_0(WC_SMovement_t3_0)
[]
SMovement_WC."WC_SMovement_t3_0"?x__ -> Memory_SMovement_WC_SMovement_t3_0(x__)
)

MemoryTransitions_SMovement = (getWC_SMovement."WC_SMovement_t3_0"?WC_SMovement_t3_0 ->
(SMovement_obstacle__!"SMovement_t2" -> MemoryTransitions_SMovement
[]
(WC_SMovement_t3_0)&(SMovement_internal__!"SMovement_t3" -> MemoryTransitions_SMovement)
[]
SMovement_WC."WC_SMovement_t3_0"?x__ -> MemoryTransitions_SMovement))


MemoryVariablesProcesses_SMovement = {(Memory_SMovement_WC_SMovement_t3_0(false),{|getWC_SMovement."WC_SMovement_t3_0",SMovement_WC."WC_SMovement_t3_0"|})}

MemoryVariables_SMovement = ||| (P, alpha) : MemoryVariablesProcesses_SMovement @ P
MemoryVariablesSyncSet_SMovement = {|getWC_SMovement."WC_SMovement_t3_0",
SMovement_WC."WC_SMovement_t3_0"|}
MemoryVariablesHideSet_SMovement = {|getWC_SMovement|}

MemoryN_SMovement = (wbisim(MemoryVariables_SMovement) [| MemoryVariablesSyncSet_SMovement |] wbisim(MemoryTransitions_SMovement)) \ MemoryVariablesHideSet_SMovement

Memory_SMovement(WC_SMovement_t3_0) = (
SMovement_WC."WC_SMovement_t3_0"?x__ -> Memory_SMovement(x__)
[]
SMovement_obstacle__!"SMovement_t2" -> Memory_SMovement(WC_SMovement_t3_0)
[]
(WC_SMovement_t3_0)&(SMovement_internal__!"SMovement_t3" -> Memory_SMovement(WC_SMovement_t3_0))
)

MemoryO_SMovement = Memory_SMovement(false)

-- main process
SMovement_aux = prioritise(timed_priority(((wbisim(STM_SMovement)
	[|Union({
		{||},
		{|SMovement_obstacle__."SMovement_t2",
		SMovement_internal__."SMovement_t3"|}
		,
		{|SMovement_deadline|},
		SMovement_WCresets
	})|]
	(wbisim(MemoryN_SMovement) [| union({|SMovement_WC|},SMovement_WCsync) |] SMovement_WaitingConditions)\{|SMovement_WC|}
)[[SMovement_obstacle__.x <- SMovement_obstacle| x<-SMovement_TIDS]]\union({||},{|SMovement_deadline,SMovement_clockReset|}))
[|{|SMovement_terminate|}|>SKIP\{|SMovement_internal__|}),<{|SMovement_enteredV,SMovement_enterV,SMovement_exitV,SMovement_exitedV|},{tock}>)

SMovement = timed_priority(SMovement_aux \ {|SMovement_enteredV, SMovement_enterV, SMovement_exitV, SMovement_exitedV|})
SMovement_VS = SMovement_aux
}
End of file SMovement.csp   --}
------------------------------------------------------------------------------------------
{--
CS_SMovement_Moving_sync = {|
    SMovement_enter.y.x, 
    SMovement_entered.y.x, 
    SMovement_exit.y.x, 
    SMovement_exited.y.x,
    SMovement_enter.x.y, 
    SMovement_entered.x.y, 
    SMovement_exit.x.y, 
    SMovement_exited.x.y |
    x <- {"SMovement_Moving","SMovement_Turning"},
    y <- {"SMovement_Moving"}
|}
--}
cS_SMovement_Moving_sync = concat [[
    (ID ("SMovement_enter"     ++ y ++ x)), 
    (ID ("SMovement_entered"   ++ y ++ x)), 
    (ID ("SMovement_exit"      ++ y ++ x)), 
    (ID ("SMovement_exited"    ++ y ++ x)),
    (ID ("SMovement_enter"     ++ y ++ y)), 
    (ID ("SMovement_entered"   ++ x ++ y)), 
    (ID ("SMovement_exit"      ++ x ++ y)), 
    (ID ("SMovement_exited"    ++ x ++ y))]  |
    x <- ["_SMovement_Moving","_SMovement_Turning"],
    y <- ["_SMovement_Moving"]
    ]


{--
S_SMovement_Moving = let
     -- C2 --
    T_SMovement_t2    = SMovement_obstacle__!"SMovement_t2" -> DoClockReset({SMovement_clockReset."MBC"});
                     (SKIP; SMovement_enter!"SMovement_Moving"!"SMovement_Turning" ->
                     SMovement_entered!"SMovement_Moving"!"SMovement_Turning" ->
                     S_SMovement_Moving    )
    
    -- C3 --
    S_SMovement_Moving_execute(o__) = 
        (EDeadline(moveCall,0) ; move(SMovement_lv,0); EDeadline(moveRet,0)); WAIT(1); 
        SMovement_entered!o__!"SMovement_Moving" ->
        (SKIP; STOP /\ ( T_SMovement_t2
                           []
                           SMovement_internal__?x:diff(SMovement_TIDS,{"__NULLTRANSITION__","SMovement_t2"}) ->
                           SMovement_exit?y:diff(SMovement_SIDS,{"SMovement_Moving"})!"SMovement_Moving" -> (
                           SKIP;SMovement_exited!y!"SMovement_Moving" -> SKIP);S_SMovement_Moving
                           [] SMovement_obstacle__?x:diff(SMovement_TIDS,{"__NULLTRANSITION__","SMovement_t2"}) ->
                           SMovement_exit?y:diff(SMovement_SIDS,{"SMovement_Moving"})!"SMovement_Moving" -> (
                           SKIP;SMovement_exited!y!"SMovement_Moving" -> SKIP);
                           S_SMovement_Moving
                           )
    )
    within
    -- C1 --
    SMovement_enter?x:diff(SMovement_SIDS,{"SMovement_Moving"})!"SMovement_Moving" -> 
    (S_SMovement_Moving_execute(x))

Since sMovement_SIDS = ["SMovement", "SMovement_Moving", "SMovement_Turning"]
--}



{-- C1 --
-- Simplification and resolve the external choice
S_SMovement_Moving = SMovement_enter?x:diff(SMovement_SIDS,{"SMovement_Moving"})!"SMovement_Moving" -> 
        (S_SMovement_Moving_execute(x))
=> S_SMovement_Moving = SMovement_enter?x:{ "SMovement", "SMovement_Turning" } !"SMovement_Moving" -> 
        (S_SMovement_Moving_execute(x))
=> S_SMovement_Moving = SMovement_enter?SMovement!SMovement_Moving -> (S_SMovement_Moving_execute(x))
                     []
                     SMovement_enter?SMovement_Turning!SMovement_Moving -> (S_SMovement_Moving_execute(x))
--}
-- AST of the process S_SMovement_Moving, 
-- After simplifying "diff(SMovement_SIDS,{"SMovement_Moving"}" that introduce external choice.
s_SMovement_Moving :: CSPproc
s_SMovement_Moving =  ExtChoice
          (Prefix (ID "SMovement_enter_SMovement_SMovement_Moving"        ) (s_SMovement_Moving_execute "SSMovement" ))
          (Prefix (ID "SMovement_enter_SMovement_Turning_SMovement_Moving") (s_SMovement_Moving_execute "SSMovement_Turning"))

ns_SMovement_Moving :: NamedProc
ns_SMovement_Moving =  NamedProc "S_SMovement_Moving" s_SMovement_Moving


-- C2 --
-- AST of the process T_SMovement_t2
{-- Resolve the multipart events
T_SMovement_t2    = SMovement_obstacle__!"SMovement_t2" -> DoClockReset({SMovement_clockReset."MBC"})
                     (SKIP; SMovement_enter!"SMovement_Moving"!"SMovement_Turning" ->
                     SMovement_entered!"SMovement_Moving"!"SMovement_Turning" ->
                     S_SMovement_Moving    )
--}
t_SMovement_t2 :: CSPproc
t_SMovement_t2 =  Seq 
                  (Prefix (ID "SMovement_obstacle___SMovement_t2") (doClockReset "SMovement_clockReset_MBC" ))
                  (Seq (SKIP) 
                       (Prefix (ID "SMovement_enter_SMovement_Moving_SMovement_Turning") 
                       ((Prefix (ID "SMovement_entered_SMovement_Moving_SMovement_Turning")
                         (ProcID "S_SMovement_Moving")))
                         )
                  )
                   

{--
    S_SMovement_Moving_execute(o__) = 
        (EDeadline(moveCall,0) ; move(SMovement_lv,0); EDeadline(moveRet,0)); WAIT(1); 
        SMovement_entered!o__!"SMovement_Moving" ->
        (SKIP; STOP /\ ( T_SMovement_t2
                           []
                           SMovement_internal__?x:diff(SMovement_TIDS,{"__NULLTRANSITION__","SMovement_t2"}) ->
                           SMovement_exit?y:diff(SMovement_SIDS,{"SMovement_Moving"})!"SMovement_Moving" -> (
                           SKIP;SMovement_exited!y!"SMovement_Moving" -> SKIP);S_SMovement_Moving
                           [] SMovement_obstacle__?x:diff(SMovement_TIDS,{"__NULLTRANSITION__","SMovement_t2"}) ->
                           SMovement_exit?y:diff(SMovement_SIDS,{"SMovement_Moving"})!"SMovement_Moving" -> (
                           SKIP;SMovement_exited!y!"SMovement_Moving" -> SKIP);
                           S_SMovement_Moving
                           )
        )
--}                   
-- C3--
-- AST of the S_SMovement_Moving_execute  
s_SMovement_Moving_execute o__ = 
    Seq (Seq (EDeadline (ID "moveCall") 0 ) (Seq  (move sMovement_lv 0)  (EDeadline (ID "moveRet")  0) ) )
        (Seq (Wait 1 ) 
            (Prefix (ID ("SMovement_entered_" ++ o__ ++ "_SMovement_Moving"))
            (Seq SKIP 
              (Interrupt STOP 
                  (ExtChoice  
                    (ExtChoice t_SMovement_t2
                       (Prefix (ID "SMovement_internal__SMovement_t3")
                               (ExtChoice 
                               (Prefix (ID "SMovement_exit_SMovement_SMovement_Moving")
                               (Seq SKIP 
                                   (Seq (Prefix (ID "SMovement_exited_SMovement_SMovement_Moving") SKIP)
                                   (ProcID "S_SMovement_Moving"))))
                               (Prefix (ID "SMovement_exit_SMovement_Turning_SMovement_Moving") 
                                   (Seq SKIP 
                                       (Seq (Prefix (ID "SMovement_exited_SMovement_Turning_SMovement_Moving") SKIP)
                                       (ProcID "S_SMovement_Moving")
                                       )))     )   )   )
                       (Prefix (ID "SMovement_obstacle___SMovement_t3") 
                       (ExtChoice
                           (Prefix (ID "SMovement_exit_SMovement_SMovement_Moving") 
                               (Seq SKIP 
                                    (Seq (Prefix (ID "SMovement_exited_SMovement_SMovement_Moving")  SKIP)
                                          (ProcID "S_SMovement_Moving"))
                           ))
                           (Prefix (ID "SMovement_exit_SMovement_Turning_SMovement_Moving") 
                           (Seq SKIP 
                               (Seq (Prefix (ID "SMovement_exited_SMovement_Turning_SMovement_Moving") SKIP)
                                    (ProcID "S_SMovement_Moving"))
                           ))
                       ))
                       ))))
    )                


-------------------------------------------------------------------------                   
{--
S_SMovement_Turning = let
    -- C5 --
    T_SMovement_t3    = SMovement_internal__!"SMovement_t3" -> SKIP;
                      SMovement_enter!"SMovement_Turning"!"SMovement_Moving" ->
                      SMovement_entered!"SMovement_Turning"!"SMovement_Moving" ->
                      S_SMovement_Turning
    
    -- C6 --
    S_SMovement_Turning_execute(o__) = (EDeadline(moveCall,0) ; move(0,SMovement_av); EDeadline(moveRet,0)); 
                      SMovement_entered!o__!"SMovement_Turning" ->
                      (SKIP; STOP /\ (T_SMovement_t3
                                         []
                                   SMovement_internal__?x:diff(SMovement_TIDS,{"__NULLTRANSITION__","SMovement_t3"}) ->
                                   SMovement_exit?y:diff(SMovement_SIDS,{"SMovement_Turning"})!"SMovement_Turning" -> (
                                   SKIP;SMovement_exited!y!"SMovement_Turning" -> SKIP);
                                   S_SMovement_Turning
                                   [] 
                                   SMovement_obstacle__?x:diff(SMovement_TIDS,{"__NULLTRANSITION__","SMovement_t3"}) ->
                                   SMovement_exit?y:diff(SMovement_SIDS,{"SMovement_Turning"})!"SMovement_Turning" -> (
                                   SKIP; SMovement_exited!y!"SMovement_Turning" -> SKIP);
                                   S_SMovement_Turning
                                   )
                       )
    within
    -- C4 --
    SMovement_enter?x:diff(SMovement_SIDS,{"SMovement_Turning"})!"SMovement_Turning" -> ( 
    S_SMovement_Turning_execute(x)) 
--}

 -- C4 --
-- AST for the S_SMovement_Turning,
s_SMovement_Turning :: CSPproc
s_SMovement_Turning = ExtChoice
                      (Prefix (ID "SMovement_enter_SMovement_SMovement_Turning")
                            (s_SMovement_Turning_execute "SMovement" ))
                      (Prefix (ID "SMovement_enter_SMovement_Turning_SMovement_Turning")
                            (s_SMovement_Turning_execute "SMovement_Turning" ))

ns_SMovement_Turning :: NamedProc
ns_SMovement_Turning =  NamedProc "S_SMovement_Turning" s_SMovement_Turning
{-                        (ExtChoice
                        (Prefix (ID "SMovement_enter_SMovement_SMovement_Turning")
                            (s_SMovement_Turning_execute "SMovement" ))
                        (Prefix (ID "SMovement_enter_SMovement_Turning_SMovement_Turning")
                            (s_SMovement_Turning_execute "SMovement_Turning" ))
                        )
-}
    
{-- C5 --
-- AST for T_SMovement_t3
T_SMovement_t3    = SMovement_internal__!"SMovement_t3" -> SKIP;
                      SMovement_enter!"SMovement_Turning"!"SMovement_Moving" ->
                      SMovement_entered!"SMovement_Turning"!"SMovement_Moving" ->
                      S_SMovement_Turning
--}
--AST for T_SMovement_t3,  
t_SMovement_t3    = Seq (Prefix (ID "SMovement_internal___SMovement_t3") SKIP)
                      (Prefix (ID "SMovement_enter_SMovement_Turning_SMovement_Moving")
                      (Prefix (ID "SMovement_entered_SMovement_Turning_SMovement_Moving")
                      (ProcID "S_SMovement_Turning")))
                      
{-- -- C6 --
-- AST for the S_SMovement_Turning_execute    
S_SMovement_Turning_execute(o__) = (EDeadline(moveCall,0) ; move(0,SMovement_av); EDeadline(moveRet,0)); 
                      SMovement_entered!o__!"SMovement_Turning" ->
                      (SKIP; STOP /\ (T_SMovement_t3
                                         []
                                   SMovement_internal__?x:diff(SMovement_TIDS,{"__NULLTRANSITION__","SMovement_t3"}) ->
                                   SMovement_exit?y:diff(SMovement_SIDS,{"SMovement_Turning"})!"SMovement_Turning" -> (
                                   SKIP;SMovement_exited!y!"SMovement_Turning" -> SKIP);
                                   S_SMovement_Turning
                                   [] 
                                   SMovement_obstacle__?x:diff(SMovement_TIDS,{"__NULLTRANSITION__","SMovement_t3"}) ->
                                   SMovement_exit?y:diff(SMovement_SIDS,{"SMovement_Turning"})!"SMovement_Turning" -> 
                                   (SKIP; SMovement_exited!y!"SMovement_Turning" -> SKIP);
                                   S_SMovement_Turning
                                   )
                       )
--}
-- AST for the S_SMovement_Turning_execute,                    
s_SMovement_Turning_execute o__ = 
               Seq (Seq (EDeadline (ID "moveCall") 0)
                        (Seq SKIP  (EDeadline (ID "moveRet")  0)) )
                   (Prefix (ID ("SMovement_entered_" ++ o__  ++  "_SMovement_Turning"))
                       (Seq SKIP 
                           (Interrupt STOP
                              (ExtChoice
                                 (ExtChoice
                                     (t_SMovement_t3)
                                     (Prefix (ID "SMovement_internal___SMovement_t2")
                                        (Seq
                                        (ExtChoice
                                           (Prefix (ID "SMovement_exit_SMovement_SMovement_Turning") 
                                              (Seq SKIP 
                                                (Prefix (ID "SMovement_exited_SMovement_SMovement_Turning") SKIP)))
                                           (Prefix (ID "SMovement_exit_SMovement_Moving_SMovement_Turning")
                                                (Seq SKIP 
                                                    (Prefix (ID "SMovement_exited_SMovement_Moving_SMovement_Turning")
                                                     SKIP))
                                        ))
                                        (ProcID "S_SMovement_Turning")
                                      ))
                                   )
                               (Seq (Prefix (ID "SMovement_obstacle_SMovement_t2")
                                    (ExtChoice  
                                       (Prefix (ID "SMovement_exit_SMovement_S_Movement_Turning")
                                          (Prefix (ID "SMovement_exited_SMovement_SMovement_Turning")
                                             (Seq SKIP 
                                                 (Prefix (ID "SMovement_exited_SMovement_SMovement_Turning")  SKIP))
                                           ))
                                       (Prefix (ID "SMovement_exit_SMovement_Moving_SMovement_Turning")
                                           (Seq SKIP 
                                                (Prefix (ID "SMovement_exited_SMovement_Moving_SMovement_Turning") SKIP)
                                                ))
                                    ))
                                    (ProcID "S_SMovement_Turning")
                               )
                               )
                              )
                         )
                     )



-- T_SMovement_t1    = SMovement_enter!"SMovement"!"SMovement_Moving" -> SMovement_entered!"SMovement"!"SMovement_Moving" -> SKIP
t_SMovement_t1    = Prefix  (ID "SMovement_enter_SMovement_SMovement_Moving")
                   (Prefix  (ID "SMovement_entered_SMovement_SMovement_Moving") SKIP)

{--
S_SMovement_Moving_R = S_SMovement_Moving
         [|diff(SMovement_int_int,SMovement_Moving_triggers)|]
     -- the above line becomes
     -- {SMovement_internal__."SMovement_t2", SMovement_obstacle__."SMovement_t3", SMovement_internal__."SMovement_t3"}
         SKIP
--}
s_SMovement_Moving_R = GenPar s_SMovement_Moving
--  s_SMovement_Moving_R = GenPar (ProcID "S_SMovement_Moving")
                              SKIP
                              (sMovement_int_int  \\  sMovement_Moving_triggers)

         
{--
S_SMovement_Turning_R = S_SMovement_Turning
         [|diff(SMovement_int_int,SMovement_Turning_triggers)|]
    -- the above line is simplify to become 
    -- {SMovement_obstacle__."SMovement_t2", SMovement_internal__."SMovement_t2", SMovement_obstacle__."SMovement_t3"}
         SKIP
--}
s_SMovement_Turning_R  = GenPar  s_SMovement_Turning  
                                 SKIP
                                 (sMovement_int_int \\ sMovement_Turning_triggers)

         
{----------------------------------------------------------------------------------
STM_SMovement = ShowEvents_SMovement(
                        I_SMovement_i1
                            [|{|SMovement_enter.x.y,
                                SMovement_entered.x.y,
                                SMovement_exit.x.y,
                                SMovement_exited.x.y |
                                x <- diff(SMovement_SIDS,{"SMovement_Moving","SMovement_Turning"}),
                                y <- {"SMovement_Moving","SMovement_Turning"}
                            |}|]
                        ShowEvents_SMovement(
                                S_SMovement_Moving_R
                                    [|inter(CS_SMovement_Moving_sync,CS_SMovement_Turning_sync)|]
                                S_SMovement_Turning_R,  inter(CS_SMovement_Moving_sync,CS_SMovement_Turning_sync)
                                )\inter(CS_SMovement_Moving_sync,CS_SMovement_Turning_sync), 
                                       {|SMovement_enter,SMovement_entered, SMovement_exit,SMovement_exited|}
                ) \  SMovement_internal_events

--}
-- AST for the process STM_Movement  
{-- sTM_SMovement = (GenPar (s_SMovement_Moving_R) 
                  (s_SMovement_Turning_R) 
                  (intersect cS_SMovement_Moving_sync cS_SMovement_Turning_sync))
--}
sTM_SMovement = Hiding (showEvents_SMovement 
                            (GenPar (i_SMovement_i1) 
                                  (Hiding (showEvents_SMovement  
                                               (GenPar (s_SMovement_Moving_R) 
                                                       (s_SMovement_Turning_R) 
                                                       (intersect cS_SMovement_Moving_sync cS_SMovement_Turning_sync))  
                                               (intersect cS_SMovement_Moving_sync cS_SMovement_Turning_sync) 
                                               ) 
                                          (intersect cS_SMovement_Moving_sync cS_SMovement_Turning_sync )  )
                                 (concat [[(ID ("SMovement_enter"   ++ x ++ y)),
                                           (ID ("SMovement_entered" ++ x ++ y)),
                                           (ID ("SMovement_exit"    ++ x ++ y)),
                                           (ID ("SMovement_exited"  ++ x ++ y)) ] |
                                           x <- (sMovement_SIDS \\ ["_SMovement_Moving","_SMovement_Turning"]),
                                           y <- ["_SMovement_Moving","_SMovement_Turning"] ] )
                            )  
                            [(ID "SMovement_enter"), (ID "SMovement_entered"), 
                            (ID "SMovement_exit"),(ID "SMovement_exited")  ]
                            )    
                       sMovement_internal_events

------------------------------------------------------------------------------------
-- AST for the process move from the file move.csp
------------------------------------------------------------------------------------
{-- 
Timed(OneStep) {
move(lv,av) = let
AUX(N) = if (N == 0) then SKIP else
	  SKIP
            within AUX(move_BOUND)
}  
--}
move _  _ = SKIP0 


---------------------------------------------------------- 
-- From untimed SMovement.csp, line 3.
{-- ShowEvents_SMovement(P,E) = P[[ SMovement_entered.x.y <- SMovement_enteredV.y | SMovement_entered.x.y <- E]]
                                 [[ SMovement_enter.x.y <- SMovement_enterV.y | SMovement_enter.x.y <- E]]
                                 [[ SMovement_exit.x.y <- SMovement_exitV.y | SMovement_exit.x.y <- E]]
                                 [[ SMovement_exited.x.y <- SMovement_exitedV.y | SMovement_exited.x.y <- E ]]
--}

showEvents_SMovement ::  CSPproc -> [Event]  -> CSPproc
-- showEvents_SMovement     p          []       =  p
showEvents_SMovement     p          e        =  fun1 p (events p) e  
-- showEvents_SMovement     p          e        =  SKIP
-- showEvents_SMovement     p          (e:es)   =  showEvents_SMovement (Rename p [(e, (ID s2))]) es
-- showEvents_SMovement     p          (e:es)   =  -- error "To be implemented" 
-- Split and remove the middle value???????
-- split e on . and replace the middle element with V and return .y.
-- For each event in p, if it matches the events in e then rename it otherwise skip that event.
    where
        fun1 p (e1:es1)  es = if   elem (ID (head (sp e1)))  es 
                              then fun1 (Rename p [(e1, (ID (((sp e1)!!0) ++ "V" ++ ('_':((sp e1))!!2))))] )  (es1)  es
                              else fun1 p es1  es
        fun1 p []        es = p  
        sp a = (splitOn "_" (show a))
--        events' (showEvents_SMovement p es) =  events p
--        events' (_                        ) = []
--        s0 = events p
--        s1 = splitOn "." (show e)
--        s2 = (s1!!0) ++ "V" ++ ('.':s1!!2)

-- Test example
test1 = showEvents_SMovement (Prefix  (ID "SMovement_enter_SMovement_SMovement_Moving")
                             (Prefix  (ID "SMovement_entered_SMovement_SMovement_Moving") SKIP)) 
                             [(ID "SMovement_enter"), (ID "SMovement_entered"), 
                              (ID "SMovement_exit"),  (ID "SMovement_exited" )  ]
-- >> ((SMovement_enter!SMovement!SMovement_Moving-> (SMovement_entered!SMovement!SMovement_Moving-> (SKIP)))[[SMovement_enter!SMovement!SMovement_Moving<-SMovement_enterV.SMovement_Moving]])[[SMovement_entered!SMovement!SMovement_Moving<-SMovement_enteredV.SMovement_Moving]]

---------------------------------------------------------


{--  Memory process are not relevant for this example
channel getWC_SMovement : SMovement_WC_enablerSet.Bool


Memory_SMovement_WC_SMovement_t3_0(WC_SMovement_t3_0) = (
getWC_SMovement."WC_SMovement_t3_0"!WC_SMovement_t3_0 -> Memory_SMovement_WC_SMovement_t3_0(WC_SMovement_t3_0)
[]
SMovement_WC."WC_SMovement_t3_0"?x__ -> Memory_SMovement_WC_SMovement_t3_0(x__)
)

MemoryTransitions_SMovement = (getWC_SMovement."WC_SMovement_t3_0"?WC_SMovement_t3_0 ->
(SMovement_obstacle__!"SMovement_t2" -> MemoryTransitions_SMovement
[]
(WC_SMovement_t3_0)&(SMovement_internal__!"SMovement_t3" -> MemoryTransitions_SMovement)
[]
SMovement_WC."WC_SMovement_t3_0"?x__ -> MemoryTransitions_SMovement))


MemoryVariablesProcesses_SMovement = {(Memory_SMovement_WC_SMovement_t3_0(false),{|getWC_SMovement."WC_SMovement_t3_0",SMovement_WC."WC_SMovement_t3_0"|})}

MemoryVariables_SMovement = ||| (P, alpha) : MemoryVariablesProcesses_SMovement @ P
MemoryVariablesSyncSet_SMovement = {|getWC_SMovement."WC_SMovement_t3_0",
SMovement_WC."WC_SMovement_t3_0"|}
MemoryVariablesHideSet_SMovement = {|getWC_SMovement|}

MemoryN_SMovement = (wbisim(MemoryVariables_SMovement) [| MemoryVariablesSyncSet_SMovement |] wbisim(MemoryTransitions_SMovement)) \ MemoryVariablesHideSet_SMovement

Memory_SMovement(WC_SMovement_t3_0) = (
SMovement_WC."WC_SMovement_t3_0"?x__ -> Memory_SMovement(x__)
[]
SMovement_obstacle__!"SMovement_t2" -> Memory_SMovement(WC_SMovement_t3_0)
[]
(WC_SMovement_t3_0)&(SMovement_internal__!"SMovement_t3" -> Memory_SMovement(WC_SMovement_t3_0))
)

MemoryO_SMovement = Memory_SMovement(false)
--}

------------------------------------------------------------------------------------------------
{-- main process, the generated code.
SMovement_aux = prioritise(timed_priority(((wbisim(STM_SMovement)
    [|Union({
        {||},
        {|SMovement_obstacle__."SMovement_t2",
        SMovement_internal__."SMovement_t3"|}
        ,
        {|SMovement_deadline|},
        SMovement_WCresets
    })|]
    (wbisim(MemoryN_SMovement) [| union({|SMovement_WC|},SMovement_WCsync) |] SMovement_WaitingConditions)\{|SMovement_WC|}
)[[SMovement_obstacle__.x <- SMovement_obstacle| x<-SMovement_TIDS]]\union({||},{|SMovement_deadline,SMovement_clockReset|}))
[|{|SMovement_terminate|}|>SKIP\{|SMovement_internal__|}),<{|SMovement_enteredV,SMovement_enterV,SMovement_exitV,SMovement_exitedV|},{tock}>)

SMovement = timed_priority(SMovement_aux \ {|SMovement_enteredV, SMovement_enterV, SMovement_exitV, SMovement_exitedV|})
SMovement_VS = SMovement_aux
}
--}
-- A simplification of the main process without the memory process.
-- SMovement_aux = STM_SMovement [|{|SMovement_terminate|}|> SKIP\{|SMovement_internal__|}
-- Which can be interrupted when ever the process STM_SMovement performs the event SMovement_terminate.
-- timed priority is not included
sMovement_aux  = Exception sTM_SMovement SKIP [(ID "SMovement_terminate")]


-- sMovement_aux  = sTM_SMovement 
--SMovement = timed_priority(SMovement_aux 
--                          \ {|SMovement_enteredV, SMovement_enterV, SMovement_exitV, SMovement_exitedV|})
sMovement = Hiding sMovement_aux 
                   [(ID "SMovement_enteredV"), (ID "SMovement_enterV"), 
                    (ID "SMovement_exitV"),    (ID "SMovement_exitedV")]
------------------------------------------------------------------------------------------------



-----------------------------------------------------------------------------------------------------
-- Other definitions, some from unitimed sections.
-----------------------------------------------------------------------------------------------------

-- From the file instantiations.csp
-- generate SMovement_lv
sMovement_lv = 0

-- declaring identifiers of state and final states
{-- SMovement_SIDS = {
    "SMovement",
    "SMovement_Moving",
    "SMovement_Turning"
}   --}
sMovement_SIDS = ["_SMovement", "_SMovement_Moving", "_SMovement_Turning"]


-- declaring identifiers of transitions
{-- SMovement_TIDS = {
    "__NULLTRANSITION__",
    "SMovement_t2",
    "SMovement_t3"
}  --}
sMovement_TIDS = ["__NULLTRANSITION__", "_SMovement_t2", "_SMovement_t3" ] 



{-- Simplification
=> Therefore, diff(SMovement_TIDS,{"__NULLTRANSITION__","SMovement_t2"}) 
           =  {"SMovement_t3"}

-- Simplification           
=> And also  diff(SMovement_SIDS,{"SMovement_Moving"})
           = { "SMovement", "SMovement_Turning" }

SMovement_int_int = {|
    SMovement_obstacle__."SMovement_t2",
    SMovement_internal__."SMovement_t2",
    SMovement_obstacle__."SMovement_t3",
    SMovement_internal__."SMovement_t3"
|}  --}
sMovement_int_int = [ (ID "SMovement_obstacle___SMovement_t2"), 
                      (ID "SMovement_internal___SMovement_t2"),
                      (ID "SMovement_obstacle___SMovement_t3"),
                      (ID "SMovement_internal___SMovement_t3")  ]
         
-----------------------------------------------------------------------------------------------------





{--
CS_SMovement_Turning_sync = {|
    SMovement_enter.y.x, 
    SMovement_entered.y.x, 
    SMovement_exit.y.x, 
    SMovement_exited.y.x,
    SMovement_enter.x.y, 
    SMovement_entered.x.y, 
    SMovement_exit.x.y, 
    SMovement_exited.x.y |
    x <- {"SMovement_Moving","SMovement_Turning"},
    y <- {"SMovement_Turning"}
|}      --}
cS_SMovement_Turning_sync = concat [[
   (ID ("SMovement_enter"    ++ y ++ x)), 
   (ID ("SMovement_entered"  ++ y ++ x)), 
   (ID ("SMovement_exit"     ++ y ++ x)), 
   (ID ("SMovement_exited"   ++ y ++ x)),
   (ID ("SMovement_enter"    ++ x ++ y)), 
   (ID ("SMovement_entered"  ++ x ++ y)), 
   (ID ("SMovement_exit"     ++ x ++ y)), 
   (ID ("SMovement_exited"   ++ x ++ y)) ]|
   x <- ["_SMovement_Moving","_SMovement_Turning"],
   y <- ["_SMovement_Turning"]
   ]


-- I_SMovement_i1 = T_SMovement_t1
i_SMovement_i1 = t_SMovement_t1


-------------------------------------------------------------------
-- Definition from untimed SMovement.csp, line 50
-- SMovement_Moving_triggers = {|SMovement_obstacle__."SMovement_t2"|}
sMovement_Moving_triggers = [(ID "SMovement_obstacle__.SMovement_t2")]


-- SMovement_Turning_triggers = {| SMovement_internal__."SMovement_t3" |}
sMovement_Turning_triggers = [ (ID "SMovement_internal__.SMovement_t3") ]

-- SMovement_internal_events = {|SMovement_enter,SMovement_entered, SMovement_exit,SMovement_exited|}
sMovement_internal_events = [(ID "SMovement_enter"), (ID "SMovement_entered"), 
                             (ID "SMovement_exit" ), (ID "SMovement_exited" )]

--------------------------------------------------------------------
-- From the file timed_definitions.csp
-- Assumes no time needed to reset clock
-- DoClockReset(CS) = ||| c : CS @ c -> SKIP

doClockReset _ = SKIP0
